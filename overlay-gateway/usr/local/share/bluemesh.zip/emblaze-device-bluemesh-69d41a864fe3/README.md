BlueMesh
========

[![pre-commit](https://img.shields.io/badge/pre--commit%202.20.0-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)
[![Code style: black](https://img.shields.io/badge/code%20style-black%2022.6.0-black.svg)](https://github.com/psf/black)
[![Code style: flake8](https://img.shields.io/badge/pep8-flake8%204.0.1-CC9900)](https://github.com/pycqa/flake8)
[![linting: pylint](https://img.shields.io/badge/linting-pylint%202.14.5-yellowgreen.svg)](https://github.com/PyCQA/pylint)
[![Imports: isort](https://img.shields.io/badge/imports-isort%205.9.3-%231674b1?style=flat&labelColor=ef8336)](https://pycqa.github.io/isort/)
[![Checked with mypy](https://img.shields.io/badge/typing-mypy%200.981-333CCC)](http://mypy-lang.org/)
[![Docs: sphinx](https://img.shields.io/badge/Made%20with-Sphinx-1f425f.svg)](https://www.sphinx-doc.org/)
[![Coverage](https://img.shields.io/badge/Coverage-93%%-99FF33.svg)](https://user-images.githubusercontent.com/24751868/223009807-cdba83d2-a5e7-49bc-8c54-928085711d93.png)

[![Python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

---

BlueMesh is the SDK to develop bluetooth mesh applications for Python with BlueZ's bluetooth-mesh daemon.

## Table of contents

- [BlueMesh](#bluemesh)
    * [Table of contents](#table-of-contents)
    * [Version](#version)
    * [Environment](#environment)
    * [Installation](#installation)
    * [Guide](#guide)
        + [Sample code](#sample-code)
        + [Model](#model)
        + [Element](#element)
        + [Application](#application)
        + [Usage](#usage)
    * [Test](#test)
        + [unittest](#unittest)
        + [coverage](#coverage)
    * [Documentation](#documentation)
        + [Sphinx](#sphinx)


## Version

|Version|Patch Note|
|:-----:|----------|
|0.0.0  |Advanced development. No release.|
|0.1.0  |Minimal candidate-release version.|

## Environment

|Module|Version|Note|
|------|-------|----|
|Kernel|5.15.0|Ubuntu 20.04.|
|BlueZ|5.65|www.bluez.org/release-of-bluez-5-65/. See also Github. Download the source code.|
|Python|3.10.6|Python packages to use are defined in 'requirements.txt'.|

## Installation

1. Compile BlueZ. See
    [our guideline](https://neostack.atlassian.net/wiki/spaces/MES/pages/101384207/bluez).
1. Start Bluetooth Mesh mode by BlueZ.
    ```bash
    sudo systemctl stop bluetooth.service
    sudo bluez/mesh/bluetooth-meshd -nd            # bluez directory is source
    ```
1. Install BlueMesh.
    - Using git
        ```bash
        sudo apt install python3-gi python3-gi-cairo gir1.2-gtk-3.0        # Install PyGObject on Ubuntu.
        pip install dbus-python==1.2.18
        git clone --depth 1 https://TOT0RoKR@bitbucket.org/emblaze-device/bluemesh.git
        cd bluemesh
        pip install -r requirements.txt
        python3 setup.py install        # For futher development, use 'develop' instead of 'install'.
        ```
        > You can also download PyGObject on other platform. See
        > https://pygobject.readthedocs.io/en/latest/getting_started.html#ubuntu-getting-started

## Guide

### Sample code

See docs/sample_application.py

### Model

Define a class inherit from `bluemesh.models.Model`.

1. Set class-defined attributes
    * `MODEL_ID`: 16-bit Vendor-assigned model identifier.
    * `VENDOR`: 16-bit Company identifier. If vendor is SIG, VENDOR is None.
    * `HANDLERS`: Dictionary variable containing incoming message handlers. You must declare an empty
        `dictionary.
    * `PUBLISH`: Whether the model uses the Model Publication feature. Default False.
    * `SUBSCRIBE`: Same as `PUBLISH`
1. Define methods to send message
    * Declare a method using `send()` or `dev_key_send()`, a decorator that receives the opcode of the
        message and the signature of the message to be sent as arguments.
    * The first two arguments are destination address and app key index in case of `send()`, and
        destination address and net key index in case of `dev_key_send()`.
    * Method return values should be put in a list in the order appropriate for the signature.
1. Define methods to receive message
    * Declare a method using `message_handlert` or `dev_key_message_handler`, a decorator that
        receives `HANDLER`, the opcode of the message, and the signature of the message to be sent as
        arguments.
    * In case of `message_handler()`, the arguments are source address, app key index, destination
        address, and fields. In case of `dev_key_message_handler()`, the arguments are fixed as source
        address, remote node or not, net key index, and fields.
    * The method return value should be properly stored in a container in the data format to be used
        when handling in the application.
1. Register a new signature
    * Define pack method
        1. Define a method that takes the value and signature as arguments.
        1. Packing in little-endian by processing data according to values and signatures.
    * Define unpack method
        1. Define a method that receives little-endian byte data and a signature as arguments.
        1. Unpacking little-endian bytes, typecasting. If the data is multiple fields, it is returned
            as a tuple or list. Additionally, return byte-data length.
    * Register user-define signature through `bluemesh.AccessMessage.set_signature()` methods
        * `set_signature()` arguments are signature, defined pack method, defined unpack method.
        * When using a signature, enclose it in parentheses.

#### Example

```python
from bluemesh.models import Model
from bluemesh.access import AccessMessage

class VendorClient(Model):
    MODEL_ID = 0x9999
    VENDOR = 0x05F1
    HANDLERS = {}

    PUBLISH = False
    SUBSCRIBE = True

    @Model.send(0x05F101, "(ve)")
    def echo(self, dest, key_index, msg):
        return [msg]

    @Model.message_handler(HANDLERS, 0x05F102, "(ve)")
    def echo_handler(self, source, key_index, dest, fields):
        msg = fields[0]
        return {"msg": msg}


def pack_vendor_echo(msg, sign):
    return msg.encode()

def unpack_vendor_echo(data, sign):
    return data.decode(), len(data)

AccessMessage.set_signature("ve", pack_func=pack_vendor_echo, unpack_func=unpack_vendor_echo)
```

### Element

Define a class inherit from `bluemesh.element.Element` including `MODEL_CLASSES`.

#### Example

```python
from bluemesh.element import Element
from bluemesh.models import ConfigClient, GenericLevelClient

class SampleElement(Element):
    MODEL_CLASSES = [
        ConfigClient,
        GenericLevelClient,
        VendorClient,
    ]
```

### Application

Define a class inheriting from `bluemesh.application.Application` with following attributes:

|Attribute|Type|Requirements|Note|
|:-------:|----|------------|----|
|`COMPANY_ID`|16-bit `int`|Required| It is the same as Vendor ID|
|`PRODUCT_ID`|16-bit `int`|Required||
|`VERSION_ID`|16-bit `int`|Required||
|`CRPL`      |16-bit `int`|Optional   |Minimum number of replay attack protection list entries|
|`ELEMENT_CLASSES`|`bluemesh.element.Element`|Required|User defined elements. Each element has address counting from the `ADDRESS`|

#### Example

```python
from bluemesh.application import Application

class SampleApplication(Application):
    """SampleApplication"""

    COMPANY_ID: int = 0x05F1  # Linux Foundation
    PRODUCT_ID: int = 0x0001
    VERSION_ID: int = 0x0001
    ELEMENT_CLASSES = [
        SampleElement,
    ]

```

### Usage

1. Make an instance of `bluemesh.application.Application` with D-Bus object path.
    * It is recommended to use the `bluemesh.application.ApplicationBuilder` for attributes setting.
    * Alternatively, it can be set as an argument during initialization.
    * Subsequent changes are prohibited.
1. Import node when it have not registered at mesh network.
1. Attach node to mesh network.
1. Setup node into local DB.
1. Connect queues to handle incoming messages.
1. Use mesh application!

#### Example

You can get token using `Application`'s property, `token`, after `import_node()`.
If you want to attach existing node, provide the token before `attach_node()`.
The example below is an example using `ApplicationBuilder`.

```python
######################################################################
# Contains the previously mentioned Element and Application examples.#
######################################################################

from bluemesh.application import ApplicationBuilder, ApplicationError
import queue
import uuid as _uuid

address = 1  # Primary element's unicast address.
uuid = _uuid.uuid1()  # Node UUID. If it exist, change it.
token = 0  # Node token. If you have gotton a token before, change it.

builder = ApplicationBuilder(SampleApplication, "/bluemesh/sample", "dbus-python")
builder.set_address(address)
builder.set_uuid(uuid)
if not token:
    builder.set_primary_net_key((0, bytes.fromhex("DEADDEADDEADDEADDEADDEADDEADDEAD")))
    builder.set_dev_key(bytes.fromhex("BEEFBEEFBEEFBEEFBEEFBEEFBEEFBEEF"))
    builder.set_iv_index(0)
    builder.set_iv_update(False)
    builder.set_key_refresh(False)
    try:
        app = builder.build_import_attach()
    except AttributeError as e:
        print(f"AttributeError: {e}")
        app = None
    except ApplicationError as e:
        print(f"ApplicationError: {e}")
        app = None
    else:
        print("Imported")
else:
    builder.set_token(token)
    try:
        app = builder.build_attach()
    except AttributeError as e:
        print(f"AttributeError: {e}")
        app = None
    except ApplicationError as e:
        print(f"ApplicationError: {e}")
        app = None
    print("Attached")
app.import_app_key(0, 0, bytes.fromhex("C0DEC0DEC0DEC0DEC0DEC0DEC0DEC0DE"))

que = queue.Queue(maxsize=100)
app.register_queue(que)
app[0][(None, 0x0001)].composition_data_get(1, 0)
print(que.get())
```

## Test

### unittest

Add tests into "test" directory, as filename with prefix `test_`.
Run whole test using setuptools.

```
python3 setup.py test
```

### coverage

#### Prerequirement

Install coverage

```
pip install "bluemesh[test]"
```

Make coverage files using setuptools.

```
python3 setup.py coverage
```

HTML output is made to `docs/coverage_report_html` directory.


## Documentation

### Sphinx

#### Prerequirement

Install Sphinx

```
pip install "bluemesh[docs]"
```

To build technical documents using sphinx, as follow:

```bash
sphinx-apidoc -f -o docs/source bluemesh
python setup.py build_sphinx [options...]
```

You can find html document in `docs/sphinx/`.
Get more information about sphinx from [here](https://www.sphinx-doc.org/en/master/usage/advanced/setuptools.html)
