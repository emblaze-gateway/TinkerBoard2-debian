# -*- coding: utf-8 -*-
"""Bluemesh Access Module"""


import re
import struct
import uuid as _uuid
from typing import Any, Callable

import bluemesh.bluemesh_logging as logging

logger = logging.getLogger("bluemesh.access")

re_variable = re.compile(r"\{.+\}")
"""
Todo:
    Fix regex not to match text without brace. Currently, variable extension match wrong
    about text_with_brace-text_without_brace-text_with_brace string::

        re_variable.match("{alice}bob{carol}").group()
        Expected: "{alice}"
        Got: "{alice}bob{carol}"

    ChatGPT said you can use this way::

        def extract_matches(text):
            matches = []
            stack = []
            for i,c in enumerate(text):
                if c == '{':
                    stack.append(i)
                elif c == '}':
                    if stack:
                        start = stack.pop()
                        if not stack:
                            matches.append(text[start:i+1])
            return matches

        text = "This is a {sentence} with {{nested {braces}} and {words}}."
        result = extract_matches(text)
        print(result)


"""
re_extension = re.compile(r"\([^\(\)]+\)")
re_raw_data = re.compile(r"r[0-9]+")


def _pack_undefined(dump: Any, signature: str) -> bytes:
    logger.debug(
        "Any pack method of the signature {} for {}({}) does not defined",
        signature,
        type(dump),
        dump,
    )
    return bytes()


def _unpack_undefined(dump: Any, signature) -> tuple[list[Any], int]:
    logger.debug(
        "Any unpack method of the signature {} for {}({}) does not defined",
        signature,
        type(dump),
        dump,
    )
    return [], 0


class AccessMessage:
    """AccessMessage"""

    _funcs: dict[str, dict[str, Callable]] = {}

    @staticmethod
    def unpack(data: bytes, signature: str) -> list[Any] | None:
        if data[0] < 0x7F:
            data = data[1:]
        elif data[0] == 0x7F:
            raise ValueError("Opcode 0x7F is RFU")
        elif data[0] < 0xC0:
            data = data[2:]
        else:
            data = data[3:]

        if len(signature) > 0:
            fields, _ = AccessMessage._unpack_variable(data, signature)
        else:
            fields = None

        return fields

    @staticmethod
    def parse_opcode(data: bytes) -> int:
        if data[0] < 0x7F:
            opcode = struct.unpack(">B", data[:1])[0]
        elif data[0] == 0x7F:
            raise ValueError("Opcode 0x7F is RFU")
        elif data[0] < 0xC0:
            opcode = struct.unpack(">H", data[:2])[0]
        else:
            opcode = struct.unpack(">I", bytes([0]) + data[:3])[0]

        return opcode

    @staticmethod
    def pack(opcode: int, fields: list[Any], signature: str) -> bytes:
        """Packing a model's message."""
        data = bytearray()
        if opcode < 0 or opcode == 0x7F:
            raise ValueError("Opcode 0x7F is RFU")
        if opcode < 0x7F:
            data += struct.pack(">B", opcode)
        elif opcode < 0x8000:
            raise ValueError("Opcode is not valid")
        elif opcode < 0xC000:
            data += struct.pack(">H", opcode)
        elif opcode < 0xC00000:
            raise ValueError("Opcode is not valid")
        elif opcode <= 0xFFFFFF:
            data += struct.pack(">HB", (opcode & 0xFFFF00) >> 8, opcode & 0xFF)
        else:
            raise ValueError("opcode is not valid")

        if len(signature) > 0:
            data += AccessMessage._pack_variable(fields, signature)

        return data

    @staticmethod
    def set_signature(
        signature: str,
        /,
        pack_func: Callable = _pack_undefined,
        unpack_func: Callable = _unpack_undefined,
    ):
        if signature in AccessMessage._funcs:
            logger.warning(
                'Signature "{}" already exist and to be overridden', signature
            )
        AccessMessage._funcs[signature] = {"pack": pack_func, "unpack": unpack_func}

    @staticmethod
    def _pack_variable(fields: list[Any], signature: str) -> bytes:
        """ "{?}": Variable, as list.  Contains zero or more sequences.

        Note:
            * Variable length fields must be placed last.
            * There must be only one sequence of consecutive optional fields
                or a variable length parameter
        """
        data = bytearray()
        while len(fields) > 0:
            i = 0
            while i < len(signature) and len(fields) > 0:
                sign = signature[i]
                field = fields.pop(0)
                if sign in "{":
                    sub_signature = re_variable.match(signature[i:])
                    if sub_signature is None:
                        raise RuntimeError("Made error by signature")
                    data += AccessMessage._pack_variable(
                        field, sub_signature.group()[1:-1]
                    )
                    i += len(sub_signature.group())
                elif sign in "(":
                    sub_signature = re_extension.match(signature[i:])
                    if sub_signature is None:
                        raise RuntimeError("Made error by signature")
                    sign = sub_signature.group()[1:-1]
                    data += AccessMessage._funcs[sign]["pack"](field, sign)
                    i += len(sign) + 2
                elif sign in "r":
                    if signature[i + 1] == "_":
                        data += field
                        i += 2
                    else:
                        sub_signature = re_raw_data.match(signature[i:])
                        if sub_signature is None:
                            raise RuntimeError("Made error by signature")
                        data += field
                        i += len(sub_signature.group())
                else:
                    data += AccessMessage._funcs[sign]["pack"](field, sign)
                    i += 1

        return data

    @staticmethod
    def _unpack_variable(data: bytes, signature: str) -> tuple[list[Any], int]:
        """
        Note:
            * Variable length fields must be placed last.
            * There must be only one sequence of consecutive optional fields
                or a variable length parameter

        """
        fields: list[Any] = []
        count = 0
        while count < len(data):
            i = 0
            while i < len(signature) and count < len(data):
                sign = signature[i]
                if sign in "{":
                    sub_signature = re_variable.match(signature[i:])
                    if sub_signature is None:
                        raise RuntimeError("Made error by signature")
                    field, cnt = AccessMessage._unpack_variable(
                        data[count:], sub_signature.group()[1:-1]
                    )
                    fields += field
                    i += len(sub_signature.group())
                elif sign in "(":
                    sub_signature = re_extension.match(signature[i:])
                    if sub_signature is None:
                        raise RuntimeError("Made error by signature")
                    sign = sub_signature.group()[1:-1]
                    field, cnt = AccessMessage._funcs[sign]["unpack"](
                        data[count:], sign
                    )
                    fields.append(field)
                    i += len(sign) + 2
                elif sign in "r":
                    if signature[i + 1] == "_":
                        cnt = len(data[count:])
                        i += 2
                    else:
                        sub_signature = re_raw_data.match(signature[i:])
                        if sub_signature is None:
                            raise RuntimeError("Made error by signature")
                        cnt = int(sub_signature.group()[1:])
                        i += len(sub_signature.group())
                    fields.append(data[count : count + cnt])
                else:
                    field, cnt = AccessMessage._funcs[sign]["unpack"](
                        data[count:], sign
                    )
                    fields.append(field)
                    i += 1
                count += cnt
        return fields, count


def pack_integer(integer: int, signature: str) -> bytes:
    """ "bBhHiI": Integer. See more `python library struct`_.

    * '?': 1-byte boolean.
    * 'b': 1-byte signed integer.
    * 'B': 1-byte unsigned integer.
    * 'h': 2-byte signed integer.
    * 'H': 2-byte unsigned integer.
    * 'i': 4-byte signed integer.
    * 'I': 4-byte unsigned integer.

    .. _python library struct:
        https://docs.python.org/3/library/struct.html

    """
    return struct.pack("<" + signature, integer)


def unpack_integer(data: bytes, signature: str) -> tuple[int, int]:
    if signature in "?bB":
        count = 1
    elif signature in "hH":
        count = 2
    else:
        count = 4

    return struct.unpack("<" + signature, data[:count])[0], count


def pack_uuid(uuid: str | bytes | _uuid.UUID, signature: str) -> bytes:
    # pylint: disable=unused-argument
    if isinstance(uuid, str):
        uuid = _uuid.UUID(uuid).bytes
    elif isinstance(uuid, _uuid.UUID):
        uuid = uuid.bytes

    return uuid


def unpack_uuid(data: bytes, signature: str) -> tuple[_uuid.UUID, int]:
    # pylint: disable=unused-argument
    return _uuid.UUID(bytes=data[:16]), 16


for _iter_integer_sign in "?bBhHiI":
    AccessMessage.set_signature(
        _iter_integer_sign, pack_func=pack_integer, unpack_func=unpack_integer
    )
AccessMessage.set_signature("u", pack_func=pack_uuid, unpack_func=unpack_uuid)
