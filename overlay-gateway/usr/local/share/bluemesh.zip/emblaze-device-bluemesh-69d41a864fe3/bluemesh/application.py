# -*- coding: utf-8 -*-
"""Bluemesh Application Module

This module provides :class:`Application` to make bluetooth mesh application
using bluez interfaces.

Example:
    User application with SIG/Vendor models can be made by inheritance of
    :class:`Application`.::

        class MyApplication(Application):
            ...

.. _Mesh API:
   https://git.kernel.org/pub/scm/bluetooth/bluez.git/tree/doc/mesh-api.txt

"""

import queue as _queue
import threading
import uuid as _uuid
from collections.abc import Callable
from typing import Any, Optional

import bluemesh.bluemesh_logging as logging
from bluemesh.bluez_interface import (
    ApplicationInterfaceABC,
    BlueZInterfaceFactory,
    ManagementInterfaceABC,
    NetworkInterfaceABC,
    NodeInterfaceABC,
    PropertyInterfaceABC,
)
from bluemesh.element import Element

logger = logging.getLogger("bluemesh.application")


class ApplicationError(Exception):
    """The type of 'Exception' for Application Errors"""


class UUIDProperty:
    """Machine uuid property

    Raises:
        AttributeError: Setting is forbidden.

    """

    @property
    def uuid(self) -> _uuid.UUID:
        """uuid"""
        uuid = getattr(self, "__uuid")
        return uuid

    @uuid.setter
    def uuid(self, value: _uuid.UUID):
        raise AttributeError(
            "attribute 'uuid' of 'bluemesh.Application' object is not writable"
        )


class KeysProperty:
    """Keys

    Raises:
        ValueError: If value is wrong data.
        TypeError: If value is wrong type.

    """

    @property
    def dev_key(self) -> bytes:
        """Device key

        Returns:
            16-byte

        """
        key = getattr(self, "__dev_key")
        return key

    @dev_key.setter
    def dev_key(self, value: bytes):
        if not isinstance(value, bytes):
            raise TypeError("key type is bytes")
        if len(value) != 16:
            raise ValueError(f"key must be 16 bytes long, got: {value!r}")
        setattr(self, "__dev_key", value)

    @property
    def primary_net_key(self) -> tuple[int, bytes]:
        """Primary Network key

        Returns:
            tuple[index, 16-byte key]

        """
        key = getattr(self, "__primary_net_key")
        return key

    @primary_net_key.setter
    def primary_net_key(self, value: tuple[int, bytes]):
        if not isinstance(value, tuple):
            raise TypeError("'value' must be tuple[int, bytes]")
        if not isinstance(value[0], int):
            raise TypeError("index must be int")
        if not isinstance(value[1], bytes):
            raise TypeError("key must be bytes")
        if not 0 <= value[0] <= 4095:
            raise ValueError(f"index must be in range of 0~4095, got: {value[0]}")
        if len(value[1]) != 16:
            raise ValueError(f"key must be 16 bytes long, got: {value[1]!r}")
        setattr(self, "__primary_net_key", value)


class TokenProperty:
    """Token

    Could get by JoinComplete when application success to import node to BlueZ.
    Please see :func:`ApplicationInterface.JoinComplete` and
    :func:`Application.import_node`. You can find out how to import it from `Mesh API`_.

    Raises:
        AttributeError: Setting is forbidden.

    """

    @property
    def token(self) -> int:
        return getattr(self, "__token")

    @token.setter
    def token(self, value: int):
        raise AttributeError(
            "attribute 'token' of 'bluemesh.Application' object is not writable"
        )


class MessageHandlerMixin:
    """MessageHandlerMixin

    Messages received from the mesh network are stored in a queue so that handlers can
    process them.

    """

    def __init__(self):
        self.__handlers = {}

    def register_queue(self, queue, filter_message: Callable | None = None):
        """register_queue.

        Args:
            queue (multiprocessing.Queue | queue.Queue | other Queue object): Queue
                containing messages to be handle. Queue must implements all the methods
                of `queue.Queue` except for `task_done()` and `join()`.
                The usual `queue.Empty` and `queue.Full` exceptions from the standard
                library's queue module are raised to signal timeouts.
            filter_message (Callable | None): A fuction to filter messages.

        """
        if filter_message is not None and not callable(filter_message):
            raise TypeError("'filter_message' must be 'callable'")
        if not hasattr(queue, "put") or not hasattr(queue, "get"):
            raise TypeError("'queue' must have 'get' and 'put' method")
        if queue not in self.__handlers:
            self.__handlers[queue] = filter_message
        else:
            logger.warning("register_queue: queue {} is already added", queue)

    def unregister_queue(self, queue):
        try:
            self.__handlers.pop(queue)
        except KeyError:
            logger.warning("unregister_queue: queue {} has not added", queue)

    def message_handler(self, message):
        for queue, filter_message in self.__handlers.items():
            if filter_message and not filter_message(message):
                continue
            try:
                queue.put(message, block=False)
            except _queue.Full:
                logger.error(
                    "message_handler: 'queue' {} is full. Discard handling "
                    + "for message {}",
                    queue,
                    message,
                )


class Application(
    UUIDProperty,
    KeysProperty,
    TokenProperty,
    MessageHandlerMixin,
):
    # pylint: disable=abstract-method,too-many-instance-attributes,R0904
    # too-many-public-methods
    """Application

    Attributes:
        path (str): The object path of application root.
        interface: BlueZ Application1 interface.
        _network_interface: BlueZ Network1 interface.
        _node_interface: BlueZ Node1 interface.
        _management_interface: BlueZ Management1 interface.
        DEVICE_UUID: device uuid. Must be overriden.
        ADDRESS: address. Must be overriden.

    Todo:
        * Implement export_keys_cb method

    """
    ELEMENT_CLASSES: list[type["Element"]]
    COMPANY_ID: int
    PRODUCT_ID: int
    VERSION_ID: int
    CRPL: int  # Optional

    def __new__(cls, *args, **kwargs):
        # pylint: disable=unused-argument
        if cls is Application:
            raise TypeError("Cannot instantiate Base class")
        return super().__new__(cls)

    def __init__(self, path: str, dbus_module_type: str, **kwargs):
        self.path = path

        for attr in ("COMPANY_ID", "PRODUCT_ID", "VERSION_ID", "CRPL"):
            identifier = getattr(self, attr, None)
            if identifier is None:
                if attr == "CRPL":
                    continue
                raise ApplicationError(f"'Application.{attr}' must be overriden.")
            if not isinstance(identifier, int):
                raise TypeError(f"attribute 'Application.{attr}' must be int")
            if not 0 <= identifier <= 0xFFFF:
                raise ValueError(
                    f"attribute 'Application.{attr}' must be 4-character hexadecimal, "
                    + f"got: 0x{identifier:X}"
                )

        try:
            self.interface_factory = BlueZInterfaceFactory(dbus_module_type)
        except ImportError as e:
            logger.error(e)
            raise ApplicationError(
                f"Wrong module type for communication with D-Bus: {e}"
            ) from e

        self.interface: ApplicationInterfaceABC = (
            self.interface_factory.create_application_interface(self, self.path)
        )
        self._network_interface: NetworkInterfaceABC = (
            self.interface_factory.create_network_interface(self)
        )

        self._node_interface: NodeInterfaceABC
        self._management_interface: ManagementInterfaceABC
        self._property_interface: PropertyInterfaceABC

        self._elements: dict[int, Element] = {}
        if not getattr(self, "ELEMENT_CLASSES", None):
            raise ApplicationError(f"{self.__class__} does not have any Element")
        for index, element_class in enumerate(self.ELEMENT_CLASSES):
            element = element_class(self, index, self.interface_factory)
            self._elements[index] = element

        for key, value in kwargs.items():
            if key in (
                "uuid",
                "address",
                "dev_key",
                "primary_net_key",
                "iv_update",
                "key_refresh",
                "iv_index",
                "token",
            ):
                setattr(self, "__" + key, value)

        MessageHandlerMixin.__init__(self)

    @property
    def node_interface(self) -> NodeInterfaceABC:
        if not getattr(self, "_node_interface", None):
            raise ApplicationError("Application has not attached yet")
        return self._node_interface

    @property
    def management_interface(self) -> ManagementInterfaceABC:
        if not getattr(self, "_management_interface", None):
            raise ApplicationError("Application has not attached yet")
        return self._management_interface

    @property
    def property_interface(self) -> PropertyInterfaceABC:
        if not getattr(self, "_property_interface", None):
            raise ApplicationError("Application has not attached yet")
        return self._property_interface

    def __getitem__(self, key: int):
        return self._elements[key]

    def import_node(
        self, wait: bool = False, event_lock: threading.Event | None = None
    ) -> int | None:
        if wait:
            if isinstance(event_lock, threading.Event):
                _event_lock = event_lock
            else:
                _event_lock = threading.Event()
            setattr(self, "__import_container", _event_lock)

        self._network_interface.import_node(
            app_root=self.path,
            uuid=self.uuid.bytes,
            dev_key=self.dev_key,
            net_key=self.primary_net_key[1],
            net_index=self.primary_net_key[0],
            iv_update=getattr(self, "__iv_update"),
            key_refresh=getattr(self, "__key_refresh"),
            iv_index=getattr(self, "__iv_index"),
            unicast=getattr(self, "__address"),
        )

        if wait:
            if not _event_lock.wait(timeout=5):
                logger.error("timeout: 'Application' failed to import to network")
                delattr(self, "__import_container")
                raise ApplicationError("'import_node()' failed'")
            token = getattr(self, "__import_container", None)
            delattr(self, "__import_container")
            return token
        return None

    def attach_node(
        self, wait: bool = False, event_lock: threading.Event | None = None
    ):
        if wait:
            if isinstance(event_lock, threading.Event):
                _event_lock = event_lock
            else:
                _event_lock = threading.Event()
            setattr(self, "__attach_container", _event_lock)

        self._network_interface.attach_node(app_root=self.path, token=self.token)

        if wait:
            if not _event_lock.wait(timeout=3):
                logger.error("timeout: 'Application' failed to attach to network")
                delattr(self, "__attach_container")
                raise ApplicationError("'attach_node()' failed'")
            delattr(self, "__attach_container")

    @property
    def features(self) -> dict[str, bool]:
        return self.property_interface.get(self._node_interface, "Features")

    @property
    def beacon(self) -> bool:
        return self.property_interface.get(self._node_interface, "Beacon")

    @property
    def iv_index(self) -> int:
        return self.property_interface.get(self._node_interface, "IvIndex")

    @property
    def iv_update(self) -> bool:
        return self.property_interface.get(self._node_interface, "IvUpdate")

    @property
    def seconds_since_last_heard(self) -> int:
        return self.property_interface.get(
            self._node_interface, "SecondsSinceLastHeard"
        )

    @property
    def addresses(self) -> list[int]:
        return self.property_interface.get(self._node_interface, "Addresses")

    @property
    def sequence_number(self) -> int:
        return self.property_interface.get(self._node_interface, "SequenceNumber")

    def set_sequence_number(self, seq_nr: int):
        """Adjust sequence number

        This is a method to adjust the Read-Only sequence number property value.
        This is not a bluez official method.

        """
        if hasattr(self.node_interface, "set_sequence_number"):
            self.node_interface.set_sequence_number(seq_nr=seq_nr)  # type: ignore
        else:
            logger.warning("Application can not adjust sequence number")

    def attach_node_handler(
        self, node_path: str, config: list[tuple[int, list[tuple[int, dict]]]]
    ):
        """Attach node call-back handler

        Args:
            node_path: :class:`NodeInterface` object path as device uuid when
                declared :func:`Application.import_node`.
            config: Current elements configurations. data structures:
                [(element_index(int), [(model_id(int), model_configs(dict))])]

        """
        self._node_interface = self.interface_factory.create_node_interface(
            self, node_path
        )
        self._management_interface = self.interface_factory.create_management_interface(
            self, node_path
        )

        self._property_interface = self.interface_factory.create_property_interface(
            self, node_path
        )

        for element_index, models_config in config:
            for model_id, model_config in models_config:
                self._elements[element_index].update_model_config(
                    vendor_assigned_model_id=model_id, config=model_config
                )

        event_lock = getattr(self, "__attach_container", None)
        if event_lock:
            event_lock.set()

    def leave_node(self):
        self._network_interface.leave_node(token=self.token)

    def export_keys(
        self, wait: bool = False, event_lock: threading.Event | None = None
    ) -> dict[str, Any] | None:
        if wait:
            if isinstance(event_lock, threading.Event):
                _event_lock = event_lock
            else:
                _event_lock = threading.Event()
            setattr(self, "__export_keys_container", _event_lock)

        self.management_interface.export_keys()

        if wait:
            if not _event_lock.wait(timeout=3):
                logger.error("timeout: 'Application' failed to export keys")
                delattr(self, "__export_keys_container")
                raise ApplicationError("'export_keys()' failed'")
            ret = getattr(self, "__export_keys_container", None)
            delattr(self, "__export_keys_container")
            return ret
        return None

    def export_keys_handler(self, keys: dict):
        """
        Args:
            keys (dict): Each params defined at `Mesh API`_.

        Todo:
            * Compares the keys that application has with the argument ``keys``
               and updates them. Details on the method will be decided later.

        """
        net_keys = {}
        app_keys = {}
        dev_keys = {}
        logger.debug("NetKeys:")
        if "NetKeys" in keys:
            for net_key in keys["NetKeys"]:
                logger.debug("\tnet index: {}", net_key[0])
                logger.debug("\t\tkey  : {}", bytes(net_key[1]).hex())
                net_keys[net_key[0]] = bytes(net_key[1])
                net_optional = net_key[2]
                if "Phase" in net_optional:
                    logger.debug("\t\tphase: {}", net_optional["Phase"])
                if "OldKey" in net_optional:
                    logger.debug("\t\told  : {}", net_optional["OldKey"])
                if "AppKeys" in net_optional:
                    for app_key in net_optional["AppKeys"]:
                        logger.debug("\t\tapp index: {}", app_key[0])
                        logger.debug("\t\t\tkey  : {}", bytes(app_key[1]).hex())
                        app_keys[app_key[0]] = (net_key[0], bytes(app_key[1]))
                        app_optional = app_key[2]
                        if "OldKey" in app_optional:
                            logger.debug("\t\t\told  : {}", app_optional["OldKey"])
        logger.debug("DeviceKeys:")
        if "DevKeys" in keys:
            for dev_key in keys["DevKeys"]:
                logger.debug("\tdevice unicast: {}", dev_key[0])
                logger.debug("\t\tkey    : {}", bytes(dev_key[1]).hex())
                dev_keys[dev_key[0]] = bytes(dev_key[1])

        event_lock = getattr(self, "__export_keys_container", None)
        if event_lock:
            ret = {"net_keys": net_keys, "app_keys": app_keys, "dev_keys": dev_keys}
            setattr(self, "__export_keys_container", ret)
            event_lock.set()

    def join_complete_handler(self, token: int):
        setattr(self, "__token", token)

        logger.info(
            "Join Complete - Path: {}, UUID: {}, Token: {}",
            self.path,
            self.uuid.hex,
            self.token,
        )

        event_lock = getattr(self, "__import_container", None)
        if event_lock:
            setattr(self, "__import_container", token)
            event_lock.set()

    def join_failed_handler(self):
        logger.warning(
            "Join Failed - Path: {}, UUID: {}",
            self.path,
            self.uuid.hex,
        )

        event_lock = getattr(self, "__import_container", None)
        if event_lock:
            setattr(self, "__import_container", None)
            event_lock.set()

    def get_managed_objects_handler(self) -> dict:
        response = {}
        response[self.path] = self.interface.get_properties()
        for element in self._elements.values():
            response[element.path] = element.interface.get_properties()
        return response

    def setup(self):
        index, key = self.primary_net_key
        self.import_subnet(index, key)
        self.import_remote_node(self.addresses[0], len(self.addresses), self.dev_key)

    def import_subnet(self, index: int, key: bytes):
        self.management_interface.import_subnet(net_index=index, net_key=key)

    def import_app_key(self, bound_net_index: int, app_index: int, app_key: bytes):
        self.management_interface.import_app_key(
            net_index=bound_net_index, app_index=app_index, app_key=app_key
        )

    def import_remote_node(self, address: int, count: int, device_key: bytes):
        self.management_interface.import_remote_node(
            primary=address, count=count, device_key=device_key
        )

    def send(
        self,
        element_path: str,
        destination: int,
        key_index: int,
        data: bytes,
        force_segmented: bool = False,
    ):
        # pylint: disable=too-many-arguments
        self.node_interface.send(
            element_path=element_path,
            destination=destination,
            key_index=key_index,
            force_segmented=force_segmented,
            data=data,
        )

    def dev_key_send(
        self,
        element_path: str,
        destination: int,
        net_index: int,
        data: bytes,
        remote: bool = True,
        force_segmented: bool = False,
    ):
        # pylint: disable=too-many-arguments
        self.node_interface.dev_key_send(
            element_path=element_path,
            destination=destination,
            remote=remote,
            net_index=net_index,
            force_segmented=force_segmented,
            data=data,
        )

    def publish(
        self,
        element_path: str,
        model_id: tuple[int | None, int],
        data: bytes,
        force_segmented: bool = False,
    ):
        # pylint: disable=too-many-arguments
        self.node_interface.publish(
            element_path=element_path,
            model=model_id[1],
            vendor=model_id[0],
            force_segmented=force_segmented,
            data=data,
        )


class ApplicationBuilder:
    """Useful class to build Application simply"""

    def __init__(
        self, application_class: type["Application"], path: str, dbus_module_type: str
    ):
        self.application_class = application_class
        self.path = path
        self.dbus_module_type = dbus_module_type
        self.reset()

    def set_uuid(self, value: _uuid.UUID | str | bytes | int):
        """Set uuid

        Raises:
            ValueError: If value could not be cast to uuid.UUID.
            TypeError: If value is wrong type.

        """
        if isinstance(value, _uuid.UUID):
            pass
        elif isinstance(value, str):
            value = _uuid.UUID(value)
        elif isinstance(value, bytes):
            value = _uuid.UUID(bytes=value)
        elif isinstance(value, int):
            value = _uuid.UUID(int=value)
        else:
            raise TypeError(
                "'value' type must be one of 'uuid.UUID', 'str', 'bytes', 'int'"
            )
        self._instance_attributes["uuid"] = value

    def set_address(self, value: int):
        """Set address

        Raises:
            ValueError: If address is not in the range of 0~4095.
            TypeError: If value is wrong type.

        """
        if not isinstance(value, int):
            raise TypeError("attribute 'address' type is 'int'")
        if not 0 < value < 0x8000:
            raise ValueError(
                "attribute 'address' allow in the range of 0x0001~0x7999, "
                + f"got: 0x{value:X}"
            )
        self._instance_attributes["address"] = value

    def set_dev_key(self, value: bytes):
        """Set device key

        Raises:
            ValueError: If key is not 16-byte length of 'bytes'.
            TypeError: If 'value' is wrong type.

        """
        if not isinstance(value, bytes):
            raise TypeError("key type is 'bytes'")
        if len(value) != 16:
            raise ValueError(f"key must be 16 bytes long, got: {value!r}")
        self._instance_attributes["dev_key"] = value

    def set_primary_net_key(self, value: tuple[int, bytes]):
        """Set primary network key

        Raises:
            ValueError: If key is not 16-byte length of 'bytes' or
                if index is not in range of 0~4095
            TypeError: If value is wrong type.

        """
        if not isinstance(value, tuple):
            raise TypeError("'value' must be tuple[int, bytes]")
        if not isinstance(value[0], int):
            raise TypeError("index must be int")
        if not isinstance(value[1], bytes):
            raise TypeError("key type is 'bytes'")
        if not 0 <= value[0] <= 4095:
            raise ValueError(f"index must be in range of 0~4095, got: {value[0]}")
        if len(value[1]) != 16:
            raise ValueError(f"key must be 16 bytes long, got: {value[1]!r}")
        self._instance_attributes["primary_net_key"] = value

    def set_iv_update(self, value: bool):
        """Set whether IV Index Update is in progress

        Raises:
            TypeError: If value is wrong type.
        """
        if not isinstance(value, bool):
            raise TypeError("attribute 'iv_update' must be bool")
        self._instance_attributes["iv_update"] = value

    def set_key_refresh(self, value: bool):
        """Set whether primary net key's refresh procedure is in progress.

        Raises:
            TypeError: If value is wrong type.
        """
        if not isinstance(value, bool):
            raise TypeError("attribute 'key_refresh' must be bool")
        self._instance_attributes["key_refresh"] = value

    def set_iv_index(self, value: bool):
        """Set current IV Index value

        Raises:
            TypeError: If value is wrong type.
        """
        if not isinstance(value, int):
            raise TypeError("attribute 'iv_index' must be int")
        self._instance_attributes["iv_index"] = value

    def set_token(self, value: int):
        """Set token(64-bit integer)

        Raises:
            TypeError: If value is wrong type.
        """
        if not isinstance(value, int):
            raise TypeError("attribute 'token' must be int")
        self._instance_attributes["token"] = value

    def reset(self):
        self._instance_attributes: dict[str, Any] = {}

    def build(self) -> Optional["Application"]:
        """Build an Application but do not any method.

        Raises:
            AttributeError: If required attributes to create 'Application' are
                missing or if attributes have wrong value.

        Returns:
            Application instance if build succeed, None otherwise.

        """
        try:
            instance = self.application_class(
                self.path, self.dbus_module_type, **self._instance_attributes
            )
        except ApplicationError as e:
            logger.error(f"Application.ApplicationBuilder failed to build: {e}")
            return None

        self.reset()

        return instance

    def build_attach(self) -> Optional["Application"]:
        """Build, attach an Application

        Raises:
            AttributeError: If required attributes to create 'Application' are
                missing or if attributes have wrong value.

        Returns:
            Application instance if build succeed, None otherwise.

        """
        required_attrs = [
            "token",
        ]
        self.__missing_attribute_check(required_attrs, self._instance_attributes)

        instance = self.build()
        if not instance:
            return None

        instance.attach_node(True)

        return instance

    def build_import_attach(self) -> Optional["Application"]:
        """Build, import, attach an Application

        Raises:
            AttributeError: If required attributes to create 'Application' are
                missing or if attributes have wrong value.

        Returns:
            Application instance if build succeed, None otherwise.

        """
        required_attrs = [
            "uuid",
            "dev_key",
            "primary_net_key",
            "iv_update",
            "key_refresh",
            "iv_index",
            "address",
        ]
        self.__missing_attribute_check(required_attrs, self._instance_attributes)

        instance = self.build()
        if not instance:
            return None

        instance.import_node(True)
        instance.attach_node(True)
        instance.setup()

        return instance

    @staticmethod
    def __missing_attribute_check(required_attrs, attributes):
        missing_attrs = [attr for attr in required_attrs if attr not in attributes]
        if missing_attrs:
            raise AttributeError(f"Missing attributes: {', '.join(missing_attrs)}")
