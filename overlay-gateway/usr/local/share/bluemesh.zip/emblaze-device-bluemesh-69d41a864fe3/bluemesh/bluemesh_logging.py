# -*- coding: utf-8 -*-
"""To use logging bluemesh.

It is very simple to make log inside bluemesh module. You can get logs from through two
functions.

Example:
    In order to turn on the log recording function inside bluemesh, a handler must be
    registered. Handler could be added through two ways: ``add_stream_handler`` makes
    handler when you get logs from stream like stdout, and ``add_file_handler`` is used
    to make log file::

        import bluemesh.bluemesh_logging as logging
        logging.addStreamHandler("bluemesh", loglevel="INFO")
        logging.addFileHandler("bluemesh", "bluemesh.log", loglevel="DEBUG",
            logformat="%(asctime)s/%(name)s/%(levelname)s/%(funcName)s/"
                      "process(%(process)d)/thread(%(thread)d)/%(message)s")

    First argument is the module name. Each module hierarchy may looks like this::

        bluemesh
        |   .application
        |   .element
        |   .interface
        |   .models
        |   |   .base
        |   |   .config
        |   |   .general_level
        |   |   ...
        |   .access

    User-defined(vendor) model might need to write logs. ``bluemesh_logging`` uses
    brace({}) formatting unlike traditional logging formatting. But format arguments
    consist of only index arguments. Do not use keywords format, like::

        logger.info("hello {foo}", foo="world")

    Here, an example to add logging for user-defined models::

        import bluemesh.bluemesh_logging as logging
        logger = logging.getLogger("bluemesh.models.user_custom_model")
        logger.info( "You can write log this way: opcode({}): status {}", 0xC005F1, 0)

"""

import logging

_logger = logging.getLogger("bluemesh")
_logger.setLevel(logging.DEBUG)
_logger.propagate = True

_logger.addHandler(logging.NullHandler())
DEFAULT_LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
"""str: logging format if ``logformat`` is not specify when adding logger handler.

You can make formats and find the attributes from `here`_.

.. _here: https://docs.python.org/3/library/logging.html#logrecord-attributes

"""


class _Handlers:
    __next_index: int = 0
    __handlers: dict[int, logging.Handler] = {}

    @classmethod
    def add(cls, handler: logging.Handler) -> int:
        if not isinstance(handler, logging.Handler):
            raise TypeError("'handler' must be 'logging.Handler'")
        index = cls.__next_index
        cls.__handlers[index] = handler
        cls.__next_index += 1
        return index

    @classmethod
    def remove(cls, index: int) -> logging.Handler:
        if not isinstance(index, int):
            raise TypeError("'index' must be 'int'")
        if index not in cls.__handlers:
            raise IndexError("Not listed")
        handler = cls.__handlers[index]
        del cls.__handlers[index]
        return handler


class _FormatString:
    def __init__(self, msg, args):
        self.msg = msg
        self.args = args

    def __str__(self):
        return self.msg.format(*self.args)


class _StyleAdapter(logging.LoggerAdapter):
    def __init__(self, logger, extra=None):
        super().__init__(logger, extra or {})

    def log(self, level, msg, /, *args, **kwargs):
        if self.isEnabledFor(level):
            # pylint: disable=protected-access
            self.logger._log(level, _FormatString(msg, args), (), **kwargs)


def getLogger(name=None) -> logging.LoggerAdapter:
    # pylint: disable=invalid-name
    """To use when getting logger instance. You can find more information by
    `logging.getLogger`_.

    Returns:
        An instance of ``logging.LoggerAdapter``. You can find more information by
        `logging.LoggerAdapter`_ and `logging.Logger`_.

    .. _logging.getLogger:
       https://docs.python.org/3/library/logging.html#logging.getLogger
    .. _logging.LoggerAdapter:
       https://docs.python.org/3/library/logging.html#logging.LoggerAdapter
    .. _logging.Logger: https://docs.python.org/3/library/logging.html#logging.Logger

    """
    return _StyleAdapter(logging.getLogger(name))


def addHandler(
    name: str,
    handler: logging.Handler,
    loglevel: int | str = logging.INFO,
    logformat: logging.Formatter | str | None = None,
) -> int:
    # pylint: disable=invalid-name
    """Add handler easily

    Args:
        name: A module name for printing logs.
        handler: ``logging.Handler`` instance
        loglevel: logging level after severity; DEBUG, INFO, WARN, ERROR, CRITICAL.
        logformat: Logging format to write. If None, this is set
            ``DEFAULT_LOG_FORMAT``.

    Returns:
        int: ``bluemesh``'s handler index to use when removing it.

    """
    if isinstance(loglevel, str):
        loglevel = getattr(logging, loglevel)
    if logformat is None:
        logformat = logging.Formatter(DEFAULT_LOG_FORMAT)
    elif isinstance(logformat, str):
        logformat = logging.Formatter(logformat)
    handler.setLevel(loglevel)
    handler.setFormatter(logformat)
    logging.getLogger(name).addHandler(handler)

    index = _Handlers.add(handler)
    return index


def removeHandler(name: str, index: int):
    # pylint: disable=invalid-name
    """Remove handler easily

    Args:
        name: A module name for printing logs.
        index: ``logging.Handler`` instance

    """
    try:
        handler = _Handlers.remove(index)
    except IndexError as e:
        raise IndexError(e) from e
    logging.getLogger(name).removeHandler(handler)


def addStreamHandler(
    name: str, stream=None, loglevel: int | str = "WARN", logformat=None
) -> int:
    # pylint: disable=invalid-name
    """To use to get logs into stream like console.

    Args:
        name: A module name for printing logs.
        stream: An output stream. When stream is None, it shall print by standard
            output.
        loglevel: logging level after severity; DEBUG, INFO, WARN, ERROR, CRITICAL.
        logformat: Logging format to write. If None, this is set
            ``DEFAULT_LOG_FORMAT``.

    Returns:
        int: ``bluemesh``'s handler index to use when removing it.

    """
    handler = logging.StreamHandler(stream)
    return addHandler(name, handler, loglevel, logformat)


def addFileHandler(
    name: str, file_name: str, loglevel: int | str = "INFO", logformat=None
) -> int:
    # pylint: disable=invalid-name
    """To use to get logs into a file.

    Args:
        name: A module name for printing logs.
        file_name: A logfile path.
        loglevel: logging level after severity; DEBUG, INFO, WARN, ERROR, CRITICAL.
        logformat: Logging format to write. If None, this is set
            ``DEFAULT_LOG_FORMAT``.

    Returns:
        int: ``bluemesh``'s handler index to use when removing it.

    """
    handler = logging.FileHandler(file_name)
    return addHandler(name, handler, loglevel, logformat)
