# -*- coding: utf-8 -*-
"""Abstraction Class for BlueZ Interface."""


class NetworkInterfaceABC:
    """NetworkInterfaceABC."""

    def attach_node(self, app_root: str, token: int):
        """attach_node.

        Args:
            app_root (str): app_root
            token (int): token
        """
        raise NotImplementedError

    def leave_node(self, token: int):
        """leave_node.

        Args:
            token (int): token
        """
        raise NotImplementedError

    def import_node(
        self,
        app_root: str,
        uuid: bytes,
        dev_key: bytes,
        net_key: bytes,
        net_index: int,
        iv_update: bool,
        key_refresh: bool,
        iv_index: int,
        unicast: int,
    ):
        # pylint: disable=too-many-arguments
        """import_node.

        Args:
            app_root (str): app_root
            uuid (bytes): uuid
            dev_key (bytes): dev_key
            net_key (bytes): net_key
            net_index (int): net_index
            iv_update (bool): iv_update
            key_refresh (bool): key_refresh
            iv_index (int): iv_index
            unicast (int): unicast
        """
        raise NotImplementedError


class NodeInterfaceABC:
    """NodeInterfaceABC."""

    def send(
        self,
        element_path: str,
        destination: int,
        key_index: int,
        force_segmented: bool,
        data: bytes,
    ):
        # pylint: disable=too-many-arguments
        """send.

        Args:
            element_path (str): element_path
            destination (int): destination
            key_index (int): key_index
            force_segmented (bool): force_segmented
            data (bytes): data
        """
        raise NotImplementedError

    def dev_key_send(
        self,
        element_path: str,
        destination: int,
        remote: bool,
        net_index: int,
        force_segmented: bool,
        data: bytes,
    ):
        # pylint: disable=too-many-arguments
        """dev_key_send.

        Args:
            element_path (str): element_path
            destination (int): destination
            remote (bool): remote
            net_index (int): net_index
            force_segmented (bool): force_segmented
            data (bytes): data
        """
        raise NotImplementedError

    def publish(
        self,
        element_path: str,
        model: int,
        vendor: int | None,
        force_segmented: bool,
        data: bytes,
    ):
        # pylint: disable=too-many-arguments
        """publish.

        Args:
            element_path (str): element_path
            model (int): model
            vendor (int | None): vendor
            force_segmented (bool): force_segmented
            data (bytes): data
        """
        raise NotImplementedError


class ManagementInterfaceABC:
    """ManagementInterfaceABC."""

    def import_subnet(self, net_index: int, net_key: bytes):
        """import_subnet.

        Args:
            net_index (int): net_index
            net_key (bytes): net_key
        """
        raise NotImplementedError

    def import_app_key(self, net_index: int, app_index: int, app_key: bytes):
        """import_app_key.

        Args:
            net_index (int): net_index
            app_index (int): app_index
            app_key (bytes): app_key
        """
        raise NotImplementedError

    def import_remote_node(self, primary: int, count: int, device_key: bytes):
        """import_remote_node.

        Args:
            primary (int): primary
            count (int): count
            device_key (bytes): device_key
        """
        raise NotImplementedError

    def export_keys(self):
        """export_keys."""
        raise NotImplementedError


class ApplicationInterfaceABC:
    """ApplicationInterfaceABC."""

    def get_properties(self):
        """get_properties."""
        raise NotImplementedError


class ElementInterfaceABC:
    """ElementInterfaceABC."""

    def get_properties(self):
        """get_properties."""
        raise NotImplementedError


class PropertyInterfaceABC:
    """PropertyInterfaceABC."""

    def get(self, interface, prop):
        """get_properties."""
        raise NotImplementedError

    def get_all(self, interface):
        """get_all_properties."""
        raise NotImplementedError

    def set(self, interface, prop, value):
        """set_properties."""
        raise NotImplementedError
