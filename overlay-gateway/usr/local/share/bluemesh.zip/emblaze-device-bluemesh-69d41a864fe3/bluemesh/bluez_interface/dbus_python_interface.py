# -*- coding: utf-8 -*-
# pylint: disable=too-many-arguments
"""Bluemesh dbus Interface Module through dbus-python.

This module supports :class:`bluemesh.Application` to communicates with BlueZ
`Mesh API`_ through dbus.

.. _Mesh API:
   https://git.kernel.org/pub/scm/bluetooth/bluez.git/tree/doc/mesh-api.txt

Todo:
    * Add ApplicationInterface, ElementInterface, DbusInterface
    * Logging

"""

from typing import Any, Union

import dbus  # pylint: disable=import-error
import dbus.service  # pylint: disable=import-error
from dbus.mainloop.glib import DBusGMainLoop  # pylint: disable=import-error
from gi.repository import GLib  # pylint: disable=import-error

import bluemesh.bluemesh_logging as logging
from bluemesh.bluez_interface.base import (
    ApplicationInterfaceABC,
    ElementInterfaceABC,
    ManagementInterfaceABC,
    NetworkInterfaceABC,
    NodeInterfaceABC,
    PropertyInterfaceABC,
)

logger = logging.getLogger("bluemesh.bluez_interface.dbus_python_interface")


def get_loop():
    DBusGMainLoop(set_as_default=True)
    mainloop = GLib.MainLoop()
    return mainloop


def run_loop(loop: GLib.MainLoop):
    loop.run()


def stop_loop(loop: GLib.MainLoop):
    loop.quit()


APPLICATION_INTERFACE_NAME = "org.bluez.mesh.Application1"
ELEMENT_INTERFACE_NAME = "org.bluez.mesh.Element1"
DBUS_INTERFACE_NAME = "org.freedesktop.DBus.ObjectManager"


def unwrap(item):
    # pylint: disable=too-many-return-statements
    if isinstance(item, (dbus.Boolean, bool)):
        return bool(item)
    elif isinstance(
        item,
        (
            dbus.Byte,
            dbus.UInt16,
            dbus.Int16,
            dbus.UInt32,
            dbus.Int32,
            dbus.UInt64,
            dbus.Int64,
            int,
        ),
    ):
        return int(item)
    elif isinstance(item, (dbus.ObjectPath, dbus.String, str)):
        return str(item)
    elif isinstance(item, (dbus.Array, list)):
        return [unwrap(x) for x in item]
    elif isinstance(item, (dbus.Struct, tuple)):
        return tuple(unwrap(x) for x in item)
    elif isinstance(item, (dbus.Dictionary, dict)):
        return {unwrap(x): unwrap(y) for x, y in item.items()}
    else:
        logger.error("Dictionary item not handled: {}", type(item))

    return item


class Interface:
    """Interface

    Attributes:
        _interface (:obj:`dbus.Interface`): A dbus's interface. This is used to call
            BlueZ API through dbus.
        _application (:obj:`bluemesh.Application`): An responsible application for
            dbus API call. `_application` needs to have call-back methods which receive
            returns of BlueZ APIs.

    """

    SERVICE_NAME: str = ""
    OBJECT_PATH: str = ""
    INTERFACE_NAME: str = ""

    def __init__(self, application):
        self.bus = dbus.SystemBus()
        if self.SERVICE_NAME != "":
            self._proxy_object_init()

        self._application = application

    def _proxy_object_init(self):
        assert "" not in (
            self.SERVICE_NAME,
            self.OBJECT_PATH,
            self.INTERFACE_NAME,
        ), "Could not connect proxy object's interface"
        self._interface = dbus.Interface(
            self.bus.get_object(self.SERVICE_NAME, self.OBJECT_PATH),
            self.INTERFACE_NAME,
        )


class NetworkInterface(Interface, NetworkInterfaceABC):
    """BlueZ API - Network1 interface

    Note:
        `Mesh API`_ informs methods with arguments.

    """

    SERVICE_NAME = "org.bluez.mesh"
    OBJECT_PATH = "/org/bluez/mesh"
    INTERFACE_NAME = "org.bluez.mesh.Network1"

    def attach_node(self, app_root: str, token: int):
        """Attach node on BlueZ service."""
        self._interface.Attach(
            app_root,
            token,
            reply_handler=self.attach_node_reply_handler,
            error_handler=self.attach_node_error_handler,
        )

    def attach_node_reply_handler(self, node: str, configuration: dbus.Array):
        logger.debug("Attach Success")
        self._application.attach_node_handler(node, unwrap(configuration))

    def attach_node_error_handler(self, error):
        logger.warning("Attach Failed: {}", error)

    def leave_node(self, token: int):
        """Leave node from BlueZ service and erase from databases."""
        self._interface.Leave(
            token,
            reply_handler=self.leave_node_reply_handler,
            error_handler=self.leave_node_error_handler,
        )

    def leave_node_reply_handler(self):
        logger.debug("Leave Success")

    def leave_node_error_handler(self, error):
        logger.warning("Leave Failed: {}", error)

    def import_node(
        self,
        app_root: str,
        uuid: bytes,
        dev_key: bytes,
        net_key: bytes,
        net_index: int,
        iv_update: bool,
        key_refresh: bool,
        iv_index: int,
        unicast: int,
    ):
        """Import node in BlueZ database, which is already provisioned."""

        flags = {"IvUpdate": iv_update, "KeyRefresh": key_refresh}

        self._interface.Import(
            app_root,
            uuid,
            dev_key,
            net_key,
            net_index,
            dbus.Dictionary(flags, signature="sv", variant_level=1),
            iv_index,
            unicast,
            reply_handler=self.import_node_reply_handler,
            error_handler=self.import_node_error_handler,
        )

    def import_node_reply_handler(self):
        logger.debug("Import Success")

    def import_node_error_handler(self, error):
        logger.warning("Import Failed: {}", error)


class PropertyInterface(Interface, PropertyInterfaceABC):
    """BlueZ API - Property interface

    Note:
        `Mesh API`_ informs methods with arguments.

    """

    SERVICE_NAME = "org.bluez.mesh"
    INTERFACE_NAME = "org.freedesktop.DBus.Properties"

    def __init__(self, application, object_path):
        # pylint: disable=invalid-name
        self.OBJECT_PATH = object_path
        super().__init__(application)

    def get(self, interface: Interface, prop: str) -> Any:
        return unwrap(self._interface.Get(interface.INTERFACE_NAME, prop))

    def get_all(self, interface: Interface) -> dict[str, Any]:
        return unwrap(self._interface.GetAll(interface.INTERFACE_NAME))

    def set(self, interface: Interface, prop: str, value: Any) -> Any:
        self._interface.Set(interface.INTERFACE_NAME, prop, value)


class NodeInterface(Interface, NodeInterfaceABC):
    """BlueZ API - Node1 interface

    Note:
        `Mesh API`_ informs methods with arguments.

    """

    SERVICE_NAME = "org.bluez.mesh"
    INTERFACE_NAME = "org.bluez.mesh.Node1"

    def __init__(self, application, object_path):
        # pylint: disable=invalid-name
        self.OBJECT_PATH = object_path
        super().__init__(application)

    def send(
        self,
        element_path: str,
        destination: int,
        key_index: int,
        force_segmented: bool,
        data: bytes,
    ):
        """Send Bluetooth mesh message by an element with application key.

        Almost SIG/Vendor models use this method in order to send messages to unicast
        or group addresses.

        """
        options = {"ForceSegmented": force_segmented}
        self._interface.Send(
            element_path,
            destination,
            key_index,
            options,
            data,
            reply_handler=self.send_reply_handler,
            error_handler=self.send_error_handler,
        )

    def send_reply_handler(self):
        logger.debug("Send Success")

    def send_error_handler(self, error):
        logger.warning("Send Failed: {}", error)

    def dev_key_send(
        self,
        element_path: str,
        destination: int,
        remote: bool,
        net_index: int,
        force_segmented: bool,
        data: bytes,
    ):
        """Send Bluetooth mesh message by an element with device key encoded destination
        address.

        Particular models (like ConfigurationClient) use this method in order to send
        messages to specific nodes.

        """
        options = {"ForceSegmented": force_segmented}
        self._interface.DevKeySend(
            element_path,
            destination,
            remote,
            net_index,
            options,
            data,
            reply_handler=self.dev_key_send_reply_handler,
            error_handler=self.dev_key_send_error_handler,
        )

    def dev_key_send_reply_handler(self):
        logger.debug("DevKeySend Success")

    def dev_key_send_error_handler(self, error):
        logger.warning("DevKeySend Failed: {}", error)

    def publish(
        self,
        element_path: str,
        model: int,
        vendor: int | None,
        force_segmented: bool,
        data: bytes,
    ):
        """Send a Bluetooth mesh publication message by an local model.

        Since only one Publish record may exist per element-model, the destination and
        key_index are obtained from the Publication record.

        """
        options: dict[str, bool | int] = {"ForceSegmented": force_segmented}
        if vendor:
            options["Vendor"] = vendor
        self._interface.Publish(
            element_path,
            model,
            options,
            data,
            reply_handler=self.publish_reply_handler,
            error_handler=self.publish_error_handler,
        )

    def publish_reply_handler(self):
        logger.debug("Publish Success")

    def publish_error_handler(self, error):
        logger.warning("Publish Failed: {}", error)

    def set_sequence_number(self, seq_nr: int):
        """Update sequence number to specific value"""
        self._interface.SetSequenceNumber(
            seq_nr,
            reply_handler=self.set_sequence_number_reply_handler,
            error_handler=self.set_sequence_number_error_handler,
        )

    def set_sequence_number_reply_handler(self):
        logger.debug("Set Sequence Number Success")

    def set_sequence_number_error_handler(self, error):
        logger.warning("Set Sequence Number Failed: {}", error)


class ManagementInterface(Interface, ManagementInterfaceABC):
    """BlueZ API - Management1 interface

    Note:
        `Mesh API`_ informs methods with arguments.

    """

    SERVICE_NAME = "org.bluez.mesh"
    INTERFACE_NAME = "org.bluez.mesh.Management1"

    def __init__(self, application, object_path):
        # pylint: disable=invalid-name
        self.OBJECT_PATH = object_path
        super().__init__(application)

    def import_subnet(self, net_index: int, net_key: bytes):
        """Import subnet key to database"""
        self._interface.ImportSubnet(
            net_index,
            net_key,
            reply_handler=self.import_subnet_reply_handler,
            error_handler=self.import_subnet_error_handler,
        )

    def import_subnet_reply_handler(self):
        logger.debug("ImportSubnet Success")

    def import_subnet_error_handler(self, error):
        logger.warning("ImportSubnet Failed: {}", error)

    def import_app_key(self, net_index: int, app_index: int, app_key: bytes):
        """Import application key to database"""
        self._interface.ImportAppKey(
            net_index,
            app_index,
            app_key,
            reply_handler=self.import_app_key_reply_handler,
            error_handler=self.import_app_key_error_handler,
        )

    def import_app_key_reply_handler(self):
        logger.debug("ImportAppKey Success")

    def import_app_key_error_handler(self, error):
        logger.warning("ImportAppKey Failed: {}", error)

    def import_remote_node(self, primary: int, count: int, device_key: bytes):
        """Import device key to database"""
        self._interface.ImportRemoteNode(
            primary,
            count,
            device_key,
            reply_handler=self.import_remote_node_reply_handler,
            error_handler=self.import_remote_node_error_handler,
        )

    def import_remote_node_reply_handler(self):
        logger.debug("ImportRemoteNode Success")

    def import_remote_node_error_handler(self, error):
        logger.warning("ImportRemoteNode Failed: {}", error)

    def export_keys(self):
        """Export all of keys from database"""
        self._interface.ExportKeys(
            reply_handler=self.export_keys_reply_handler,
            error_handler=self.export_keys_error_handler,
        )

    def export_keys_reply_handler(self, keys: dbus.Dictionary):
        logger.debug("ExportKeys Success")
        self._application.export_keys_handler(unwrap(keys))

    def export_keys_error_handler(self, error):
        logger.warning("ExportKeys Failed: {}", error)


class ApplicationInterface(Interface, dbus.service.Object, ApplicationInterfaceABC):
    # pylint: disable=invalid-name
    """BlueZ API - Application1 interface

    Note:
        `Mesh API`_ informs methods and properties.

    """
    INTERFACE_NAME = APPLICATION_INTERFACE_NAME

    def __init__(self, application, object_path):
        self.OBJECT_PATH = object_path
        Interface.__init__(self, application)
        dbus.service.Object.__init__(self, self.bus, self.OBJECT_PATH)

    @dbus.service.method(DBUS_INTERFACE_NAME, out_signature="a{oa{sa{sv}}}")
    def GetManagedObjects(self):
        return self._application.get_managed_objects_handler()

    @dbus.service.method(APPLICATION_INTERFACE_NAME, in_signature="t", out_signature="")
    def JoinComplete(self, token: dbus.UInt64):
        token = unwrap(token)
        logger.debug("JoinComplete {0}(0x{0:x})", token)
        self._application.join_complete_handler(token)

    @dbus.service.method(APPLICATION_INTERFACE_NAME, in_signature="s", out_signature="")
    def JoinFailed(self, reason: dbus.String):
        logger.warning("JoinFailed {}", reason)
        self._application.join_failed_handler()

    @property
    def CompanyID(self) -> dbus.UInt16:
        return dbus.UInt16(self._application.COMPANY_ID)

    @property
    def ProductID(self) -> dbus.UInt16:
        return dbus.UInt16(self._application.PRODUCT_ID)

    @property
    def VersionID(self) -> dbus.UInt16:
        return dbus.UInt16(self._application.VERSION_ID)

    @property
    def CRPL(self) -> dbus.UInt16:
        crpl = getattr(self._application, "CRPL", None)
        if not crpl:
            raise AttributeError(
                "module 'ApplicationInterface' has no attribute 'CRPL'"
            )
        return dbus.UInt16(crpl)

    def get_properties(self) -> dict:
        properties = {
            "CompanyID": self.CompanyID,
            "ProductID": self.ProductID,
            "VersionID": self.VersionID,
        }
        try:
            crpl = self.CRPL
            properties["CRPL"] = crpl
        except AttributeError:
            pass
        return {self.INTERFACE_NAME: properties}


class ElementInterface(Interface, dbus.service.Object, ElementInterfaceABC):
    # pylint: disable=invalid-name
    """BlueZ API - Element1 Interface

    Note:
        `Mesh API`_ informs methods and properties.

    """
    INTERFACE_NAME = ELEMENT_INTERFACE_NAME

    def __init__(self, element, object_path):
        self.OBJECT_PATH = object_path
        Interface.__init__(self, element)
        dbus.service.Object.__init__(self, self.bus, self.OBJECT_PATH)

    @dbus.service.method(ELEMENT_INTERFACE_NAME, in_signature="qqvay", out_signature="")
    def MessageReceived(
        self,
        source: dbus.UInt16,
        key_index: dbus.UInt16,
        destination: Union[dbus.UInt16, dbus.Array],
        data: dbus.Array,
    ):
        # pylint: disable=broad-except
        try:
            logger.debug(
                "Message Received on Element {:02x}, src={:04x}",
                unwrap(self.Index),
                unwrap(source),
            )

            self._application.message_received_handler(
                *unwrap((source, key_index, destination, data))
            )
        except Exception as e:
            logger.error("error: {}", e)

    @dbus.service.method(ELEMENT_INTERFACE_NAME, in_signature="qbqay", out_signature="")
    def DevKeyMessageReceived(
        self,
        source: dbus.UInt16,
        remote: dbus.Boolean,
        net_index: dbus.UInt16,
        data: dbus.Array,
    ):
        # pylint: disable=broad-except
        try:
            logger.debug(
                "Dev Key Message Received on Element {:02x}, src={:04x}",
                unwrap(self.Index),
                unwrap(source),
            )

            self._application.dev_key_message_received_handler(
                *unwrap((source, remote, net_index, data))
            )
        except Exception as e:
            logger.error("error: {}", e)

    @dbus.service.method(
        ELEMENT_INTERFACE_NAME, in_signature="qa{sv}", out_signature=""
    )
    def UpdateModelConfiguration(self, model_id: dbus.UInt16, config: dbus.Dictionary):
        self._application.update_model_config_handler(
            vendor_assigned_model_id=unwrap(model_id), config=unwrap(config)
        )

    @property
    def Index(self) -> dbus.Byte:
        return dbus.Byte(self._application.index)

    @property
    def Models(self) -> dbus.Array:
        return dbus.Array(self._application.models, signature="(qa{sv})")

    @property
    def VendorModels(self) -> dbus.Array:
        return dbus.Array(self._application.vendor_models, signature="(qqa{sv})")

    def get_properties(self) -> dict:
        properties = {}
        properties["Index"] = self.Index
        properties["Models"] = self.Models
        properties["VendorModels"] = self.VendorModels
        return {self.INTERFACE_NAME: properties}
