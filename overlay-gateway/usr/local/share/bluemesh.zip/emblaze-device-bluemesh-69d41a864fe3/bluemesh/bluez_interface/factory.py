# -*- coding: utf-8 -*-
"""The Factory for BlueZ Interface."""
import threading

import bluemesh.bluemesh_logging as logging
from bluemesh.bluez_interface.base import (
    ApplicationInterfaceABC,
    ElementInterfaceABC,
    ManagementInterfaceABC,
    NetworkInterfaceABC,
    NodeInterfaceABC,
    PropertyInterfaceABC,
)

logger = logging.getLogger("bluemesh.bluez_interface.factory")


class BlueZInterfaceFactory:
    """BlueZInterfaceFactory."""

    def __init__(self, dbus_module_type: str):
        # pylint: disable=import-outside-toplevel
        self.dbus_module_type = dbus_module_type
        if dbus_module_type == "dbus-python":
            import bluemesh.bluez_interface.dbus_python_interface

            self.module = bluemesh.bluez_interface.dbus_python_interface

            self.loop = self.module.get_loop()
            self.thread = threading.Thread(
                target=self.module.run_loop, args=(self.loop,)
            )
            self.thread.daemon = True
            self.thread.start()

            logger.info(
                f"{dbus_module_type} type is selected for communication with BlueZ"
            )
        else:
            raise ImportError(f"{dbus_module_type} is unknown module")

    def __del__(self):
        if self.dbus_module_type == "dbus-python":
            self.module.stop_loop(self.loop)
            self.thread.join()

    def create_network_interface(self, *args, **kwargs) -> NetworkInterfaceABC:
        """create_network_interface.

        Args:
            args:
            kwargs:

        Returns:
            NetworkInterfaceABC:
        """
        return self.module.NetworkInterface(*args, **kwargs)

    def create_node_interface(self, *args, **kwargs) -> NodeInterfaceABC:
        """create_node_interface.

        Args:
            args:
            kwargs:

        Returns:
            NodeInterfaceABC:
        """
        return self.module.NodeInterface(*args, **kwargs)

    def create_management_interface(self, *args, **kwargs) -> ManagementInterfaceABC:
        """create_management_interface.

        Args:
            args:
            kwargs:

        Returns:
            ManagementInterfaceABC:
        """
        return self.module.ManagementInterface(*args, **kwargs)

    def create_application_interface(self, *args, **kwargs) -> ApplicationInterfaceABC:
        """create_application_interface.

        Args:
            args:
            kwargs:

        Returns:
            ApplicationInterfaceABC:
        """
        return self.module.ApplicationInterface(*args, **kwargs)

    def create_element_interface(self, *args, **kwargs) -> ElementInterfaceABC:
        """create_element_interface.

        Args:
            args:
            kwargs:

        Returns:
            ElementInterfaceABC:
        """
        return self.module.ElementInterface(*args, **kwargs)

    def create_property_interface(self, *args, **kwargs) -> PropertyInterfaceABC:
        """create_property_interface.

        Args:
            args:
            kwargs:

        Returns:
            PropertyInterfaceABC:
        """
        return self.module.PropertyInterface(*args, **kwargs)
