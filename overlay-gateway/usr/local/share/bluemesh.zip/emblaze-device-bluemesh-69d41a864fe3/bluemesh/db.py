# -*- coding: utf-8 -*-
# pylint: disable=invalid-name,too-many-arguments,too-many-locals,
# pylint: disable=too-many-instance-attributes
"""Bluemesh Database Module"""
import datetime
import json
import os
import uuid

import jsonschema

import bluemesh.bluemesh_logging as logging

logger = logging.getLogger("bluemesh.db")

SCHEMA_FILE = os.path.join(os.path.dirname(__file__), "cdb-schema.json")


class CDBObject:
    """CDBObject Type"""

    def _to_json_extra(self, key, attr):
        # pylint: disable=unused-argument
        return NotImplemented

    def __to_obj(self, attr, key) -> object:
        to_json_method = getattr(attr, "to_obj", None)
        if callable(to_json_method):
            ret = attr.to_obj()
        else:
            ret = getattr(self, "_to_json_extra")(key, attr)
            if ret == NotImplemented:
                ret = attr
        return ret

    def to_obj(self) -> dict:
        ret: dict = {}
        for key in self.__dict__:
            if key.startswith("_"):
                continue
            attributes = getattr(self, key)
            if isinstance(attributes, list):
                ret[key] = []
                for attr in attributes:
                    ret[key].append(self.__to_obj(attr, key))
            else:
                ret[key] = self.__to_obj(attributes, key)
        return ret


class Version:
    """The type of Version.

    Versioning follow `semantic versioning`_

    .. _semantic versioning: https://semver.org/

    """

    def __init__(self, version: str):
        self.major, self.minor, self.patch = map(int, version.split("."))

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}.{self.patch}"

    def to_obj(self) -> str:
        return str(self)


class Timestamp:
    """The type of Timestamp."""

    def __init__(self, timestamp: str):
        self.datetime = datetime.datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S%z")

    def __add__(self, other: int) -> "Timestamp":
        return Timestamp(
            (self.datetime + datetime.timedelta(seconds=other)).isoformat(
                timespec="seconds"
            )
        )

    def __sub__(self, other: int) -> "Timestamp":
        return Timestamp(
            (self.datetime - datetime.timedelta(seconds=other)).isoformat(
                timespec="seconds"
            )
        )

    def __lt__(self, other: int) -> bool:
        return int(self) < other

    def __le__(self, other: int) -> bool:
        return int(self) <= other

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Timestamp):
            return int(self) == int(other)
        if isinstance(other, int):
            return int(self) == other
        raise ValueError(
            "Incomparable value. It should be an integer or a Timestamp object"
        )

    def __ne__(self, other: object) -> bool:
        if isinstance(other, Timestamp):
            return int(self) != int(other)
        if isinstance(other, int):
            return int(self) != other
        raise ValueError(
            "Incomparable value. It should be an integer or a Timestamp object"
        )

    def __gt__(self, other: int) -> bool:
        return int(self) > other

    def __ge__(self, other: int) -> bool:
        return int(self) >= other

    def __int__(self) -> int:
        return int(self.datetime.timestamp())

    def __str__(self) -> str:
        return self.datetime.isoformat(timespec="seconds")

    def to_obj(self) -> str:
        return str(self)

    def __format__(self, formatstr: str) -> str:
        if formatstr == "short":
            return self.datetime.strftime("%y%m%d_%H%M%S")
        return str(self)


class AddressRange(CDBObject):
    """The type of AddressRange."""

    def __init__(self, *, lowAddress: str, highAddress: str):
        self.lowAddress = int(lowAddress, base=16)
        self.highAddress = int(highAddress, base=16)

    def _to_json_extra(self, key, attr):
        if key in ("lowAddress", "highAddress"):
            return f"{attr:04X}"
        return super()._to_json_extra(key, attr)


class SceneRange(CDBObject):
    """The type of SceneRange."""

    def __init__(self, *, firstScene: str, lastScene: str):
        self.firstScene = int(firstScene, base=16)
        self.lastScene = int(lastScene, base=16)

    def _to_json_extra(self, key, attr):
        if key in ("firstScene", "lastScene"):
            return f"{attr:04X}"
        return super()._to_json_extra(key, attr)


class Provisioner(CDBObject):
    """The type of Provisioner."""

    def __init__(
        self,
        *,
        provisionerName: str,
        UUID: str,
        allocatedUnicastRange: list[dict],
        allocatedGroupRange: list[dict],
        allocatedSceneRange: list[dict],
    ):
        self.provisionerName = provisionerName
        self.UUID: uuid.UUID = uuid.UUID(UUID)
        self.allocatedUnicastRange = [
            AddressRange(**addressRange) for addressRange in allocatedUnicastRange
        ]
        self.allocatedGroupRange = [
            AddressRange(**addressRange) for addressRange in allocatedGroupRange
        ]
        self.allocatedSceneRange = [
            SceneRange(**sceneRange) for sceneRange in allocatedSceneRange
        ]

    def _to_json_extra(self, key, attr):
        if key == "UUID":
            return str(attr)
        return super()._to_json_extra(key, attr)


class Key(CDBObject):
    """The type of Key."""

    def __init__(
        self,
        *,
        name: str,
        index: int,
        key: str,
        oldKey: str | None,
    ):
        self.name = name
        self.index = index
        self.key = bytes.fromhex(key)
        if oldKey is not None:
            self.oldKey = bytes.fromhex(oldKey)

    def _to_json_extra(self, key, attr):
        if key in ("key", "oldKey"):
            return attr.hex()
        return super()._to_json_extra(key, attr)


class NetworkKey(Key):
    """The type of NetworkKey."""

    def __init__(
        self,
        *,
        name: str,
        index: int,
        phase: int,
        key: str,
        minSecurity: str,
        timestamp: str,
        oldKey: str | None = None,
    ):
        super().__init__(name=name, index=index, key=key, oldKey=oldKey)
        self.phase = phase
        self.minSecurity = minSecurity
        self.timestamp = Timestamp(timestamp)


class ApplicationKey(Key):
    """The type of ApplicationKey."""

    def __init__(
        self,
        *,
        name: str,
        index: int,
        boundNetKey: int,
        key: str,
        oldKey: str | None = None,
    ):
        super().__init__(name=name, index=index, key=key, oldKey=oldKey)
        self.boundNetKey = boundNetKey


class NodeKey(CDBObject):
    """The type of NodeKey."""

    def __init__(self, *, index: int, updated: bool):
        self.index = index
        self.updated = updated


class Features(CDBObject):
    """The type of Features"""

    def __init__(self, *, relay: int, proxy: int, lowPower: int, friend: int):
        self.relay = self.__decode(relay)
        self.proxy = self.__decode(proxy)
        self.lowPower = self.__decode(lowPower)
        self.friend = self.__decode(friend)

    def __decode(self, x) -> str:
        if x == 0:
            return "disabled"
        elif x == 1:
            return "enabled"
        else:
            return "unsupported"

    def _to_json_extra(self, key, attr):
        if key in ("relay", "proxy", "lowPower", "friend"):
            if attr == "disabled":
                return 0
            elif attr == "enabled":
                return 1
            else:
                return 2
        return super()._to_json_extra(key, attr)


class PublishPeriod(CDBObject):
    """The type of PublishPeriod."""

    def __init__(self, *, numberOfSteps: int, resolution: int):
        #  self.period = numberOfSteps * resolution
        self.numberOfSteps = numberOfSteps
        self.resolution = resolution


class Retransmit(CDBObject):
    """The type of Retransmit."""

    def __init__(self, *, count: int, interval: int):
        self.count = count
        self.interval = interval


class Publish(CDBObject):
    """The type of Publish."""

    def __init__(
        self,
        *,
        address: str,
        index: int,
        ttl: int,
        period: dict,
        credentials: int,
        retransmit: dict,
    ):
        self.address = (
            int(address, base=16) if len(address) == 4 else uuid.UUID(address)
        )
        self.index = index
        self.ttl = ttl
        self.period = PublishPeriod(**period)
        self.credentials = credentials
        self.retransmit = Retransmit(**retransmit)

    def _to_json_extra(self, key, attr):
        if key == "address":
            if isinstance(attr, int):
                return f"{attr:04X}"
            else:
                return attr.hex
        return super()._to_json_extra(key, attr)


class Model(CDBObject):
    """The type of Model."""

    def __init__(
        self,
        *,
        modelId: str,
        subscribe: list[str],
        bind: list[int],
        publish: dict | None = None,
    ):
        self.modelId = int(modelId, base=16)
        self.subscribe = [
            int(sub, base=16) if len(sub) == 4 else uuid.UUID(sub) for sub in subscribe
        ]
        if publish is not None:
            self.publish = Publish(**publish)
        self.bind = bind

    def _to_json_extra(self, key, attr):
        if key == "modelId":
            if attr > 0xFFFF:
                return f"{attr:08X}"
            else:
                return f"{attr:04X}"
        elif key == "subscribe":
            if isinstance(attr, int):
                return f"{attr:04X}"
            else:
                return attr.hex
        return super()._to_json_extra(key, attr)


class Element(CDBObject):
    """The type of Element."""

    def __init__(
        self, *, index: int, location: str, models: list[dict], name: str | None = None
    ):
        if name is not None:
            self.name = name
        self.index = index
        self.location = int(location, base=16)
        self.models = [Model(**model) for model in models]

        # fast search
        self.__models = {model.modelId: model for model in self.models}

    def get_model(self, model_id: int) -> Model | None:
        return self.__models.get(model_id)

    def _to_json_extra(self, key, attr):
        if key == "location":
            return f"{attr:04X}"
        return super()._to_json_extra(key, attr)


class HeartbeatPublication(CDBObject):
    """The type of HeartbeatPublication."""

    def __init__(
        self, *, address: str, period: int, ttl: int, index: int, features: list[str]
    ):
        self.address = int(address, base=16)
        self.period = period
        self.ttl = ttl
        self.index = index
        self.features = features

    def _to_json_extra(self, key, attr):
        if key == "address":
            return f"{attr:04X}"
        return super()._to_json_extra(key, attr)


class HeartbeatSubscription(CDBObject):
    """The type of HeartbeatSubscription."""

    def __init__(self, *, source: str, destination: str):
        self.source = int(source, base=16)
        self.destination = int(destination, base=16)

    def _to_json_extra(self, key, attr):
        if key in ("source", "destination"):
            return f"{attr:04X}"
        return super()._to_json_extra(key, attr)


class Node(CDBObject):
    """The type of Node."""

    def __init__(
        self,
        *,
        UUID: str,
        unicastAddress: str,
        security: str,
        netKeys: list[dict],
        configComplete: bool,
        appKeys: list[dict],
        elements: list[dict],
        excluded: bool,
        deviceKey: str | None = None,
        name: str | None = None,
        cid: str | None = None,
        pid: str | None = None,
        vid: str | None = None,
        crpl: str | None = None,
        features: dict | None = None,
        secureNetworkBeacon: bool | None = None,
        defaultTTL: int | None = None,
        networkTransmit: dict | None = None,
        relayRetransmit: dict | None = None,
        heartbeatPub: dict | None = None,
        heartbeatSub: dict | None = None,
    ):
        # pylint: disable=too-many-branches
        self.UUID = uuid.UUID(UUID)
        self.unicastAddress = int(unicastAddress, base=16)
        if deviceKey is not None:
            self.deviceKey = bytes.fromhex(deviceKey)
        self.security = security
        self.netKeys = [NodeKey(**netKey) for netKey in netKeys]
        self.configComplete = configComplete
        if name is not None:
            self.name = name
        if cid is not None:
            self.cid = int(cid, base=16)
        if pid is not None:
            self.pid = int(pid, base=16)
        if vid is not None:
            self.vid = int(vid, base=16)
        if crpl is not None:
            self.crpl = int(crpl, base=16)
        if features is not None:
            self.features = Features(**features)
        if secureNetworkBeacon is not None:
            self.secureNetworkBeacon = secureNetworkBeacon
        if defaultTTL is not None:
            self.defaultTTL = defaultTTL
        if networkTransmit is not None:
            self.networkTransmit = Retransmit(**networkTransmit)
        if relayRetransmit is not None:
            self.relayRetransmit = Retransmit(**relayRetransmit)
        self.appKeys = [NodeKey(**appKey) for appKey in appKeys]
        self.elements = [Element(**element) for element in elements]
        self.excluded = excluded
        if heartbeatPub is not None:
            self.heartbeatPub = HeartbeatPublication(**heartbeatPub)
        if heartbeatSub is not None:
            self.heartbeatSub = HeartbeatSubscription(**heartbeatSub)

        # fast search
        self.__netKeys = {netKey.index: netKey for netKey in self.netKeys}
        self.__appKeys = {appKey.index: appKey for appKey in self.appKeys}
        self.__elements = {element.index: element for element in self.elements}

    def get_net_key(self, index: int) -> NodeKey | None:
        return self.__netKeys.get(index)

    def get_app_key(self, index: int) -> NodeKey | None:
        return self.__appKeys.get(index)

    def get_element(self, index: int) -> Element | None:
        return self.__elements.get(index)

    def _to_json_extra(self, key, attr):
        if key == "deviceKey":
            return attr.hex()
        if key == "UUID":
            return str(attr)
        if key in ("unicastAddress", "cid", "pid", "vid", "crpl"):
            return f"{attr:04X}"
        return super()._to_json_extra(key, attr)


class Group(CDBObject):
    """The type of Group."""

    def __init__(self, *, name: str, address: str, parentAddress: str):
        self.name = name
        self.address = (
            int(address, base=16) if len(address) == 4 else uuid.UUID(address)
        )
        self.parentAddress = (
            int(parentAddress, base=16)
            if len(parentAddress) == 4
            else uuid.UUID(parentAddress)
        )

    def _to_json_extra(self, key, attr):
        if key in ("address", "parentAddress"):
            if isinstance(attr, int):
                return f"{attr:04X}"
            else:
                return attr.hex
        return super()._to_json_extra(key, attr)


class Scene(CDBObject):
    """The type of Scene."""

    def __init__(self, *, name: str, number: str, addresses: list[str]):
        self.name = name
        self.number = int(number, base=16)
        self.addresses = [int(address, base=16) for address in addresses]

    def _to_json_extra(self, key, attr):
        if key == "number":
            return f"{attr:04X}"
        elif key == "addresses":
            if isinstance(attr, int):
                return f"{attr:04X}"
            else:
                return attr
        return super()._to_json_extra(key, attr)


class ExclusionList(CDBObject):
    """The type of ExclusionList."""

    def __init__(self, *, ivIndex: int, addresses: list[str]):
        self.ivIndex = ivIndex
        self.addresses = [int(address, base=16) for address in addresses]

    def _to_json_extra(self, key, attr):
        if key == "addresses":
            if isinstance(attr, int):
                return f"{attr:04X}"
            else:
                return attr
        return super()._to_json_extra(key, attr)


class ConfigurationDatabase(CDBObject):
    """ConfigurationDatabase"""

    def __init__(
        self,
        *,
        schema: str,
        id: str,
        version: str,
        meshUUID: str,
        meshName: str,
        timestamp: str,
        partial: bool,
        provisioners: list[dict],
        netKeys: list[dict],
        appKeys: list[dict],
        nodes: list[dict],
        groups: list[dict],
        scenes: list[dict],
        networkExclusions: list[dict] | None = None,
    ):
        # pylint: disable=redefined-builtin
        self.schema = schema
        self.id = id
        self.version = Version(version=version)
        self.meshUUID = uuid.UUID(meshUUID)
        self.meshName = meshName
        self.timestamp = Timestamp(timestamp)
        self.partial = partial
        self.provisioners = [Provisioner(**provisioner) for provisioner in provisioners]
        self.netKeys = [NetworkKey(**netKey) for netKey in netKeys]
        self.appKeys = [ApplicationKey(**appKey) for appKey in appKeys]
        self.nodes = [Node(**node) for node in nodes]
        self.groups = [Group(**group) for group in groups]
        self.scenes = [Scene(**scene) for scene in scenes]
        if networkExclusions is not None:
            self.networkExclusions = [
                ExclusionList(**networkExclusion)
                for networkExclusion in networkExclusions
            ]

        # For fast search
        self.__nodes = {}
        for node in self.nodes:
            for i in range(len(node.elements)):
                self.__nodes[node.unicastAddress + i] = node
        self.__netKeys = {netKey.index: netKey for netKey in self.netKeys}
        self.__appKeys = {appKey.index: appKey for appKey in self.appKeys}

    def get_node(self, address: int) -> Node | None:
        return self.__nodes.get(address)

    def get_net_key(self, index: int) -> NetworkKey | None:
        return self.__netKeys.get(index)

    def get_app_key(self, index: int) -> ApplicationKey | None:
        return self.__appKeys.get(index)

    def _to_json_extra(self, key, attr):
        if key == "meshUUID":
            return str(attr)
        return super()._to_json_extra(key, attr)

    @classmethod
    def __load(cls, obj, path_schema):
        with open(path_schema, "r", encoding="utf-8") as file:
            schema = json.load(file)
        jsonschema.validate(obj, schema)
        obj["schema"] = obj["$schema"]
        del obj["$schema"]
        return cls(**obj)

    @classmethod
    def loads(cls, s: str, *args, path_schema=SCHEMA_FILE, **kwargs):
        obj = json.loads(s, *args, **kwargs)
        return cls.__load(obj, path_schema)

    @classmethod
    def load(cls, fp, *args, path_schema=SCHEMA_FILE, **kwargs):
        obj = json.load(fp, *args, **kwargs)
        return cls.__load(obj, path_schema)

    def __dump(self, path_schema=SCHEMA_FILE):
        obj = self.to_obj()
        obj["$schema"] = obj["schema"]
        del obj["schema"]
        with open(path_schema, "r", encoding="utf-8") as file:
            schema = json.load(file)
        jsonschema.validate(obj, schema)
        return obj

    def dumps(self, *args, path_schema=SCHEMA_FILE, **kwargs):
        obj = self.__dump(path_schema)
        return json.dumps(obj, *args, **kwargs)

    def dump(self, fp, *args, path_schema=SCHEMA_FILE, **kwargs):
        obj = self.__dump(path_schema)
        return json.dump(obj, fp, *args, **kwargs)
