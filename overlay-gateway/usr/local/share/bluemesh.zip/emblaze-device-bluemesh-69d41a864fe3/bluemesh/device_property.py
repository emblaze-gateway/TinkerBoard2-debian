# -*- coding: utf-8 -*-
"""Bluemesh DeviceProperty"""
import struct
from enum import IntEnum
from typing import Any, Type

import bluemesh.bluemesh_logging as logging

logger = logging.getLogger("bluemesh.device_property")


__all__ = [
    "pack",
    "unpack",
    "DevicePropertyID",
    "DeviceProperty",
]


class DevicePropertyCharacteristic:
    """DevicePropertyCharacteristic

    Please note that `Mesh Device Properties`_.

    .. _Mesh Device Properties:
       https://www.bluetooth.com/specifications/specs/mesh-device-properties-2/

    """

    @staticmethod
    def pack(value: Any) -> bytes:
        raise NotImplementedError

    @staticmethod
    def unpack(data: bytes) -> Any:
        raise NotImplementedError


class Illuminance(DevicePropertyCharacteristic):
    """Illuminance

    Uint24 state that represents luxlevel with accuracy of 0.01 lux.
    Value is between 0.00 and 167772.15 lux.

    """

    @staticmethod
    def pack(value: float) -> bytes:
        if not 0.0 <= value <= 167772.15:
            logger.error(
                "Illuminance value is between 0.0 and 167772.15 lux. value: {}", value
            )
            raise ValueError("Illuminance value is between 0.0 and 167772.15 lux")
        data = bytearray()
        _value = int(value * 100)
        data.append(_value & 0xFF)
        data.append((_value & 0xFF00) >> 8)
        data.append((_value & 0xFF0000) >> 16)
        return bytes(data)

    @staticmethod
    def unpack(data: bytes) -> float:
        if len(data) != 3:
            logger.error("Illuminance's bytes length is 3. data: {}", data)
            raise ValueError("Illuminance's bytes length is 3")
        value = round((data[2] << 16 | data[1] << 8 | data[0]) / 100, 2)
        return value


class PerceivedLightness(DevicePropertyCharacteristic):
    """PerceivedLightness

    Uint16 state that represents lightness.
    Value is between 0 and 65536.

    """

    @staticmethod
    def pack(value: int) -> bytes:
        return struct.pack("<H", value)

    @staticmethod
    def unpack(data: bytes) -> int:
        if len(data) != 2:
            logger.error("PerceivedLightness's bytes length is 2. data: {}", data)
            raise ValueError("PerceivedLightness's bytes length is 2")
        return struct.unpack("<H", data)[0]


class Percentage8(DevicePropertyCharacteristic):
    """Percentage8

    Int8 state that represents the percentage.
    Value is between 0.0 and 100.0 %.

    """

    @staticmethod
    def pack(value: float) -> bytes:
        if not 0.0 <= value <= 100.0:
            logger.error("Percentage8 value is between 0.0 and 100.0. value: {}", value)
            raise ValueError("Percentage8 value is between 0.0 and 100.0")
        return struct.pack("<b", int(value * 2))

    @staticmethod
    def unpack(data: bytes) -> float:
        if len(data) != 1:
            logger.error("Percentage8's bytes length is 1. data: {}", data)
            raise ValueError("Percentage8's bytes length is 1")
        value = round(struct.unpack("<b", data)[0] / 2, 1)
        if not 0.0 <= value <= 100.0:
            logger.error("Percentage8 value is between 0.0 and 100.0. value: {}", value)
            raise ValueError("Percentage8 value is between 0.0 and 100.0")
        return value


class Coefficient(DevicePropertyCharacteristic):
    """Coefficient

    Float32 state that represents the coefficient.
    Value is between 0.0 and 1000.0.

    """

    @staticmethod
    def pack(value: float) -> bytes:
        if not 0.0 <= value <= 1000.0:
            logger.error(
                "Coefficient value is between 0.0 and 1000.0. value: {}", value
            )
            raise ValueError("Coefficient value is between 0.0 and 1000.0")
        return struct.pack("<f", value)

    @staticmethod
    def unpack(data: bytes) -> float:
        if len(data) != 4:
            logger.error("Coefficient's bytes length is 4. data: {}", data)
            raise ValueError("Coefficient's bytes length is 4")
        value = round(struct.unpack("<f", data)[0], 1)
        if not 0.0 <= value <= 1000.0:
            logger.error(
                "Coefficient value is between 0.0 and 1000.0. value: {}", value
            )
            raise ValueError("Coefficient value is between 0.0 and 1000.0")
        return value


class TimeMillisecond24(DevicePropertyCharacteristic):
    """TimeMillisecond24

    Uint24 state that represents time.
    Value is between 0.0 and 16777.215 msec.

    """

    @staticmethod
    def pack(value: float) -> bytes:
        if not 0.0 <= value <= 16777.215:
            logger.error(
                "TimeMillisecond24 value is between 0.0 and 16777.215 msec. value: {}",
                value,
            )
            raise ValueError(
                "TimeMillisecond24 value is between 0.0 and 16777.215 msec"
            )
        data = bytearray()
        _value = int(value * 1000)
        data.append(_value & 0xFF)
        data.append((_value & 0xFF00) >> 8)
        data.append((_value & 0xFF0000) >> 16)
        return bytes(data)

    @staticmethod
    def unpack(data: bytes) -> float:
        if len(data) != 3:
            logger.error("TimeMillisecond24's bytes length is 3. data: {}", data)
            raise ValueError("TimeMillisecond24's bytes length is 3")
        value = round((data[2] << 16 | data[1] << 8 | data[0]) / 1000, 3)
        return value


class DevicePropertyID(IntEnum):
    """DevicePropertyID"""

    AVERAGE_AMBIENT_TEMPERATURE_IN_A_PERIOD_OF_DAY = 0x0001
    AVERAGE_INPUT_CURRENT = 0x0002
    AVERAGE_INPUT_VOLTAGE = 0x0003
    AVERAGE_OUTPUT_CURRENT = 0x0004
    AVERAGE_OUTPUT_VOLTAGE = 0x0005
    CENTER_BEAM_INTENSITY_AT_FULL_POWER = 0x0006
    CHROMATICITY_TOLERANCE = 0x0007
    COLOR_RENDERING_INDEX_R9 = 0x0008
    COLOR_RENDERING_INDEX_RA = 0x0009
    DEVICE_APPEARANCE = 0x000A
    DEVICE_COUNTRY_OF_ORIGIN = 0x000B
    DEVICE_DATE_OF_MANUFACTURE = 0x000C
    DEVICE_ENERGY_USE_SINCE_TURN_ON = 0x000D
    DEVICE_FIRMWARE_REVISION = 0x000E
    DEVICE_GLOBAL_TRADE_ITEM_NUMBER = 0x000F
    DEVICE_HARDWARE_REVISION = 0x0010
    DEVICE_MANUFACTURER_NAME = 0x0011
    DEVICE_MODEL_NUMBER = 0x0012
    DEVICE_OPERATING_TEMPERATURE_RANGE_SPECIFICATION = 0x0013
    DEVICE_OPERATING_TEMPERATURE_STATISTICAL_VALUES = 0x0014
    DEVICE_OVER_TEMPERATURE_EVENT_STATISTICS = 0x0015
    DEVICE_POWER_RANGE_SPECIFICATION = 0x0016
    DEVICE_RUNTIME_SINCE_TURN_ON = 0x0017
    DEVICE_RUNTIME_WARRANTY = 0x0018
    DEVICE_SERIAL_NUMBER = 0x0019
    DEVICE_SOFTWARE_REVISION = 0x001A
    DEVICE_UNDER_TEMPERATURE_EVENT_STATISTICS = 0x001B
    INDOOR_AMBIENT_TEMPERATURE_STATISTICAL_VALUES = 0x001C
    INITIAL_CIE1931_CHROMATICITY_COORDINATES = 0x001D
    INITIAL_CORRELATED_COLOR_TEMPERATURE = 0x001E
    INITIAL_LUMINOUS_FLUX = 0x001F
    INITIAL_PLANCKIAN_DISTANCE = 0x0020
    INPUT_CURRENT_RANGE_SPECIFICATION = 0x0021
    INPUT_CURRENT_STATISTICS = 0x0022
    INPUT_OVER_CURRENT_EVENT_STATISTICS = 0x0023
    INPUT_OVER_RIPPLE_VOLTAGE_EVENT_STATISTICS = 0x0024
    INPUT_OVER_VOLTAGE_EVENT_STATISTICS = 0x0025
    INPUT_UNDER_CURRENT_EVENT_STATISTICS = 0x0026
    INPUT_UNDER_VOLTAGE_EVENT_STATISTICS = 0x0027
    INPUT_VOLTAGE_RANGE_SPECIFICATION = 0x0028
    INPUT_VOLTAGE_RIPPLE_SPECIFICATION = 0x0029
    INPUT_VOLTAGE_STATISTICS = 0x002A
    LIGHT_CONTROL_AMBIENT_LUXLEVEL_ON = 0x002B
    LIGHT_CONTROL_AMBIENT_LUXLEVEL_PROLONG = 0x002C
    LIGHT_CONTROL_AMBIENT_LUXLEVEL_STANDBY = 0x002D
    LIGHT_CONTROL_LIGHTNESS_ON = 0x002E
    LIGHT_CONTROL_LIGHTNESS_PROLONG = 0x002F
    LIGHT_CONTROL_LIGHTNESS_STANDBY = 0x0030
    LIGHT_CONTROL_REGULATOR_ACCURACY = 0x0031
    LIGHT_CONTROL_REGULATOR_KID = 0x0032
    LIGHT_CONTROL_REGULATOR_KIU = 0x0033
    LIGHT_CONTROL_REGULATOR_KPD = 0x0034
    LIGHT_CONTROL_REGULATOR_KPU = 0x0035
    LIGHT_CONTROL_TIME_FADE = 0x0036
    LIGHT_CONTROL_TIME_FADE_ON = 0x0037
    LIGHT_CONTROL_TIME_FADE_STANDBY_AUTO = 0x0038
    LIGHT_CONTROL_TIME_FADE_STANDBY_MANUAL = 0x0039
    LIGHT_CONTROL_TIME_OCCUPANCY_DELAY = 0x003A
    LIGHT_CONTROL_TIME_PROLONG = 0x003B
    LIGHT_CONTROL_TIME_RUN_ON = 0x003C
    LUMEN_MAINTENANCE_FACTOR = 0x003D
    LUMINOUS_EFFICACY = 0x003E
    LUMINOUS_ENERGY_SINCE_TURN_ON = 0x003F
    LUMINOUS_EXPOSURE = 0x0040
    LUMINOUS_FLUX_RANGE = 0x0041
    MOTION_SENSED = 0x0042
    MOTION_THRESHOLD = 0x0043
    OPEN_CIRCUIT_EVENT_STATISTICS = 0x0044
    OUTDOOR_STATISTICAL_VALUES = 0x0045
    OUTPUT_CURRENT_RANGE = 0x0046
    OUTPUT_CURRENT_STATISTICS = 0x0047
    OUTPUT_RIPPLE_VOLTAGE_SPECIFICATION = 0x0048
    OUTPUT_VOLTAGE_RANGE = 0x0049
    OUTPUT_VOLTAGE_STATISTICS = 0x004A
    OVER_OUTPUT_RIPPLE_VOLTAGE_EVENT_STATISTICS = 0x004B
    PEOPLE_COUNT = 0x004C
    PRESENCE_DETECTED = 0x004D
    PRESENT_AMBIENT_LIGHT_LEVEL = 0x004E
    PRESENT_AMBIENT_TEMPERATURE = 0x004F
    PRESENT_CIE1931_CHROMATICITY_COORDINATES = 0x0050
    PRESENT_CORRELATED_COLOR_TEMPERATURE = 0x0051
    PRESENT_DEVICE_INPUT_POWER = 0x0052
    PRESENT_DEVICE_OPERATING_EFFICIENCY = 0x0053
    PRESENT_DEVICE_OPERATING_TEMPERATURE = 0x0054
    PRESENT_ILLUMINANCE = 0x0055
    PRESENT_INDOOR_AMBIENT_TEMPERATURE = 0x0056
    PRESENT_INPUT_CURRENT = 0x0057
    PRESENT_INPUT_RIPPLE_VOLTAGE = 0x0058
    PRESENT_INPUT_VOLTAGE = 0x0059
    PRESENT_LUMINOUS_FLUX = 0x005A
    PRESENT_OUTDOOR_AMBIENT_TEMPERATURE = 0x005B
    PRESENT_OUTPUT_CURRENT = 0x005C
    PRESENT_OUTPUT_VOLTAGE = 0x005D
    PRESENT_PLANCKIAN_DISTANCE = 0x005E
    PRESENT_RELATIVE_OUTPUT_RIPPLE_VOLTAGE = 0x005F
    RELATIVE_DEVICE_ENERGY_USE_IN_A_PERIOD_OF_DAY = 0x0060
    RELATIVE_DEVICE_RUNTIME_IN_A_GENERIC_LEVEL_RANGE = 0x0061
    RELATIVE_EXPOSURE_TIME_IN_AN_ILLUMINANCE_RANGE = 0x0062
    RELATIVE_RUNTIME_IN_A_CORRELATED_COLOR_TEMPERATURE_RANGE = 0x0063
    RELATIVE_RUNTIME_IN_A_DEVICE_OPERATING_TEMPERATURE_RANGE = 0x0064
    RELATIVE_RUNTIME_IN_AN_INPUT_CURRENT_RANGE = 0x0065
    RELATIVE_RUNTIME_IN_AN_INPUT_VOLTAGE_RANGE = 0x0066
    SHORT_CIRCUIT_EVENT_STATISTICS = 0x0067
    TIME_SINCE_MOTION_SENSED = 0x0068
    TIME_SINCE_PRESENCE_DETECTED = 0x0069
    TOTAL_DEVICE_ENERGY_USE = 0x006A
    TOTAL_DEVICE_OFF_ON_CYCLES = 0x006B
    TOTAL_DEVICE_POWER_ON_CYCLES = 0x006C
    TOTAL_DEVICE_POWER_ON_TIME = 0x006D
    TOTAL_DEVICE_RUNTIME = 0x006E
    TOTAL_LIGHT_EXPOSURE_TIME = 0x006F
    TOTAL_LUMINOUS_ENERGY = 0x0070
    PRECISE_TOTAL_DEVICE_ENERGY_USE = 0x0072

    def __repr__(self):
        return str(self.value)


device_property_characteristics: dict[int, Type[DevicePropertyCharacteristic]] = {
    0x002B: Illuminance,
    0x002C: Illuminance,
    0x002D: Illuminance,
    0x002E: PerceivedLightness,
    0x002F: PerceivedLightness,
    0x0030: PerceivedLightness,
    0x0031: Percentage8,
    0x0032: Coefficient,
    0x0033: Coefficient,
    0x0034: Coefficient,
    0x0035: Coefficient,
    0x0036: TimeMillisecond24,
    0x0037: TimeMillisecond24,
    0x0038: TimeMillisecond24,
    0x0039: TimeMillisecond24,
    0x003A: TimeMillisecond24,
    0x003B: TimeMillisecond24,
    0x003C: TimeMillisecond24,
}
"""dict: Dictionary of property characteristics in according with property id."""


def pack(property_id: int, value: Any) -> bytes:
    """Make property value into bytes."""
    return device_property_characteristics[property_id].pack(value)


def unpack(property_id: int, data: bytes) -> Any:
    """Make data into property value."""
    return device_property_characteristics[property_id].unpack(data)


class DeviceProperty:
    """DeviceProperty

    Please note that `Mesh Device Properties`_.

    Args:
        property_id: Property identifier. Refer to `Mesh Device Properties`_.
        value: Property value.
        name: Property name when you need to know what name the property is.
        is_raw: True when `value` argurment is bytes of little endian. (keyword only)

    .. _Mesh Device Properties:
       https://www.bluetooth.com/specifications/specs/mesh-device-properties-2/

    """

    def __init__(self, property_id: int, value: Any, name: str = "", *, is_raw=False):
        self.id = property_id
        if is_raw:
            self.value = unpack(self.id, value)
        else:
            self.value = value
        self.name = name

    def __str__(self):
        return f"{self.name} - {self.value}"

    def pack(self) -> bytes:
        return pack(self.id, self.value)
