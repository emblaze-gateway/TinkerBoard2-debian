# -*- coding: utf-8 -*-
"""Bluemesh Element Module

This module provides :class:`Element` to make bluetooth mesh application
using bluez interfaces.

Example:
    User application with SIG/Vendor models can be made by inheritance of
    :class:`Element`.::

        class MyElement(Element):
            ...

.. _Mesh API:
   https://git.kernel.org/pub/scm/bluetooth/bluez.git/tree/doc/mesh-api.txt

"""

from typing import Any
from uuid import UUID

import bluemesh.bluemesh_logging as logging
from bluemesh.bluez_interface import BlueZInterfaceFactory, ElementInterfaceABC
from bluemesh.models.base import Model

logger = logging.getLogger("bluemesh.element")


class ElementError(Exception):
    """The type of 'Exception' for Element Errors"""


class Element:
    """Element

    Attributes:
        path (str): The object path of element with index on application root.
        index (int): The element index starting from 0. Each element has a unicast
            address that is an index distance from the primary address.

    """

    MODEL_CLASSES: list[type["Model"]]

    def __new__(cls, *args, **kwargs):
        # pylint: disable=unused-argument
        if cls is Element:
            raise TypeError("Cannot instantiate Base class")
        return super().__new__(cls)

    def __init__(
        self, application, index: int, interface_factory: BlueZInterfaceFactory
    ):
        self._application = application
        self.path = f"{self._application.path}/element{index:02X}"
        self.index = index

        self.interface: ElementInterfaceABC = (
            interface_factory.create_element_interface(self, self.path)
        )

        self._models: dict[tuple[int | None, int], Model] = {}
        if not getattr(self, "MODEL_CLASSES", None):
            raise ElementError(f"{self.__class__} does not have any Model")
        for model_class in self.MODEL_CLASSES:
            assert (
                model_class.VENDOR,
                model_class.MODEL_ID,
            ) not in self.MODEL_CLASSES, (
                f"Element #{self.index:02X} already has the model "
                + f"#{model_class.model_id:r}"
            )
            logger.info(
                f"element {self.index}:"
                f" model {(model_class.VENDOR, model_class.MODEL_ID)}"
            )
            model = model_class(self)
            self._models[(model_class.VENDOR, model_class.MODEL_ID)] = model

    def __getitem__(self, key: int):
        model_id = (key >> 16 if key > 0xFFFF else None, key & 0xFFFF)
        return self._models[model_id]

    def send(
        self, destination: int, key_index: int, data: bytes, force_segmented: bool
    ):
        self._application.send(self.path, destination, key_index, data, force_segmented)

    def dev_key_send(
        self,
        destination: int,
        net_index: int,
        data: bytes,
        remote: bool,
        force_segmented: bool,
    ):
        # pylint: disable=too-many-arguments
        self._application.dev_key_send(
            self.path, destination, net_index, data, remote, force_segmented
        )

    def publish(
        self, model_id: tuple[int | None, int], data: bytes, force_segmented: bool
    ):
        self._application.publish(self.path, model_id, data, force_segmented)

    @property
    def models(self) -> list[tuple[int, dict[str, bool]]]:
        rets = []
        for model_id, model in self._models.items():
            if model_id[0] is not None:
                continue
            opts = {"Publish": model.PUBLISH, "Subscribe": model.SUBSCRIBE}
            rets.append((model_id[1], opts))
        return rets

    @property
    def vendor_models(self) -> list[tuple[int, int, dict[str, bool]]]:
        rets = []
        for model_id, model in self._models.items():
            if model_id[0] is None:
                continue
            opts = {"Publish": model.PUBLISH, "Subscribe": model.SUBSCRIBE}
            rets.append((model_id[0], model_id[1], opts))
        return rets

    def update_model_config(
        self, vendor_assigned_model_id: int, config: dict[str, Any]
    ):
        """
        Args:
            vendor_assigned_model_id: Vendor-assigned model id.
            config: This model's configuration included vendor id.
        """
        model_id = (
            config["Vendor"] if "Vendor" in config else None,
            vendor_assigned_model_id,
        )
        logger.debug("update_model_config: {}", model_id)

        if model_id in self._models:
            self._models[model_id].set_config(config)

    def update_model_config_handler(
        self, vendor_assigned_model_id: int, config: dict[str, Any]
    ):
        self.update_model_config(vendor_assigned_model_id, config)

    def message_received_handler(
        self, source: int, key_index: int, destination: int | list[int], data: list[int]
    ):
        logger.debug("message_received_handler: {}", str(self.__class__.__name__))
        dest: int | UUID
        if isinstance(destination, list):
            dest = UUID(bytes=bytes(destination))
        else:
            dest = destination
        for model in self._models.values():
            message: dict = model.message_received(source, key_index, dest, bytes(data))
            if message:
                self._application.message_handler(message)
                return

    def dev_key_message_received_handler(
        self, source: int, remote: bool, net_index: int, data: list[int]
    ):
        logger.debug(
            "dev_key_message_received_handler: {}", str(self.__class__.__name__)
        )
        for model in self._models.values():
            message: dict = model.dev_key_message_received(
                source, remote, net_index, bytes(data)
            )
            if message:
                self._application.message_handler(message)
                return
