# -*- coding: utf-8 -*-
"""Bluemesh Model Module

This module provides :class:`Model` to make bluetooth mesh application
using bluez interfaces.

Example:
    User application with SIG/Vendor models can be made by inheritance of
    :class:`Model`.::

        class MyModel(Model):
            ...

.. _Mesh API:
   https://git.kernel.org/pub/scm/bluetooth/bluez.git/tree/doc/mesh-api.txt

"""


import functools
from typing import Any, Callable

import bluemesh.bluemesh_logging as logging
from bluemesh.access import AccessMessage

logger = logging.getLogger("bluemesh.models.base")


class ModelConfigProperty:
    """ModelConfigProperty"""

    @property
    def bindings(self) -> list[int] | None:
        return getattr(self, "__bindings", None)

    @property
    def publication_period(self) -> int | None:
        return getattr(self, "__publication_period", None)

    @property
    def subscriptions(self) -> list[bytes | int] | None:
        return getattr(self, "__subscriptions", None)


class ModelID:
    """Contains tuples about model id.

    This class is declared empty but filled to class fields by a model inherited
    from ``Model`` what defining.

    """

    CONFIG_SERVER = (None, 0x0000)  # Sample


class Model(ModelConfigProperty):
    """Model

    Attributes:
        model_id (tuple[None | int, int]): SIG/Vendor-assigned specified ID.

    Todo:
        * Implement publish method.

    """

    MODEL_ID: int
    VENDOR: int | None
    HANDLERS: dict[int, Callable]  # Must be overridden as empty dictionary

    PUBLISH: bool = False
    SUBSCRIBE: bool = False

    def __new__(cls, *args, **kwargs):
        # pylint: disable=unused-argument
        if cls is Model:
            raise TypeError("Cannot instantiate Base class")
        return super().__new__(cls)

    def __init__(self, element):
        self.element = element

        if (
            not hasattr(self, "MODEL_ID")
            or self.MODEL_ID is None
            or not hasattr(self, "VENDOR")
        ):
            raise AttributeError(f"{self.__class__} must define model ID")

        if not hasattr(self, "HANDLERS") or not isinstance(self.HANDLERS, dict):
            raise AttributeError(f'{self.__class__} must override "HANDLERS" field')

        self._backup_msg: dict[str, Any]

    @property
    def model_id(self) -> tuple[int | None, int]:
        return (self.VENDOR, self.MODEL_ID)

    def set_config(self, config: dict[str, Any]):
        logger.debug("Update configurations for model {}", self.__class__.__name__)
        if "Bindings" in config:
            setattr(self, "__bindings", config["Bindings"])
            logger.debug("bindings: {}", self.bindings)
        if "PublicationPeriod" in config:
            setattr(self, "__publication_period", config["PublicationPeriod"])
            logger.debug("publication_period: {}", self.publication_period)
        if "Subscriptions" in config:
            subscriptions: list[int | bytes] = []
            for sub in config["Subscriptions"]:
                if isinstance(sub, list):
                    subscriptions.append(bytes(sub))
                elif isinstance(sub, int):
                    subscriptions.append(sub)
                else:
                    raise TypeError("Allow 'int' or 'bytes'")
            setattr(self, "__subscriptions", subscriptions)
            logger.debug("subscriptions: {}", self.subscriptions)

    def message_received(self, source, key_index, destination, data):
        opcode = AccessMessage.parse_opcode(data)
        if opcode in self.HANDLERS:
            logger.debug("message_received: {}", str(self.__class__.__name__))
            fields = self.HANDLERS[opcode](self, source, key_index, destination, data)
            return {
                "opcode": opcode,
                "source": source,
                "key_index": key_index,
                "destination": destination,
                "fields": fields,
            }
        return None

    def dev_key_message_received(self, source, remote, net_index, data):
        opcode = AccessMessage.parse_opcode(data)
        if opcode in self.HANDLERS:
            logger.debug("dev_key_message_received: {}", str(self.__class__.__name__))
            fields = self.HANDLERS[opcode](self, source, remote, net_index, data)
            return {
                "opcode": opcode,
                "source": source,
                "remote": remote,
                "net_index": net_index,
                "fields": fields,
            }
        return None

    def repeat(self):
        """Send the last message repeatedly.

        This method is useful for models that use tid (Transaction Identifier). When a
        receiver gets messages of the same tid for a certain period of time, the
        receiver treats these messages as the same operation.

        """
        if not hasattr(self, "_backup_msg"):
            raise Exception("any message have not sent")
        if self.__class__ == self._backup_msg["class"]:
            logger.info(
                "repeat: dest {}, key {}, data {}",
                *self._backup_msg["data"][0:3],
            )
            self._backup_msg["callback"](*self._backup_msg["data"])

    @staticmethod
    def message_handler(handlers, opcode, signature=""):
        """Decorator of message handling with application key

        Note:
            `handlers` is a class attribute containing message_received handler defined
            by concrete model as HANDLERS.

        """

        def outer_wrapper(func):
            @functools.wraps(func)
            def wrapper(self, source, key_index, destination, data):
                fields = AccessMessage.unpack(data, signature)
                return func(self, source, key_index, destination, fields)

            handlers[opcode] = wrapper
            return wrapper

        return outer_wrapper

    @staticmethod
    def dev_key_message_handler(handlers, opcode, signature=""):
        """Decorator of message handling with device key

        Note:
            `handlers` is a class attribute containing dev_key_message_received handler
            defined by concrete model as HANDLERS.

        """

        def outer_wrapper(func):
            @functools.wraps(func)
            def wrapper(self, source, remote, net_index, data):
                fields = AccessMessage.unpack(data, signature)
                return func(self, source, remote, net_index, fields)

            if opcode in handlers:
                raise Exception(f"{opcode} is duplicated")
            handlers[opcode] = wrapper
            return wrapper

        return outer_wrapper

    @staticmethod
    def send(opcode, signature=""):
        """Decorator of sending fields with application key"""

        def outer_wrapper(func):
            @functools.wraps(func)
            def wrapper(
                self,
                destination,
                key_index,
                *args,
                force_segmented=False,
                use_repeat=False,
                **kwargs,
            ):
                # pylint: disable=protected-access
                fields = func(self, destination, key_index, *args, **kwargs)
                data = AccessMessage.pack(opcode, fields, signature)
                logger.debug("send: {}", data)
                self.element.send(destination, key_index, data, force_segmented)
                if use_repeat:
                    self._backup_msg = {
                        "class": self.__class__,
                        "callback": self.element.send,
                        "data": (destination, key_index, data, force_segmented),
                    }

                return data

            return wrapper

        return outer_wrapper

    @staticmethod
    def dev_key_send(opcode, signature=""):
        """Decorator of sending fields with device key"""

        def outer_wrapper(func):
            @functools.wraps(func)
            def wrapper(
                self,
                destination,
                net_index,
                *args,
                remote=True,
                force_segmented=False,
                use_repeat=False,
                **kwargs,
            ):
                # pylint: disable=protected-access
                fields = func(self, destination, net_index, *args, **kwargs)
                data = AccessMessage.pack(opcode, fields, signature)
                logger.debug("dev_key_send: {}", data)
                self.element.dev_key_send(
                    destination, net_index, data, remote, force_segmented
                )
                if use_repeat:
                    self._backup_msg = {
                        "class": self.__class__,
                        "callback": self.element.dev_key_send,
                        "data": (destination, net_index, data, remote, force_segmented),
                    }

                return data

            return wrapper

        return outer_wrapper
