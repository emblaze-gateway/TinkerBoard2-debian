# -*- coding: utf-8 -*-
"""Bluemesh Access Module"""
import math
import struct
from typing import Any, Callable

import bluemesh.bluemesh_logging as logging
from bluemesh.access import AccessMessage
from bluemesh.models.base import Model

logger = logging.getLogger("bluemesh.models.config")


class ConfigClient(Model):
    # pylint: disable=too-many-arguments,unused-argument,too-many-public-methods
    """Configuration Client Model by SIG"""
    MODEL_ID = 0x0001
    VENDOR = None
    HANDLERS: dict[int, Callable] = {}

    @Model.dev_key_send(0x00, "(cK)r16")
    def appkey_add(self, dest, net_index, net, app, key):
        logger.info("appkey_add")
        return [(net, app), key]

    @Model.dev_key_message_handler(HANDLERS, 0x02, "Br_")
    def composition_data_status_handler(self, source, remote, net_index, fields):
        # pylint: disable=too-many-locals
        ret = {}

        ret["page"] = fields[0]
        logger.info("composition_data_status : page {}", ret["page"])
        if ret["page"] == 0:
            data = fields[1]
            ret.update(
                zip(
                    ["cid", "pid", "vid", "crpl", "features"],
                    struct.unpack("<HHHHH", data[:10]),
                )
            )
            logger.info(
                "CID: {}, PID: {}, VID: {}, CRPL: {}",
                ret["cid"],
                ret["pid"],
                ret["vid"],
                ret["crpl"],
            )
            ret["features"] = dict(
                zip(
                    ["relay", "proxy", "friend", "low_power"],
                    [((ret["features"] >> i) & 1) == 1 for i in range(4)],
                )
            )
            logger.info(
                "Relay: {}, Proxy: {}, Friend: {}, Low Power: {}",
                ret["features"]["relay"],
                ret["features"]["proxy"],
                ret["features"]["friend"],
                ret["features"]["low_power"],
            )

            ret["elements"] = []
            data = data[10:]
            while len(data) > 0:
                loc, num_s, num_v = struct.unpack("<HBB", data[:4])
                data = data[4:]
                sig_models = []
                for _ in range(num_s):
                    sig_models.append(struct.unpack("<H", data[:2])[0])
                    data = data[2:]
                vendor_models = []
                for _ in range(num_v):
                    vendor_models.append(struct.unpack("<I", data[:4])[0])
                    data = data[4:]
                logger.info(
                    "Location: {},\n\tSIG Models: {},\n\tVendor Models: {}",
                    loc,
                    sig_models,
                    vendor_models,
                )
                ret["elements"].append(
                    {
                        "loc": loc,
                        "sig_models": sig_models,
                        "vendor_models": vendor_models,
                    }
                )
        return ret

    def __model_publication_set(
        self,
        dest,
        net_index,
        element_address,
        publish_address,
        app_key_index,
        credential_flag,
        ttl,
        period,
        rtx_cnt,
        rtx_interval,
        model_id,
    ):
        """Used to set the Model Publication state of an outgoing message"""
        key_index = [0] * 2
        key_index[0] = app_key_index & 0xFF
        key_index[1] = (app_key_index & 0xF00) >> 8 | (1 if credential_flag else 0) << 4
        if not (0 <= ttl <= 0x7F or ttl == 0xFF):
            logger.error("Publish TTL is prohibited between 0x80 - 0xFE. got: {}", ttl)
            raise ValueError
        if not 0 <= rtx_cnt <= 7:
            logger.error(
                "model_publication_set: rtx_cnt must be from 0 to 7. got: {}", rtx_cnt
            )
            raise ValueError
        if not 50 <= rtx_interval <= 1550:
            logger.error(
                "model_publication_set: rtx_interval must be from 50 to 1550. got: {}",
                rtx_interval,
            )
            raise ValueError
        rtx_interval_steps = rtx_interval // 50 - 1
        publish_rtx = rtx_cnt & 0x7 | (rtx_interval_steps & 0x1F) << 3
        return [
            element_address,
            publish_address,
            struct.pack("<BB", *key_index),
            ttl,
            period,
            struct.pack("<B", publish_rtx),
            model_id,
        ]

    @Model.dev_key_send(0x03, "HHr2B(gtt)r1(c_m)")
    def model_publication_set(
        self,
        dest,
        net_index,
        element_address,
        publish_address,
        app_key_index,
        credential_flag,
        ttl,
        period,
        rtx_cnt,
        rtx_interval,
        model_id,
    ):
        logger.info(
            "model_publication_set: address {}, target: {}, key_index: {}"
            "credential_flag: {}, ttl: {}, period: {}, rtx_cnt: {}, rtx_interval:"
            " {}, model_id: {}",
            element_address,
            publish_address,
            app_key_index,
            credential_flag,
            ttl,
            period,
            rtx_cnt,
            rtx_interval,
            model_id,
        )
        return self.__model_publication_set(
            dest,
            net_index,
            element_address,
            publish_address,
            app_key_index,
            credential_flag,
            ttl,
            period,
            rtx_cnt,
            rtx_interval,
            model_id,
        )

    @Model.dev_key_message_handler(HANDLERS, 0x06, "BH(ccp)(cpp)BH(ck)")
    def heartbeat_publication_status_handler(self, source, remote, net_index, fields):
        status = fields[0]
        logger.info("heartbeat_publication_status : status : {}", status)

        destination = fields[1]
        count = fields[2]
        period = fields[3]
        ttl = fields[4]
        features = [fields[5] & k > 0 for k in [1, 2, 4, 8]]
        net_key_index = fields[6]
        logger.info(
            "dest: {}, count: {}, period: {}, ttl: {}, features(relay, proxy, friend, "
            "low power): {}, net_key_index: {}",
            destination,
            count,
            period,
            ttl,
            features,
            net_key_index,
        )
        return {
            "status": status,
            "destination": destination,
            "count": count,
            "period": period,
            "ttl": ttl,
            "features": features,
            "net_key_index": net_key_index,
        }

    @Model.dev_key_send(0x8000, "(cK)")
    def appkey_delete(self, dest, net_index, net, app):
        logger.info("appkey_delete")
        return [(net, app)]

    @Model.dev_key_send(0x8001, "(ck)")
    def appkey_get(self, dest, net_index, net):
        logger.info("appkey_get")
        return [net]

    @Model.dev_key_message_handler(HANDLERS, 0x8002, "B(ck){(c_k)}")
    def appkey_list_handler(self, source, remote, net_index, fields):
        status = fields[0]
        logger.info("appkey_list : status : {}", status)

        net = fields[1]
        logger.info("netkey_index: {}", net)

        apps = []
        for combined_key in fields[2:]:
            if isinstance(combined_key, tuple):
                logger.info("\tappkey_index: {}", combined_key[0])
                logger.info("\tappkey_index: {}", combined_key[1])
                apps += combined_key
            else:
                logger.info("\tappkey_index: {}", combined_key)
                apps.append(combined_key)

        return {"status": status, "net_key_index": net, "app_key_indexes": apps}

    @Model.dev_key_message_handler(HANDLERS, 0x8003, "B(cK)")
    def appkey_status_handler(self, source, remote, net_index, fields):
        status = fields[0]
        logger.info("appkey_status : status : {}", status)

        net, app = fields[1]
        logger.info("netkey_index: {}, appkey_index: {}", net, app)

        return {"status": status, "net_key_index": net, "app_key_index": app}

    @Model.dev_key_send(0x8008, "B")
    def composition_data_get(self, dest, net_index, page=0):
        logger.info("composition_data_get : page {}", page)
        return [page]

    @Model.dev_key_send(0x800C, "")
    def default_ttl_get(self, dest, net_index):
        logger.info("default_ttl_get")

    @Model.dev_key_send(0x800D, "B")
    def default_ttl_set(self, dest, net_index, ttl):
        logger.info("default_ttl_set : {}", ttl)
        return [ttl]

    @Model.dev_key_message_handler(HANDLERS, 0x800E, "B")
    def default_ttl_status_handler(self, source, remote, net_index, fields):
        logger.info("default_ttl_status")
        ttl = fields[0]
        logger.info("Default TTL: {}", ttl)
        return {"ttl": ttl}

    @Model.dev_key_send(0x8018, "H(c_m)")
    def model_publication_get(self, dest, net_index, element_address, model_id):
        """Used to get the publish address and parameters of an outgoing message"""
        logger.info(
            "model_publication_get : element {}, model id: {}",
            element_address,
            model_id,
        )
        return [element_address, model_id]

    @Model.dev_key_message_handler(HANDLERS, 0x8019, "BHHr2B(gtt)r1(c_m)")
    def model_publication_status_handler(self, source, remote, net_index, fields):
        # pylint: disable=too-many-locals
        logger.info("model_publication_status_handler")
        (
            status,
            element_address,
            publish_address,
            key_index,
            ttl,
            period,
            publish_rtx,
            model_id,
        ) = fields
        app_key_index = key_index[0] | (key_index[1] & 0x0F) << 8
        credential_flag = (key_index[1] & 0x10) >> 4
        publish_rtx = struct.unpack("<B", publish_rtx)[0]
        rtx_cnt = publish_rtx & 0x7
        rtx_interval = (((publish_rtx & 0xF8) >> 3) + 1) * 50
        ret = {
            "status": status,
            "element_address": element_address,
            "publish_address": publish_address,
            "app_key_index": app_key_index,
            "credential_flag": credential_flag,
            "ttl": ttl,
            "period": period,
            "rtx_cnt": rtx_cnt,
            "rtx_interval": rtx_interval,
            "model_id": model_id,
        }
        logger.info("{}", ret)
        return ret

    @Model.dev_key_send(0x801A, "Hur2B(gtt)r1(c_m)")
    def model_publication_virtual_address_set(
        self,
        dest,
        net_index,
        element_address,
        publish_address,
        app_key_index,
        credential_flag,
        ttl,
        period,
        rtx_cnt,
        rtx_interval,
        model_id,
    ):
        logger.info(
            "model_publication_virtual_address_set: address {}, target: {}, key_index:"
            " {}, credential_flag: {}, ttl: {}, period: {}, rtx_cnt: {}, rtx_interval:"
            " {}, model_id: {}",
            element_address,
            publish_address,
            app_key_index,
            credential_flag,
            ttl,
            period,
            rtx_cnt,
            rtx_interval,
            model_id,
        )
        return self.__model_publication_set(
            dest,
            net_index,
            element_address,
            publish_address,
            app_key_index,
            credential_flag,
            ttl,
            period,
            rtx_cnt,
            rtx_interval,
            model_id,
        )

    @Model.dev_key_send(0x801B, "HH(c_m)")
    def model_subscription_add(
        self, dest, net_index, element_address, address, model_id
    ):
        logger.info(
            "model_subscription_add : {} {} {}", element_address, address, model_id
        )
        return [element_address, address, model_id]

    @Model.dev_key_send(0x801C, "HH(c_m)")
    def model_subscription_delete(
        self, dest, net_index, element_address, address, model_id
    ):
        logger.info(
            "model_subscription_delete : {} {} {}", element_address, address, model_id
        )
        return [element_address, address, model_id]

    @Model.dev_key_send(0x801D, "H(c_m)")
    def model_subscription_delete_all(self, dest, net_index, element_address, model_id):
        logger.info("model_subscription_delete_all : {} {}", element_address, model_id)
        return [element_address, model_id]

    @Model.dev_key_send(0x801E, "HH(c_m)")
    def model_subscription_overwrite(
        self, dest, net_index, element_address, address, model_id
    ):
        logger.info(
            "model_subscription_overwrite : {} {} {}",
            element_address,
            address,
            model_id,
        )
        return [element_address, address, model_id]

    @Model.dev_key_message_handler(HANDLERS, 0x801F, "BHH(c_m)")
    def model_subscription_status_handler(self, source, remote, net_index, fields):
        logger.info("model_subscription_status")
        status, element_address, address, model_id = fields
        logger.info(
            "status: {}, element_address: {}, address: {}, model_id: {}",
            status,
            element_address,
            address,
            model_id,
        )
        return {
            "status": status,
            "element_address": element_address,
            "address": address,
            "model_id": model_id,
        }

    @Model.dev_key_send(0x8020, "Hu(c_m)")
    def model_subscription_virtual_address_add(
        self, dest, net_index, element_address, address, model_id
    ):
        logger.info(
            "model_subscription_virtual_address_add : {} {} {}",
            element_address,
            address,
            model_id,
        )
        return [element_address, address, model_id]

    @Model.dev_key_send(0x8021, "Hu(c_m)")
    def model_subscription_virtual_address_delete(
        self, dest, net_index, element_address, address, model_id
    ):
        logger.info(
            "model_subscription_virtual_address_delete : {} {} {}",
            element_address,
            address,
            model_id,
        )
        return [element_address, address, model_id]

    @Model.dev_key_send(0x8022, "Hu(c_m)")
    def model_subscription_virtual_address_overwrite(
        self, dest, net_index, element_address, address, model_id
    ):
        logger.info(
            "model_subscription_virtual_address_overwrite : {} {} {}",
            element_address,
            address,
            model_id,
        )
        return [element_address, address, model_id]

    @Model.dev_key_send(0x8023, "")
    def network_transmit_get(self, dest, net_index):
        logger.info("network_transmit_get")

    @Model.dev_key_send(0x8024, "r1")
    def network_transmit_set(self, dest, net_index, tx_cnt, tx_interval):
        logger.info("network_transmit_set")
        if not 0 <= tx_cnt <= 7:
            raise ValueError("network_transmit_set: tx_cnt must be from 0 to 7")
        if not 10 <= tx_interval <= 320:
            raise ValueError("network_transmit_set: tx_interval must be from 10 to 320")
        tx_interval_steps = tx_interval // 10 - 1
        network_tx = tx_cnt & 0x7 | (tx_interval_steps & 0x1F) << 3
        return [struct.pack("<B", network_tx)]

    @Model.dev_key_message_handler(HANDLERS, 0x8025, "r1")
    def network_transmit_status_handler(self, source, remote, net_index, fields):
        logger.info("network_transmit_status")
        network_tx = struct.unpack("<B", fields[0])[0]
        tx_cnt = network_tx & 0x7
        tx_interval = (((network_tx & 0xF8) >> 3) + 1) * 10
        logger.info("TransmitCount: {}, TransmitInterval: {}", tx_cnt, tx_interval)
        return {"tx_cnt": tx_cnt, "tx_interval": tx_interval}

    @Model.dev_key_send(0x8026, "")
    def relay_get(self, dest, net_index):
        logger.info("relay_get")

    @Model.dev_key_send(0x8027, "Br1")
    def relay_set(self, dest, net_index, relay, rtx_cnt, rtx_interval):
        logger.info("relay_set : {}", relay)
        if not 0 <= rtx_cnt <= 7:
            raise ValueError("relay_set: rtx_cnt must be from 0 to 7")
        if not 10 <= rtx_interval <= 320:
            raise ValueError("relay_set: rtx_interval must be from 10 to 320")
        rtx_interval_steps = rtx_interval // 10 - 1
        relay_rtx = rtx_cnt & 0x7 | (rtx_interval_steps & 0x1F) << 3
        return [relay, struct.pack("<B", relay_rtx)]

    @Model.dev_key_message_handler(HANDLERS, 0x8028, "Br1")
    def relay_status_handler(self, source, remote, net_index, fields):
        logger.info("relay_status")
        relay = fields[0]
        relay_rtx = struct.unpack("<B", fields[1])[0]
        rtx_cnt = relay_rtx & 0x7
        rtx_interval = (((relay_rtx & 0xF8) >> 3) + 1) * 10
        logger.info(
            "Relay: {}, RetransmitCount: {}, RetransmitInterval: {}",
            relay,
            rtx_cnt,
            rtx_interval,
        )
        return {"relay": relay, "rtx_cnt": rtx_cnt, "rtx_interval": rtx_interval}

    @Model.dev_key_send(0x8029, "H(cm)")
    def sig_model_subscription_get(self, dest, net_index, element_address, model_id):
        logger.info("sig_model_subscription_get : {} {}", element_address, model_id)
        return [element_address, model_id]

    @Model.dev_key_message_handler(HANDLERS, 0x802A, "BH(cm){H}")
    def sig_model_subscription_list_handler(self, source, remote, net_index, fields):
        logger.info("sig_model_subscription_list")
        status, element_address, model_id = fields[:3]
        logger.info(
            "\tstatus: {}, element_address: {}, model_id: {}",
            status,
            element_address,
            model_id,
        )
        addresses = fields[3:]
        logger.info("\taddresses: {}", addresses)

        return {
            "status": status,
            "element_address": element_address,
            "addresses": addresses,
            "model_id": model_id,
        }

    @Model.dev_key_send(0x802B, "H(cM)")
    def vendor_model_subscription_get(self, dest, net_index, element_address, model_id):
        logger.info("sig_model_subscription_get : {} {}", element_address, model_id)
        return [element_address, model_id]

    @Model.dev_key_message_handler(HANDLERS, 0x802C, "BH(cM){H}")
    def vendor_model_subscription_list_handler(self, source, remote, net_index, fields):
        logger.info("sig_model_subscription_list")
        status, element_address, model_id = fields[:3]
        logger.info(
            "\tstatus: {}, element_address: {}, model_id: {}",
            status,
            element_address,
            model_id,
        )
        addresses = fields[3:]
        logger.info("\taddresses: {}", addresses)

        return {
            "status": status,
            "element_address": element_address,
            "addresses": addresses,
            "model_id": model_id,
        }

    @Model.dev_key_send(0x8038, "")
    def heartbeat_publication_get(self, dest, net_index):
        logger.info("heartbeat_publication_get")

    @Model.dev_key_send(0x803D, "H(ck)(c_m)")
    def model_app_bind(self, dest, net_index, element_address, app, model_id):
        logger.info("model_app_bind")
        return [element_address, app, model_id]

    @Model.dev_key_message_handler(HANDLERS, 0x803E, "BH(ck)(c_m)")
    def model_app_status_handler(self, source, remote, net_index, fields):
        status = fields[0]
        logger.info("model_app_status : status : {}", status)

        element_address = fields[1]
        app = fields[2]
        model_id = fields[3]
        logger.info(
            "element_address: {}, appkey_index: {}, model_id: {}",
            element_address,
            app,
            model_id,
        )
        return {
            "status": status,
            "element_address": element_address,
            "app_key_index": app,
            "model_id": model_id,
        }

    @Model.dev_key_send(0x803F, "H(ck)(c_m)")
    def model_app_unbind(self, dest, net_index, element_address, app, model_id):
        logger.info("model_app_unbind")
        return [element_address, app, model_id]

    @Model.dev_key_send(0x8040, "(ck)r16")
    def netkey_add(self, dest, net_index, net, key):
        logger.info("netkey_add")
        return [net, key]

    @Model.dev_key_send(0x8041, "(ck)")
    def netkey_delete(self, dest, net_index, net):
        logger.info("netkey_delete")
        return [net]

    @Model.dev_key_send(0x8042, "")
    def netkey_get(self, dest, net_index):
        logger.info("netkey_get")

    @Model.dev_key_message_handler(HANDLERS, 0x8043, "{(c_k)}")
    def netkey_list_handler(self, source, remote, net_index, fields):
        logger.info("netkey_list")

        nets = []
        for combined_key in fields:
            if isinstance(combined_key, tuple):
                logger.info("\tnetkey_index: {}", combined_key[0])
                logger.info("\tnetkey_index: {}", combined_key[1])
                nets += combined_key
            else:
                logger.info("\tnetkey_index: {}", combined_key)
                nets.append(combined_key)

        return {"net_key_indexes": nets}

    @Model.dev_key_message_handler(HANDLERS, 0x8044, "B(ck)")
    def netkey_status_handler(self, source, remote, net_index, fields):
        status = fields[0]
        logger.info("netkey_status : status : {}", status)

        net = fields[1]
        logger.info("netkey_index: {}", net)

        return {"status": status, "net_key_index": net}

    @Model.dev_key_send(0x8049, "")
    def node_reset(self, dest, net_index):
        logger.info("node_reset")

    @Model.dev_key_message_handler(HANDLERS, 0x804A, "")
    def node_reset_status_handler(self, source, remote, net_index, fields):
        logger.info("note_reset_status")


def pack_key_index(key: int | tuple[int, int], signature: str) -> bytes:
    """Key indexes.

    * 'k': One 12-bit key index into two octets when key type is int.
    * 'K': Two 12-bit key index into three octets when key type is tuple.
    * '_k': Variable key index

    """
    if isinstance(key, int) and signature in ("ck", "c_k"):
        key_index = [0] * 2
        key_index[0] = key & 0xFF
        key_index[1] = (key & 0xF00) >> 8
        return struct.pack("<BB", *key_index)
    elif isinstance(key, tuple) and signature in ("cK", "c_k"):
        key1, key2 = key
        key_index = [0] * 3
        key_index[0] = key1 & 0xFF
        key_index[1] = (key1 & 0xF00) >> 8 | (key2 & 0x0F) << 4
        key_index[2] = (key2 & 0xFF0) >> 4
        return struct.pack("<BBB", *key_index)
    else:
        raise ValueError("pack_key_index")


def unpack_key_index(data: bytes, signature: str) -> tuple[tuple[int, int] | int, int]:
    """Key indexes.

    * 'k': One 12-bit key index into two octets when key type is int.
    * 'K': Two 12-bit key index into three octets when key type is tuple.
    * '_k': Variable key index

    """
    if signature == "ck" or signature == "c_k" and len(data) == 2:
        key = data[0] | (data[1] & 0x0F) << 8
        return key, 2
    elif signature == "cK" or signature == "c_k" and len(data) >= 3:
        key1 = data[0] | (data[1] & 0x0F) << 8
        key2 = (data[1] & 0xF0) >> 4 | data[2] << 4
        return (key1, key2), 3
    else:
        raise ValueError("unpack_key_index")


def pack_model_id(model_id: int, signature: str) -> bytes:
    """Model Identifier.

    * 'm': Two octets when it is SIG Model ID.
    * 'M': Four octets when it is Vendor Model ID.
    * '_m': Variable Model ID

    """
    if 0 <= model_id <= 0xFFFF and signature in ("cm", "c_m"):
        return struct.pack("<H", model_id)
    elif 0xFFFF < model_id <= 0xFFFFFFFF and signature in ("cM", "c_m"):
        return struct.pack("<HH", model_id >> 16, model_id & 0xFFFF)
    else:
        raise ValueError("pack_model_id")


def unpack_model_id(data: bytes, signature: str) -> tuple[int, int]:
    """Model Identifier.

    * 'm': Two octets when it is SIG Model ID.
    * 'M': Four octets when it is Vendor Model ID.
    * '_m': Variable Model ID

    """
    if signature == "cm" or signature == "c_m" and len(data) == 2:
        model_id = struct.unpack("<H", data[:2])[0]
        return model_id, 2
    elif signature == "cM" or signature == "c_m" and len(data) >= 4:
        vendor, model_id = struct.unpack("<HH", data[:4])
        return (vendor << 16) | model_id, 4
    else:
        raise ValueError("unpack_model_id")


def pack_heartbeat_period_log(period: int, signature: str) -> bytes:
    """Heartbeat Period Log

    * 'pp': Publication Period.
        Smallest n, when n >= log2(a) + 1
    * 'ps': Subscriptions Period.
        Largest n, when n <= log2(a) + 1

    """
    if period == 0:
        n = 0
    elif signature == "cpp":
        n = math.ceil(math.log2(period)) + 1
    else:
        n = math.floor(math.log2(period)) + 1

    return struct.pack("<B", n)


def unpack_heartbeat_period_log(data: bytes, signature: str) -> tuple[Any, int]:
    # pylint: disable=unused-argument
    n = struct.unpack("<B", data[:1])[0]
    if n == 0:
        period = 0
    else:
        period = 2 ** (n - 1)

    return period, 1


def pack_heartbeat_count_log(count: int, signature: str) -> bytes:
    """Heartbeat Count Log

    * 'cp': Publication Period.
        Smallest n, when n >= log2(a) + 1
    * 'cs': Subscriptions Period.
        Largest n, when n <= log2(a) + 1

    """
    if count == 0:
        n = 0
    elif count == 0xFFFF:
        n = 0xFF
    elif signature == "ccp":
        n = math.ceil(math.log2(count)) + 1
    else:
        n = math.floor(math.log2(count)) + 1

    return struct.pack("<B", n)


def unpack_heartbeat_count_log(data: bytes, signature: str) -> tuple[Any, int]:
    # pylint: disable=unused-argument
    n = struct.unpack("<B", data[:1])[0]
    if n == 0:
        count = 0
    elif n == 0xFF:
        count = 0xFFFF
    else:
        count = 2 ** (n - 1)

    return count, 1


for _iter_integer_sign in ["ck", "cK", "c_k"]:
    AccessMessage.set_signature(
        _iter_integer_sign, pack_func=pack_key_index, unpack_func=unpack_key_index
    )
for _iter_integer_sign in ["cm", "cM", "c_m"]:
    AccessMessage.set_signature(
        _iter_integer_sign, pack_func=pack_model_id, unpack_func=unpack_model_id
    )
for _iter_integer_sign in ["cpp", "cps"]:
    AccessMessage.set_signature(
        _iter_integer_sign,
        pack_func=pack_heartbeat_period_log,
        unpack_func=unpack_heartbeat_period_log,
    )
for _iter_integer_sign in ["ccp", "ccs"]:
    AccessMessage.set_signature(
        _iter_integer_sign,
        pack_func=pack_heartbeat_count_log,
        unpack_func=unpack_heartbeat_count_log,
    )
