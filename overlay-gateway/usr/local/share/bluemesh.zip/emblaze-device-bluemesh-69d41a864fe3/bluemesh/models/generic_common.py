# -*- coding: utf-8 -*-
"""Bluemesh Generic Model common module"""
import struct
from functools import cache

import bluemesh.bluemesh_logging as logging
from bluemesh.access import AccessMessage

logger = logging.getLogger("bluemesh.models.generic_common")


class TIDProperty:
    """TID property"""

    def __init__(self):
        self._tid = 0

    @property
    def tid(self) -> int:
        tid = self._tid
        self._tid = (self._tid + 1) % 256
        return tid


class TransitionTime:
    """TransitionTime"""

    RESOUTION_TYPE = {0: 1, 1: 10, 2: 100, 3: 6000}

    @staticmethod
    def encode(value: int) -> bytes:
        if 0 <= value <= 62:
            step_resolution = 0
        elif 10 <= value <= 620:
            step_resolution = 1
        elif 100 <= value <= 6200:
            step_resolution = 2
        elif 600 <= value <= 372000:
            step_resolution = 3
        else:
            raise ValueError("TransitionTime value must be in range(0 ~ 372000 ms)")

        nr_steps = value // TransitionTime.RESOUTION_TYPE[step_resolution]
        return struct.pack("<B", nr_steps | step_resolution << 6)

    @staticmethod
    def decode(value: bytes) -> int:
        if len(value) != 1:
            raise ValueError("TransitionTime is 1 byte.")
        nr_steps = value[0] & 0x3F
        step_resolution = (value[0] & 0xC0) >> 6
        return nr_steps * TransitionTime.RESOUTION_TYPE[step_resolution]


def pack_transition_time(transition_time: float, signature: str) -> bytes:
    # pylint: disable=unused-argument
    return TransitionTime.encode(int(transition_time * 10))


def unpack_transition_time(data: bytes, signature: str) -> tuple[float, int]:
    # pylint: disable=unused-argument
    return TransitionTime.decode(data[:1]) / 10, 1


def pack_delay(delay: int, signature: str) -> bytes:
    # pylint: disable=unused-argument
    return struct.pack("<B", delay // 5)


def unpack_delay(data: bytes, signature: str) -> tuple[int, int]:
    # pylint: disable=unused-argument
    return struct.unpack("<B", data[:1])[0] * 5, 1


@cache
def set_signatures():
    AccessMessage.set_signature(
        "gtt", pack_func=pack_transition_time, unpack_func=unpack_transition_time
    )
    AccessMessage.set_signature("gd", pack_func=pack_delay, unpack_func=unpack_delay)
