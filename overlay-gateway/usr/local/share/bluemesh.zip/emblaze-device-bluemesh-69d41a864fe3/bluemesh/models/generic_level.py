# -*- coding: utf-8 -*-
"""Bluemesh GenericLevelClient Model"""
from typing import Callable

import bluemesh.bluemesh_logging as logging
import bluemesh.models.generic_common as common
from bluemesh.models.base import Model

logger = logging.getLogger("bluemesh.models.generic_level")


class GenericLevelClient(Model, common.TIDProperty):
    """GenericLevelClient"""

    # pylint: disable=too-many-arguments,unused-argument,too-many-public-methods
    MODEL_ID = 0x1003
    VENDOR = None
    HANDLERS: dict[int, Callable] = {}

    def __init__(self, element):
        Model.__init__(self, element)
        common.TIDProperty.__init__(self)

    @Model.send(0x8205, "")
    def get(self, dest, key_index):
        pass

    @Model.send(0x8206, "hB(gtt)(gd)")
    def set(self, dest, key_index, level, transition_time=None, delay=0):
        if transition_time is None:
            fields = [level, self.tid]
        else:
            fields = [level, self.tid, transition_time, delay]
        return fields

    @Model.send(0x8207, "hB(gtt)(gd)")
    def set_unack(self, dest, key_index, level, transition_time=None, delay=0):
        if transition_time is None:
            fields = [level, self.tid]
        else:
            fields = [level, self.tid, transition_time, delay]
        return fields

    @Model.message_handler(HANDLERS, 0x8208, "hh(gtt)")
    def status_handler(self, source, key_index, destination, fields):
        present_level = fields[0]
        logger.info("generic_level : {}", present_level)
        if len(fields) > 1:
            target_level = fields[1]
            remaining_time = fields[2]
            logger.info(
                "generic_level : target level: {}, remaining_time: {}",
                target_level,
                remaining_time,
            )
            return {
                "present_level": present_level,
                "target_level": target_level,
                "remaining_time": remaining_time,
            }

        else:
            return {"present_level": present_level}

    @Model.send(0x8209, "iB(gtt)(gd)")
    def delta_set(self, dest, key_index, delta_level, transition_time=None, delay=0):
        if transition_time is None:
            fields = [delta_level, self.tid]
        else:
            fields = [delta_level, self.tid, transition_time, delay]
        return fields

    @Model.send(0x820A, "iB(gtt)(gd)")
    def delta_set_unack(
        self, dest, key_index, delta_level, transition_time=None, delay=0
    ):
        if transition_time is None:
            fields = [delta_level, self.tid]
        else:
            fields = [delta_level, self.tid, transition_time, delay]
        return fields

    @Model.send(0x820B, "hB(gtt)(gd)")
    def move_set(self, dest, key_index, delta_level, transition_time=None, delay=0):
        if transition_time is None:
            fields = [delta_level, self.tid]
        else:
            fields = [delta_level, self.tid, transition_time, delay]
        return fields

    @Model.send(0x820C, "hB(gtt)(gd)")
    def move_set_unack(
        self, dest, key_index, delta_level, transition_time=None, delay=0
    ):
        if transition_time is None:
            fields = [delta_level, self.tid]
        else:
            fields = [delta_level, self.tid, transition_time, delay]
        return fields


common.set_signatures()
