# -*- coding: utf-8 -*-
"""Bluemesh LightLCClient Model"""
from typing import Callable

import bluemesh.bluemesh_logging as logging
import bluemesh.models.generic_common as common
from bluemesh import device_property
from bluemesh.models.base import Model

logger = logging.getLogger("bluemesh.models.light_lc")


class LightLCClient(Model, common.TIDProperty):
    """LightLCClient"""

    # pylint: disable=too-many-arguments,unused-argument,too-many-public-methods
    MODEL_ID = 0x1311
    VENDOR = None
    HANDLERS: dict[int, Callable] = {}

    def __init__(self, element):
        Model.__init__(self, element)
        common.TIDProperty.__init__(self)

    @Model.send(0x8291, "")
    def mode_get(self, dest, key_index):
        """Get the Light LC Mode state"""

    @Model.send(0x8292, "?")
    def mode_set(self, dest, key_index, mode):
        """Set the Light LC Mode state"""
        return [mode]

    @Model.send(0x8293, "?")
    def mode_set_unack(self, dest, key_index, mode):
        """Set the Light LC Mode state with unacknowledged message"""
        return [mode]

    @Model.message_handler(HANDLERS, 0x8294, "?")
    def mode_status_handler(self, source, key_index, destination, fields):
        """Report the Light LC Mode state"""
        mode = fields[0]
        logger.info("light lc mode : {}", mode)
        return {"mode": mode}

    @Model.send(0x8295, "")
    def om_get(self, dest, key_index):
        """Get the Light LC Occupancy Mode state"""

    @Model.send(0x8296, "?")
    def om_set(self, dest, key_index, mode):
        """Set the Light LC Occupancy Mode state"""
        return [mode]

    @Model.send(0x8297, "?")
    def om_set_unack(self, dest, key_index, mode):
        """Set the Light LC Occupancy Mode state with unacknowledged message"""
        return [mode]

    @Model.message_handler(HANDLERS, 0x8298, "?")
    def om_status_handler(self, source, key_index, destination, fields):
        """Report the Light LC Occupancy Mode state"""
        mode = fields[0]
        logger.info("light lc occupancy mode : {}", mode)
        return {"mode": mode}

    @Model.send(0x8299, "")
    def light_onoff_get(self, dest, key_index):
        """Get the Light LC Light OnOff state"""

    @Model.send(0x829A, "?B(gtt)(gd)")
    def light_onoff_set(
        self, dest, key_index, light_onoff, transition_time=None, delay=0
    ):
        """Set the Light LC Light OnOff state"""
        if transition_time is None:
            fields = [light_onoff, self.tid]
        else:
            fields = [light_onoff, self.tid, transition_time, delay]
        return fields

    @Model.send(0x829B, "?B(gtt)(gd)")
    def light_onoff_set_unack(
        self, dest, key_index, light_onoff, transition_time=None, delay=0
    ):
        """Set the Light LC Light OnOff state with unacknowledged message"""
        if transition_time is None:
            fields = [light_onoff, self.tid]
        else:
            fields = [light_onoff, self.tid, transition_time, delay]
        return fields

    @Model.message_handler(HANDLERS, 0x829C, "??(gtt)")
    def light_onoff_status_handler(self, source, key_index, destination, fields):
        """Report the Light LC Light OnOff state"""
        present_light_onoff = fields[0]
        logger.info("light_onoff light_light_onoff : {}", present_light_onoff)
        if len(fields) > 1:
            target_light_onoff = fields[1]
            remaining_time = fields[2]
            logger.info(
                "light_onoff light_light_onoff : target light_onoff: {}, "
                "remaining_time: {}",
                target_light_onoff,
                remaining_time,
            )
            return {
                "present_light_onoff": present_light_onoff,
                "target_light_onoff": target_light_onoff,
                "remaining_time": remaining_time,
            }

        else:
            return {"present_light_onoff": present_light_onoff}

    @Model.send(0x829D, "H")
    def property_get(self, dest, key_index, property_id):
        """Get the Light LC Property state"""
        return [property_id]

    @Model.send(0x62, "Hr_")
    def property_set(self, dest, key_index, property_id, property_value):
        """Set the Light LC Property state"""
        return [property_id, device_property.pack(property_id, property_value)]

    @Model.send(0x63, "Hr_")
    def property_set_unack(self, dest, key_index, property_id, property_value):
        """Set the Light LC Property state with unacknowledged message"""
        return [property_id, device_property.pack(property_id, property_value)]

    @Model.message_handler(HANDLERS, 0x64, "Hr_")
    def property_status_handler(self, source, key_index, destination, fields):
        """Report the Light LC Property state"""
        property_id = fields[0]
        property_value = device_property.unpack(property_id, fields[1])
        logger.info("light lc property: id({}) - {}", property_id, property_value)
        return {"property_id": property_id, "property_value": property_value}


common.set_signatures()
