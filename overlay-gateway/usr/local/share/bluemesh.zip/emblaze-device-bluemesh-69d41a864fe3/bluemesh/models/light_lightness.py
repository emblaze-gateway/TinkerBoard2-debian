# -*- coding: utf-8 -*-
"""Bluemesh LightLightnessClient Model"""
from typing import Callable

import bluemesh.bluemesh_logging as logging
import bluemesh.models.generic_common as common
from bluemesh.models.base import Model

logger = logging.getLogger("bluemesh.models.light_lightness")


class LightLightnessClient(Model, common.TIDProperty):
    """LightLightnessClient"""

    # pylint: disable=too-many-arguments,unused-argument,too-many-public-methods
    MODEL_ID = 0x1302
    VENDOR = None
    HANDLERS: dict[int, Callable] = {}

    def __init__(self, element):
        Model.__init__(self, element)
        common.TIDProperty.__init__(self)

    @Model.send(0x824B, "")
    def get(self, dest, key_index):
        """Get the Light Lightness Actual state"""

    @Model.send(0x824C, "HB(gtt)(gd)")
    def set(self, dest, key_index, lightness, transition_time=None, delay=0):
        """Set the Light Lightness Actual state"""
        if transition_time is None:
            fields = [lightness, self.tid]
        else:
            fields = [lightness, self.tid, transition_time, delay]
        return fields

    @Model.send(0x824D, "HB(gtt)(gd)")
    def set_unack(self, dest, key_index, lightness, transition_time=None, delay=0):
        """Set the Light Lightness Actual state with unacknowledged message"""
        if transition_time is None:
            fields = [lightness, self.tid]
        else:
            fields = [lightness, self.tid, transition_time, delay]
        return fields

    @Model.message_handler(HANDLERS, 0x824E, "HH(gtt)")
    def status_handler(self, source, key_index, destination, fields):
        """Report the Light Lightness Actual state"""
        present_lightness = fields[0]
        logger.info("actual light_lightness : {}", present_lightness)
        if len(fields) > 1:
            target_lightness = fields[1]
            remaining_time = fields[2]
            logger.info(
                "actual light_lightness : target lightness: {}, remaining_time: {}",
                target_lightness,
                remaining_time,
            )
            return {
                "present_lightness": present_lightness,
                "target_lightness": target_lightness,
                "remaining_time": remaining_time,
            }

        else:
            return {"present_lightness": present_lightness}

    @Model.send(0x824F, "")
    def linear_get(self, dest, key_index):
        """Get the Light Lightness Linear state"""

    @Model.send(0x8250, "HB(gtt)(gd)")
    def linear_set(self, dest, key_index, lightness, transition_time=None, delay=0):
        """Set the Light Lightness Linear state"""
        if transition_time is None:
            fields = [lightness, self.tid]
        else:
            fields = [lightness, self.tid, transition_time, delay]
        return fields

    @Model.send(0x8251, "HB(gtt)(gd)")
    def linear_set_unack(
        self, dest, key_index, lightness, transition_time=None, delay=0
    ):
        """Set the Light Lightness Linear state with unacknowledged message"""
        if transition_time is None:
            fields = [lightness, self.tid]
        else:
            fields = [lightness, self.tid, transition_time, delay]
        return fields

    @Model.message_handler(HANDLERS, 0x8252, "HH(gtt)")
    def linear_status_handler(self, source, key_index, destination, fields):
        """Report the Light Lightness Linear state"""
        present_lightness = fields[0]
        logger.info("linear light_lightness : {}", present_lightness)
        if len(fields) > 1:
            target_lightness = fields[1]
            remaining_time = fields[2]
            logger.info(
                "linear light_lightness : target lightness: {}, remaining_time: {}",
                target_lightness,
                remaining_time,
            )
            return {
                "present_lightness": present_lightness,
                "target_lightness": target_lightness,
                "remaining_time": remaining_time,
            }

        else:
            return {"present_lightness": present_lightness}

    @Model.send(0x8253, "")
    def last_get(self, dest, key_index):
        """Get the Light Lightness Last state"""

    @Model.message_handler(HANDLERS, 0x8254, "H")
    def last_status_handler(self, source, key_index, destination, fields):
        """Report the Light Lightness Last state"""
        lightness = fields[0]
        logger.info("last light_lightness : {}", lightness)
        return {"lightness": lightness}

    @Model.send(0x8255, "")
    def default_get(self, dest, key_index):
        """Get the Light Lightness Default state"""

    @Model.message_handler(HANDLERS, 0x8256, "H")
    def default_status_handler(self, source, key_index, destination, fields):
        """Report the Light Lightness Default state"""
        lightness = fields[0]
        logger.info("default light_lightness : {}", lightness)
        return {"lightness": lightness}

    @Model.send(0x8257, "")
    def range_get(self, dest, key_index):
        """Get the Light Lightness Range state"""

    @Model.message_handler(HANDLERS, 0x8258, "BHH")
    def range_status_handler(self, source, key_index, destination, fields):
        """Report the Light Lightness Range state"""
        status_code = fields[0]
        range_min = fields[1]
        range_max = fields[2]
        logger.info("range light_lightness status : {}", status_code)
        logger.info("range light_lightness : {} ~ {}", range_min, range_max)
        return {
            "status_code": status_code,
            "range_min": range_min,
            "range_max": range_max,
        }

    @Model.send(0x8259, "H")
    def default_set(self, dest, key_index, lightness):
        """Set the Light Lightness Default state"""
        return [lightness]

    @Model.send(0x825A, "H")
    def default_set_unack(self, dest, key_index, lightness):
        """Set the Light Lightness Default state with unacknowledged message"""
        return [lightness]

    @Model.send(0x825B, "HH")
    def range_set(self, dest, key_index, range_min, range_max):
        """Set the Light Lightness range state"""
        return [range_min, range_max]

    @Model.send(0x825C, "HH")
    def range_set_unack(self, dest, key_index, range_min, range_max):
        """Set the Light Lightness range state with unacknowledged message"""
        return [range_min, range_max]


common.set_signatures()
