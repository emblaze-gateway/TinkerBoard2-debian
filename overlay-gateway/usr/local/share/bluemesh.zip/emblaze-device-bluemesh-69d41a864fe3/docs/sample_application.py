"""SampleApplication"""
import json
import uuid as _uuid

import bluemesh.bluemesh_logging as logging
from bluemesh.application import Application, ApplicationBuilder, ApplicationError
from bluemesh.element import Element
from bluemesh.models import (
    ConfigClient,
    GenericLevelClient,
    LightLCClient,
    LightLightnessClient,
)

logging.addStreamHandler("bluemesh", None, "INFO")
logging.addFileHandler(
    "bluemesh",
    "log.log",
    "DEBUG",
    logformat="%(asctime)s - %(name)s - %(funcName)s - %(processName)s"
    + "(%(process)d) - %(threadName)s(%(thread)d) - %(levelname)s"
    + "- %(message)s",
)


class GenericClientElement(Element):
    """GenericElement"""

    MODEL_CLASSES = [
        ConfigClient,
        GenericLevelClient,
    ]


class LightClientElement(Element):
    """LightElement"""

    MODEL_CLASSES = [
        LightLightnessClient,
        LightLCClient,
    ]


class SampleApplication(Application):
    """SampleApplication"""

    COMPANY_ID: int = 0x05F1  # Linux Foundation
    PRODUCT_ID: int = 0x0001
    VERSION_ID: int = 0x0001

    ELEMENT_CLASSES = [
        GenericClientElement,
        LightClientElement,
    ]


def build_attach(builder, token):
    builder.set_token(token)
    try:
        app = builder.build_attach()
    except AttributeError as e:
        print(f"AttributeError: {e}")
        app = None
    except ApplicationError as e:
        print(f"ApplicationError: {e}")
        app = None
    print("Attached")
    return app


def build_import_attach(builder, path):
    builder.set_address(1)
    builder.set_primary_net_key((0, bytes.fromhex("18eed9c2a56add85049ffc3c59ad0e12")))
    builder.set_dev_key(bytes.fromhex("deadbeefdeadbeefdeadbeefdeadbeef"))
    builder.set_iv_index(0)
    builder.set_iv_update(False)
    builder.set_key_refresh(False)
    try:
        app = builder.build_import_attach()
    except AttributeError as e:
        print(f"AttributeError: {e}")
        app = None
    except ApplicationError as e:
        print(f"ApplicationError: {e}")
        app = None
    if app:
        data = {"token": hex(app.token)}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f)
            print("set token")
    return app


def main(path, queue):
    builder = ApplicationBuilder(SampleApplication, "/bluemesh/sample", "dbus-python")
    builder.set_uuid(_uuid.uuid1())
    print("Builder SampleApplication")

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            token = int(data["token"], 16)
            print("get token")
    except FileNotFoundError:
        imported_before = False
    else:
        imported_before = True

    if imported_before:
        app = build_attach(builder, token)
    else:
        app = build_import_attach(builder, path)

    if app:
        app.import_app_key(0, 0, bytes.fromhex("4f68ad85d9f48ac8589df665b6b49b8a"))
        if queue:
            app.register_queue(queue)

    return app
