.. bluemesh documentation master file, created by
   sphinx-quickstart on Fri Dec 16 10:51:07 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to bluemesh's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   modules
   README


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
