"""
setup.py
"""
import logging
import unittest

try:
    import coverage  # type: ignore # pylint: disable=import-error
except ImportError:
    logging.warning(
        "coverage is not found. You need to install coverage if you want to report "
        "coverage."
    )
from setuptools import find_packages, setup
from setuptools.command.build_py import build_py as _build_py

try:
    # type: ignore # pylint: disable=import-error
    from sphinx.setup_command import BuildDoc
except ImportError:

    class BuildDoc(_build_py):  # type: ignore
        """Dummy documentation class"""

        def run(self):
            logging.error(
                "Sphinx has not installed. You have to install documentations packages."
                "\nHint: 'pip install bluemesh[docs]'"
            )

    logging.warning(
        "Sphinx is not found. You need to install sphinx if you want to make docs."
    )


def _testing():
    loader = unittest.TestLoader()
    suite = loader.discover("test", pattern="test*.py")
    runner = unittest.TextTestRunner(verbosity=1)
    runner.run(suite)


class TestCommand(_build_py):
    """Test Command"""

    def run(self):
        _testing()


class CoverageCommand(_build_py):
    """Coverage Command"""

    def run(self):
        cov = coverage.Coverage()
        cov.start()
        _testing()
        cov.stop()
        cov.save()
        cov.html_report()


with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

install_requires = ["wheel==0.37.1", "numpy==1.23.1", "dbus-python==1.2.18"]

test_requires = [
    "coverage==6.4.3",
]

docs_requires = [
    "Sphinx==5.0.2",
    "sphinx_rtd_theme==0.4.3",
    "myst-parser==0.18.1",
]

RELEASE = "0.1.0"
VERSION = "0.1"

# fmt: off
setup(
    name="bluemesh",
    version=RELEASE,
    author="Junho Lee",
    author_email="jhlee@neostack.co.kr",
    description="The bluetooth mesh SDK for Python on Bluez",
    keywords=['Bluez', 'Bluetooth', 'Bluetooth mesh', 'BLE'],
    classifiers=[
        "Programming Language :: Python :: 3.10",
        'Programming Language :: Python :: 3 :: Only',
        'Programming Language :: Python :: Implementation :: CPython',
        'Programming Language :: Python :: Implementation :: PyPy',
        # "License :: OSI Approved :: MIT License",
        # "Operating System :: OS Independent"
        "Operating System :: POSIX :: Linux"
    ],
    python_requires='>=3.10',
    url='https://github.com/tot0rokr/bluemesh',
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(exclude=('test*',)),
    package_data={"bluemesh": ["cdb-schema.json", "cdb-example.json"]},
    install_requires=install_requires,
    tests_require=test_requires,
    extras_require={
        'test': test_requires,
        'docs': docs_requires,
    },
    cmdclass={
        'build_sphinx': BuildDoc,
        'test': TestCommand,
        'coverage': CoverageCommand,
    },
    command_options={
        'build_sphinx': {
            'project': ('setup.py', "bluemesh"),
            'version': ('setup.py', VERSION),
            'release': ('setup.py', RELEASE),
            'source_dir': ('setup.py', "docs/source"),
            'build_dir': ('setup.py', "docs/sphinx"),
        }
    },
)
