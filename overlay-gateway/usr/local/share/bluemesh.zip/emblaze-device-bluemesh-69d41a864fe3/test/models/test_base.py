# -*- coding: utf-8 -*-
import unittest
from unittest.mock import MagicMock

import bluemesh.models.base as base


class TestModel(unittest.TestCase):
    def setUp(self):
        self.element = MagicMock()

        class TestModel(base.Model):
            MODEL_ID = 0xDEAD
            VENDOR = 0xBEEF
            HANDLERS = {}

        self.model = TestModel(self.element)

    def test_new_instance(self):
        self.assertEqual(self.model.model_id, (0xBEEF, 0xDEAD))

        with self.assertRaises(TypeError):
            base.Model(self.element)

        class WrongModel1(base.Model):
            pass

        class WrongModel2(base.Model):
            MODEL_ID = 0xDEAD

        class WrongModel3(base.Model):
            MODEL_ID = 0xDEAD
            VENDOR = 0xBEEF

        with self.assertRaises(AttributeError):
            WrongModel1(self.element)

        with self.assertRaises(AttributeError):
            WrongModel2(self.element)

        with self.assertRaises(AttributeError):
            WrongModel3(self.element)

    def test_set_config(self):
        config = {
            "Bindings": [1, 2, 3, 4],
            "PublicationPeriod": [1, 10, 100, 6000],
            "Subscriptions": [
                0xC001,
                [150, 185, 27, 214, 161, 10, 17, 237, 162, 234, 0, 21, 93, 115, 8, 164],
                0xFFFF,
            ],
        }
        self.model.set_config(config)
        self.assertEqual(self.model.bindings, [1, 2, 3, 4])
        self.assertEqual(self.model.publication_period, [1, 10, 100, 6000])
        self.assertEqual(
            self.model.subscriptions,
            [
                0xC001,
                b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4",
                0xFFFF,
            ],
        )

    def test_message_received(self):
        @self.model.message_handler(self.model.HANDLERS, 0x9988, "HH")
        def handler(self, source, key_index, destination, data):
            return {k: v for k, v in zip(["a", "b"], [0xDEAD, 0xBEEF])}

        ret = self.model.message_received(
            1, 2, 3, bytes([0x99, 0x88, 0xAD, 0xDE, 0xEF, 0xBE])
        )
        self.assertEqual(
            ret,
            {
                "opcode": 0x9988,
                "source": 1,
                "key_index": 2,
                "destination": 3,
                "fields": {"a": 0xDEAD, "b": 0xBEEF},
            },
        )

        @self.model.dev_key_message_handler(self.model.HANDLERS, 0x9977, "HH")
        def handler(self, source, remote, key_index, data):
            return {k: v for k, v in zip(["a", "b"], [0xDEAD, 0xBEEF])}

        ret = self.model.dev_key_message_received(
            1, 2, 3, bytes([0x99, 0x77, 0xAD, 0xDE, 0xEF, 0xBE])
        )
        self.assertEqual(
            ret,
            {
                "opcode": 0x9977,
                "source": 1,
                "remote": 2,
                "net_index": 3,
                "fields": {"a": 0xDEAD, "b": 0xBEEF},
            },
        )

    def test_send(self):
        @self.model.send(0x9988, "HH")
        def sender(self, destination, key_index, a, b):
            return [a, b]

        sender(self.model, 1, 2, 0xDEAD, 0xBEEF, use_repeat=True)
        self.element.send.assert_called_once_with(
            1, 2, bytes([0x99, 0x88, 0xAD, 0xDE, 0xEF, 0xBE]), False
        )
        self.element.send(None)
        self.element.send.assert_called_with(None)
        self.model.repeat()
        self.element.send.assert_called_with(
            1, 2, bytes([0x99, 0x88, 0xAD, 0xDE, 0xEF, 0xBE]), False
        )

        @self.model.dev_key_send(0x9977, "HH")
        def sender(self, destination, net_index, a, b):
            return [a, b]

        sender(self.model, 1, 2, 0xDEAD, 0xBEEF, use_repeat=True)
        self.element.dev_key_send.assert_called_once_with(
            1, 2, bytes([0x99, 0x77, 0xAD, 0xDE, 0xEF, 0xBE]), True, False
        )
        self.element.dev_key_send(None)
        self.element.dev_key_send.assert_called_with(None)
        self.model.repeat()
        self.element.dev_key_send.assert_called_with(
            1, 2, bytes([0x99, 0x77, 0xAD, 0xDE, 0xEF, 0xBE]), True, False
        )
