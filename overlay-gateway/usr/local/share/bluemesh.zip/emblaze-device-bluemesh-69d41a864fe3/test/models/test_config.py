# -*- coding: utf-8 -*-
import unittest

import bluemesh.models.config as config


class DummyElement:
    def send(self, *args, **kwargs):
        pass

    def dev_key_send(self, *args, **kwargs):
        pass


class TestConfig(unittest.TestCase):
    def setUp(self):
        self.conf = config.ConfigClient(DummyElement())

    def test_appkey_add(self):
        # first data is opcode
        ret = self.conf.appkey_add(None, None, 1, 2, bytes(16))
        self.assertEqual(ret, bytes([0x00, 0x01, 0x20, 0x00]) + bytes(16))

    def test_composition_data_status_handler(self):
        # first data is opcode
        data = bytes.fromhex(
            "02000100020003000400050001000202010000010200000000020000020001001111"
        )
        ret = self.conf.composition_data_status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {
                "page": 0,
                "cid": 1,
                "pid": 2,
                "vid": 3,
                "crpl": 4,
                "features": {
                    "relay": True,
                    "proxy": False,
                    "friend": True,
                    "low_power": False,
                },
                "elements": [
                    {
                        "loc": 1,
                        "sig_models": [0x0001, 0x0100],
                        "vendor_models": [0x00000002, 0x00000200],
                    },
                    {"loc": 2, "sig_models": [0x1111], "vendor_models": []},
                ],
            },
        )

    def test_model_publication_set(self):
        ret = self.conf.model_publication_set(
            None, None, 2, 10, 0, 1, 0xFF, 10, 3, 1200, 0x0CF10001
        )
        self.assertEqual(
            ret,
            bytes(
                [
                    0x03,
                    0x02,
                    0x00,
                    0x0A,
                    0x00,
                    0x00,
                    0x10,
                    0xFF,
                    0x4A,
                    0xBB,
                    0xF1,
                    0x0C,
                    0x01,
                    0x00,
                ]
            ),
        )
        with self.assertRaises(ValueError):
            ret = self.conf.model_publication_set(
                None, None, 2, 10, 0, 1, 0xFF, 10, 3, 1600, 0x0CF10001
            )
        with self.assertRaises(ValueError):
            ret = self.conf.model_publication_set(
                None, None, 2, 10, 0, 1, 0xFF, 10, 3, 29, 0x0CF10001
            )
        with self.assertRaises(ValueError):
            ret = self.conf.model_publication_set(
                None, None, 2, 10, 0, 1, 0xFF, 10, 8, 1200, 0x0CF10001
            )
        with self.assertRaises(ValueError):
            ret = self.conf.model_publication_set(
                None, None, 2, 10, 0, 1, 0x80, 10, 3, 1200, 0x0CF10001
            )

    def test_heartbeat_publication_status_handler(self):
        data = bytes.fromhex("060012340304020A000A00")
        ret = self.conf.heartbeat_publication_status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {
                "status": 0,
                "destination": 0x3412,
                "count": 4,
                "period": 8,
                "ttl": 2,
                "features": [False, True, False, True],
                "net_key_index": 10,
            },
        )

    def test_appkey_delete(self):
        ret = self.conf.appkey_delete(None, None, 1, 2)
        self.assertEqual(ret, bytes([0x80, 0x00, 0x01, 0x20, 0x00]))

    def test_appkey_get(self):
        ret = self.conf.appkey_get(None, None, 1)
        self.assertEqual(ret, bytes([0x80, 0x01, 0x01, 0x00]))

    def test_appkey_list_handler(self):
        data = bytes.fromhex("80020001000230000450000600")
        ret = self.conf.appkey_list_handler(None, None, None, data)
        self.assertEqual(
            ret, {"status": 0, "net_key_index": 1, "app_key_indexes": [2, 3, 4, 5, 6]}
        )

    def test_appkey_status_handler(self):
        data = bytes.fromhex("800300012000")
        ret = self.conf.appkey_status_handler(None, None, None, data)
        self.assertEqual(ret, {"status": 0, "net_key_index": 1, "app_key_index": 2})

    def test_composition_data_get(self):
        ret = self.conf.composition_data_get(None, None, 1)
        self.assertEqual(ret, bytes([0x80, 0x08, 0x01]))

    def test_default_ttl_get(self):
        ret = self.conf.default_ttl_get(None, None)
        self.assertEqual(ret, bytes([0x80, 0x0C]))

    def test_default_ttl_set(self):
        ret = self.conf.default_ttl_set(None, None, 1)
        self.assertEqual(ret, bytes([0x80, 0x0D, 1]))

    def test_default_ttl_status_handler(self):
        data = bytes.fromhex("800E02")
        ret = self.conf.default_ttl_status_handler(None, None, None, data)
        self.assertEqual(ret, {"ttl": 2})

    def test_model_publication_get(self):
        ret = self.conf.model_publication_get(None, None, 2, 0x0CF10001)
        self.assertEqual(ret, bytes([0x80, 0x18, 0x02, 0x00, 0xF1, 0x0C, 0x01, 0x00]))
        ret = self.conf.model_publication_get(None, None, 10, 0x0001)
        self.assertEqual(ret, bytes([0x80, 0x18, 0x0A, 0x00, 0x01, 0x00]))

    def test_model_publication_status_handler(self):
        data = bytes.fromhex("80190002000A000010FF4ABB0100F10C")
        ret = self.conf.model_publication_status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {
                "status": 0,
                "element_address": 2,
                "publish_address": 10,
                "app_key_index": 0,
                "credential_flag": 1,
                "ttl": 0xFF,
                "period": 10,
                "rtx_cnt": 3,
                "rtx_interval": 1200,
                "model_id": 0x00010CF1,
            },
        )

    def test_model_publication_virtual_address_set(self):
        ret = self.conf.model_publication_virtual_address_set(
            None,
            None,
            2,
            "96b91bd6-a10a-11ed-a2ea-00155d7308a4",
            0,
            1,
            0xFF,
            10,
            3,
            1200,
            0x0CF10001,
        )
        self.assertEqual(
            ret,
            bytes([0x80, 0x1A, 0x02, 0x00])
            + b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4"
            + bytes([0x00, 0x10, 0xFF, 0x4A, 0xBB, 0xF1, 0x0C, 0x01, 0x00]),
        )

    def test_model_subscription_add(self):
        ret = self.conf.model_subscription_add(None, None, 2, 10, 0x0CF10001)
        self.assertEqual(
            ret, bytes([0x80, 0x1B, 0x02, 0x00, 0x0A, 0x00, 0xF1, 0x0C, 0x01, 0x00])
        )
        ret = self.conf.model_subscription_add(None, None, 2, 10, 0x0001)
        self.assertEqual(ret, bytes([0x80, 0x1B, 0x02, 0x00, 0x0A, 0x00, 0x01, 0x00]))

    def test_model_subscription_delete(self):
        ret = self.conf.model_subscription_delete(None, None, 2, 10, 0x0CF10001)
        self.assertEqual(
            ret, bytes([0x80, 0x1C, 0x02, 0x00, 0x0A, 0x00, 0xF1, 0x0C, 0x01, 0x00])
        )
        ret = self.conf.model_subscription_delete(None, None, 2, 10, 0x0001)
        self.assertEqual(ret, bytes([0x80, 0x1C, 0x02, 0x00, 0x0A, 0x00, 0x01, 0x00]))

    def test_model_subscription_delete_all(self):
        ret = self.conf.model_subscription_delete_all(None, None, 10, 0x0CF10001)
        self.assertEqual(ret, bytes([0x80, 0x1D, 0x0A, 0x00, 0xF1, 0x0C, 0x01, 0x00]))
        ret = self.conf.model_subscription_delete_all(None, None, 2, 0x0001)
        self.assertEqual(ret, bytes([0x80, 0x1D, 0x02, 0x00, 0x01, 0x00]))

    def test_model_subscription_overwrite(self):
        ret = self.conf.model_subscription_overwrite(None, None, 2, 10, 0x0CF10001)
        self.assertEqual(
            ret, bytes([0x80, 0x1E, 0x02, 0x00, 0x0A, 0x00, 0xF1, 0x0C, 0x01, 0x00])
        )
        ret = self.conf.model_subscription_overwrite(None, None, 2, 10, 0x0001)
        self.assertEqual(ret, bytes([0x80, 0x1E, 0x02, 0x00, 0x0A, 0x00, 0x01, 0x00]))

    def test_model_subscription_status_handler(self):
        data = bytes.fromhex("801F0002000A00F10C0100")
        ret = self.conf.model_subscription_status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {"status": 0, "element_address": 2, "address": 10, "model_id": 0x0CF10001},
        )

    def test_model_subscription_virtual_address_add(self):
        ret = self.conf.model_subscription_virtual_address_add(
            None, None, 2, "96b91bd6-a10a-11ed-a2ea-00155d7308a4", 0x0CF10001
        )
        self.assertEqual(
            ret,
            bytes([0x80, 0x20, 0x02, 0x00])
            + b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4"
            + bytes([0xF1, 0x0C, 0x01, 0x00]),
        )
        ret = self.conf.model_subscription_virtual_address_add(
            None, None, 2, "96b91bd6-a10a-11ed-a2ea-00155d7308a4", 0x0001
        )
        self.assertEqual(
            ret,
            bytes([0x80, 0x20, 0x02, 0x00])
            + b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4"
            + bytes([0x01, 0x00]),
        )

    def test_model_subscription_virtual_address_delete(self):
        ret = self.conf.model_subscription_virtual_address_delete(
            None, None, 2, "96b91bd6-a10a-11ed-a2ea-00155d7308a4", 0x0CF10001
        )
        self.assertEqual(
            ret,
            bytes([0x80, 0x21, 0x02, 0x00])
            + b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4"
            + bytes([0xF1, 0x0C, 0x01, 0x00]),
        )
        ret = self.conf.model_subscription_virtual_address_delete(
            None, None, 2, "96b91bd6-a10a-11ed-a2ea-00155d7308a4", 0x0001
        )
        self.assertEqual(
            ret,
            bytes([0x80, 0x21, 0x02, 0x00])
            + b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4"
            + bytes([0x01, 0x00]),
        )

    def test_model_subscription_virtual_address_overwrite(self):
        ret = self.conf.model_subscription_virtual_address_overwrite(
            None, None, 2, "96b91bd6-a10a-11ed-a2ea-00155d7308a4", 0x0CF10001
        )
        self.assertEqual(
            ret,
            bytes([0x80, 0x22, 0x02, 0x00])
            + b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4"
            + bytes([0xF1, 0x0C, 0x01, 0x00]),
        )
        ret = self.conf.model_subscription_virtual_address_overwrite(
            None, None, 2, "96b91bd6-a10a-11ed-a2ea-00155d7308a4", 0x0001
        )
        self.assertEqual(
            ret,
            bytes([0x80, 0x22, 0x02, 0x00])
            + b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4"
            + bytes([0x01, 0x00]),
        )

    def test_network_transmit_get(self):
        ret = self.conf.network_transmit_get(None, None)
        self.assertEqual(ret, bytes([0x80, 0x23]))

    def test_network_transmit_set(self):
        ret = self.conf.network_transmit_set(None, None, 5, 100)
        self.assertEqual(ret, bytes([0x80, 0x24, 0x4D]))
        with self.assertRaises(ValueError):
            ret = self.conf.network_transmit_set(None, None, 8, 100)
        with self.assertRaises(ValueError):
            ret = self.conf.network_transmit_set(None, None, 5, 1000)

    def test_network_transmit_status_handler(self):
        data = bytes.fromhex("80254D")
        ret = self.conf.network_transmit_status_handler(None, None, None, data)
        self.assertEqual(ret, {"tx_cnt": 5, "tx_interval": 100})

    def test_relay_get(self):
        ret = self.conf.relay_get(None, None)
        self.assertEqual(ret, bytes([0x80, 0x26]))

    def test_relay_set(self):
        ret = self.conf.relay_set(None, None, 2, 5, 100)
        self.assertEqual(ret, bytes([0x80, 0x27, 0x02, 0x4D]))
        with self.assertRaises(ValueError):
            ret = self.conf.relay_set(None, None, 2, 8, 100)
        with self.assertRaises(ValueError):
            ret = self.conf.relay_set(None, None, 2, 5, 1000)

    def test_relay_status_handler(self):
        data = bytes.fromhex("8028024D")
        ret = self.conf.relay_status_handler(None, None, None, data)
        self.assertEqual(ret, {"relay": 2, "rtx_cnt": 5, "rtx_interval": 100})

    def test_sig_model_subscription_get(self):
        ret = self.conf.sig_model_subscription_get(None, None, 2, 0x0002)
        self.assertEqual(ret, bytes([0x80, 0x29, 0x02, 0x00, 0x02, 0x00]))

    def test_sig_model_subscription_list_handler(self):
        data = bytes.fromhex("802A050200020001000200030004000500")
        ret = self.conf.sig_model_subscription_list_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {
                "status": 5,
                "element_address": 2,
                "model_id": 0x0002,
                "addresses": [1, 2, 3, 4, 5],
            },
        )

    def test_vendor_model_subscription_get(self):
        ret = self.conf.vendor_model_subscription_get(None, None, 2, 0x01010002)
        self.assertEqual(ret, bytes([0x80, 0x2B, 0x02, 0x00, 0x01, 0x01, 0x02, 0x00]))

    def test_vendor_model_subscription_list_handler(self):
        data = bytes.fromhex("802C0502000200010101000200030004000500")
        ret = self.conf.vendor_model_subscription_list_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {
                "status": 5,
                "element_address": 2,
                "model_id": 0x00020101,
                "addresses": [1, 2, 3, 4, 5],
            },
        )

    def test_heartbeat_publication_get(self):
        ret = self.conf.heartbeat_publication_get(None, None)
        self.assertEqual(ret, bytes([0x80, 0x38]))

    def test_model_app_bind(self):
        ret = self.conf.model_app_bind(None, None, 4522, 1, 0x9999)
        self.assertEqual(ret, bytes([0x80, 0x3D, 0xAA, 0x11, 0x01, 0x00, 0x99, 0x99]))
        ret = self.conf.model_app_bind(None, None, 4522, 1, 0xAAAA9999)
        self.assertEqual(
            ret, bytes([0x80, 0x3D, 0xAA, 0x11, 0x01, 0x00, 0xAA, 0xAA, 0x99, 0x99])
        )

    def test_model_app_status_handler(self):
        data = bytes.fromhex("803E00AA1101009999")
        ret = self.conf.model_app_status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {
                "status": 0,
                "element_address": 4522,
                "app_key_index": 1,
                "model_id": 0x9999,
            },
        )
        data = bytes.fromhex("803E00AA1101009999AAAA")
        ret = self.conf.model_app_status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {
                "status": 0,
                "element_address": 4522,
                "app_key_index": 1,
                "model_id": 0x9999AAAA,
            },
        )

    def test_model_app_unbind(self):
        ret = self.conf.model_app_unbind(None, None, 4522, 1, 0x9900)
        self.assertEqual(ret, bytes([0x80, 0x3F, 0xAA, 0x11, 0x01, 0x00, 0x00, 0x99]))
        ret = self.conf.model_app_unbind(None, None, 4522, 1, 0x9900AA11)
        self.assertEqual(
            ret, bytes([0x80, 0x3F, 0xAA, 0x11, 0x01, 0x00, 0x00, 0x99, 0x11, 0xAA])
        )

    def test_netkey_add(self):
        ret = self.conf.netkey_add(None, None, 1, bytes(16))
        self.assertEqual(ret, bytes([0x80, 0x40, 0x01, 0x00]) + bytes(16))

    def test_netkey_delete(self):
        ret = self.conf.netkey_delete(None, None, 1)
        self.assertEqual(ret, bytes([0x80, 0x41, 0x01, 0x00]))

    def test_netkey_get(self):
        ret = self.conf.netkey_get(None, None)
        self.assertEqual(ret, bytes([0x80, 0x42]))

    def test_netkey_list_handler(self):
        data = bytes.fromhex("80430230000450000600")
        ret = self.conf.netkey_list_handler(None, None, None, data)
        self.assertEqual(ret, {"net_key_indexes": [2, 3, 4, 5, 6]})

    def test_netkey_status_handler(self):
        data = bytes.fromhex("8044000100")
        ret = self.conf.netkey_status_handler(None, None, None, data)
        self.assertEqual(ret, {"status": 0, "net_key_index": 1})

    def test_node_reset(self):
        ret = self.conf.node_reset(None, None)
        self.assertEqual(ret, bytes([0x80, 0x49]))

    def test_node_reset_status_handler(self):
        data = bytes.fromhex("804A")
        ret = self.conf.node_reset_status_handler(None, None, None, data)
        self.assertEqual(ret, None)
