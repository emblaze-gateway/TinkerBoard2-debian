# -*- coding: utf-8 -*-
import unittest

import bluemesh.models.generic_common as common


class TestGenericCommon(unittest.TestCase):
    def test_TransitionTime_encode(self):
        self.assertEqual(common.TransitionTime.encode(0), bytes([0]))
        self.assertEqual(common.TransitionTime.encode(50), bytes([50]))
        self.assertEqual(common.TransitionTime.encode(62), bytes([62]))
        self.assertEqual(common.TransitionTime.encode(63), bytes([int("01000110", 2)]))
        self.assertEqual(common.TransitionTime.encode(72), bytes([int("01000111", 2)]))
        self.assertEqual(common.TransitionTime.encode(700), bytes([int("10000111", 2)]))
        self.assertEqual(
            common.TransitionTime.encode(6200), bytes([int("10111110", 2)])
        )
        self.assertEqual(
            common.TransitionTime.encode(7000), bytes([int("11000001", 2)])
        )
        self.assertEqual(
            common.TransitionTime.encode(11000), bytes([int("11000001", 2)])
        )
        self.assertEqual(
            common.TransitionTime.encode(307000), bytes([int("11110011", 2)])
        )
        with self.assertRaises(ValueError):
            common.TransitionTime.encode(-1)
        with self.assertRaises(ValueError):
            common.TransitionTime.encode(372001)

    def test_TransitionTime_decode(self):
        with self.assertRaises(ValueError):
            common.TransitionTime.decode(bytes([1, 2]))
        self.assertEqual(
            common.TransitionTime.decode(bytes([0])),
            0,
        )
        self.assertEqual(
            common.TransitionTime.decode(bytes([50])),
            50,
        )
        self.assertEqual(
            common.TransitionTime.decode(bytes([62])),
            62,
        )
        self.assertEqual(
            common.TransitionTime.decode(bytes([int("01000110", 2)])),
            60,
        )
        self.assertEqual(
            common.TransitionTime.decode(bytes([int("01000111", 2)])),
            70,
        )
        self.assertEqual(
            common.TransitionTime.decode(bytes([int("10000111", 2)])),
            700,
        )
        self.assertEqual(
            common.TransitionTime.decode(bytes([int("10111110", 2)])), 6200
        )
        self.assertEqual(
            common.TransitionTime.decode(bytes([int("11000001", 2)])), 6000
        )
        self.assertEqual(
            common.TransitionTime.decode(bytes([int("11000001", 2)])), 6000
        )
        self.assertEqual(
            common.TransitionTime.decode(bytes([int("11110011", 2)])), 306000
        )

    def test_pack_transition_time(self):
        self.assertEqual(common.pack_transition_time(0, ""), bytes([0]))
        self.assertEqual(common.pack_transition_time(5, ""), bytes([50]))
        self.assertEqual(common.pack_transition_time(6.2, ""), bytes([62]))
        self.assertEqual(
            common.pack_transition_time(6.3, ""), bytes([int("01000110", 2)])
        )
        self.assertEqual(
            common.pack_transition_time(7.2, ""), bytes([int("01000111", 2)])
        )
        self.assertEqual(
            common.pack_transition_time(70, ""), bytes([int("10000111", 2)])
        )

    def test_unpack_transition_time(self):
        self.assertEqual(
            common.unpack_transition_time(bytes([0]), "")[0],
            0,
        )
        self.assertEqual(
            common.unpack_transition_time(bytes([50]), "")[0],
            5,
        )
        self.assertEqual(
            common.unpack_transition_time(bytes([62]), "")[0],
            6.2,
        )
        self.assertEqual(
            common.unpack_transition_time(bytes([int("01000110", 2)]), "")[0],
            6.0,
        )
        self.assertEqual(
            common.unpack_transition_time(bytes([int("01000111", 2)]), "")[0],
            7.0,
        )
        self.assertEqual(
            common.unpack_transition_time(bytes([int("10000111", 2)]), "")[0],
            70,
        )

    def test_pack_delay(self):
        self.assertEqual(common.pack_delay(1002, ""), bytes([200]))

    def test_unpack_delay(self):
        self.assertEqual(common.unpack_delay(bytes([200]), "")[0], 1000)
