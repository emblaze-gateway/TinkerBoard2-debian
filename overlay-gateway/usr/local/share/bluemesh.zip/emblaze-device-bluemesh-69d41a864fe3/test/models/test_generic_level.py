# -*- coding: utf-8 -*-
import unittest

import bluemesh.models.generic_level as level


class DummyElement:
    def send(self, *args, **kwargs):
        pass

    def dev_key_send(self, *args, **kwargs):
        pass


class TestGenericLevel(unittest.TestCase):
    def setUp(self):
        self.client = level.GenericLevelClient(DummyElement())

    def test_tid(self):
        for i in range(1000):
            with self.subTest(i=i):
                self.assertEqual(self.client.tid, i % 256)

    def test_get(self):
        ret = self.client.get(None, None)
        self.assertEqual(ret, bytes([0x82, 0x05]))

    def test_set(self):
        ret = self.client.set(None, None, -30000)
        self.assertEqual(ret, bytes([0x82, 0x06, 0xD0, 0x8A, 0x00]))
        ret = self.client.set(None, None, 30000, 10)
        self.assertEqual(ret, bytes([0x82, 0x06, 0x30, 0x75, 0x01, 0x4A, 0x00]))
        ret = self.client.set_unack(None, None, -30000)
        self.assertEqual(ret, bytes([0x82, 0x07, 0xD0, 0x8A, 0x02]))
        ret = self.client.set_unack(None, None, 0, 0.5, 100)
        self.assertEqual(ret, bytes([0x82, 0x07, 0x00, 0x00, 0x03, 0x05, 0x14]))

    def test_status_handler(self):
        data = bytes.fromhex("8208D08A")
        ret = self.client.status_handler(None, None, None, data)
        self.assertEqual(ret, {"present_level": -30000})
        data = bytes.fromhex("820830754A0000")
        ret = self.client.status_handler(None, None, None, data)
        self.assertEqual(
            ret, {"present_level": 30000, "target_level": 74, "remaining_time": 0}
        )

    def test_delta_set(self):
        ret = self.client.delta_set(None, None, -90000)
        self.assertEqual(ret, bytes([0x82, 0x09, 0x70, 0xA0, 0xFE, 0xFF, 0x00]))
        ret = self.client.delta_set(None, None, 90000, 10)
        self.assertEqual(
            ret, bytes([0x82, 0x09, 0x90, 0x5F, 0x01, 0x00, 0x01, 0x4A, 0x00])
        )
        ret = self.client.delta_set_unack(None, None, -90000)
        self.assertEqual(ret, bytes([0x82, 0x0A, 0x70, 0xA0, 0xFE, 0xFF, 0x02]))
        ret = self.client.delta_set_unack(None, None, 0, 0.5, 100)
        self.assertEqual(
            ret, bytes([0x82, 0x0A, 0x00, 0x00, 0x00, 0x00, 0x03, 0x05, 0x14])
        )

    def test_move_set(self):
        ret = self.client.move_set(None, None, -30000)
        self.assertEqual(ret, bytes([0x82, 0x0B, 0xD0, 0x8A, 0x00]))
        ret = self.client.move_set(None, None, 30000, 10)
        self.assertEqual(ret, bytes([0x82, 0x0B, 0x30, 0x75, 0x01, 0x4A, 0x00]))
        ret = self.client.move_set_unack(None, None, -30000)
        self.assertEqual(ret, bytes([0x82, 0x0C, 0xD0, 0x8A, 0x02]))
        ret = self.client.move_set_unack(None, None, 0, 0.5, 100)
        self.assertEqual(ret, bytes([0x82, 0x0C, 0x00, 0x00, 0x03, 0x05, 0x14]))
