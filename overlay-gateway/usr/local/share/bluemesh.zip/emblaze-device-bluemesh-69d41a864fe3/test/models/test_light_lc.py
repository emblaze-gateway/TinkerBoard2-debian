# -*- coding: utf-8 -*-
import unittest

import bluemesh.models.light_lc as light
from bluemesh import device_property


class DummyElement:
    def send(self, *args, **kwargs):
        pass

    def dev_key_send(self, *args, **kwargs):
        pass


class TestLightLCClient(unittest.TestCase):
    def setUp(self):
        self.client = light.LightLCClient(DummyElement())

    def test_tid(self):
        for i in range(1000):
            with self.subTest(i=i):
                self.assertEqual(self.client.tid, i % 256)

    def test_mode_get(self):
        ret = self.client.mode_get(None, None)
        self.assertEqual(ret, bytes([0x82, 0x91]))

    def test_mode_set(self):
        ret = self.client.mode_set(None, None, True)
        self.assertEqual(ret, bytes([0x82, 0x92, 0x01]))
        ret = self.client.mode_set_unack(None, None, False)
        self.assertEqual(ret, bytes([0x82, 0x93, 0x00]))

    def test_mode_status_handler(self):
        data = bytes.fromhex("829401")
        ret = self.client.mode_status_handler(None, None, None, data)
        self.assertEqual(ret, {"mode": True})

    def test_om_get(self):
        ret = self.client.om_get(None, None)
        self.assertEqual(ret, bytes([0x82, 0x95]))

    def test_om_set(self):
        ret = self.client.om_set(None, None, True)
        self.assertEqual(ret, bytes([0x82, 0x96, 0x01]))
        ret = self.client.om_set_unack(None, None, False)
        self.assertEqual(ret, bytes([0x82, 0x97, 0x00]))

    def test_om_status_handler(self):
        data = bytes.fromhex("829800")
        ret = self.client.om_status_handler(None, None, None, data)
        self.assertEqual(ret, {"mode": False})

    def test_light_onoff_get(self):
        ret = self.client.light_onoff_get(None, None)
        self.assertEqual(ret, bytes([0x82, 0x99]))

    def test_light_onoff_set(self):
        ret = self.client.light_onoff_set(None, None, True)
        self.assertEqual(ret, bytes([0x82, 0x9A, 0x01, 0x00]))
        ret = self.client.light_onoff_set(None, None, False, 10)
        self.assertEqual(ret, bytes([0x82, 0x9A, 0x00, 0x01, 0x4A, 0x00]))
        ret = self.client.light_onoff_set_unack(None, None, True)
        self.assertEqual(ret, bytes([0x82, 0x9B, 0x01, 0x02]))
        ret = self.client.light_onoff_set_unack(None, None, False, 0.5, 100)
        self.assertEqual(ret, bytes([0x82, 0x9B, 0x00, 0x03, 0x05, 0x14]))

    def test_light_onoff_status_handler(self):
        data = bytes.fromhex("829C00")
        ret = self.client.light_onoff_status_handler(None, None, None, data)
        self.assertEqual(ret, {"present_light_onoff": False})
        data = bytes.fromhex("829C01010000")
        ret = self.client.light_onoff_status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {
                "present_light_onoff": True,
                "target_light_onoff": True,
                "remaining_time": 0,
            },
        )

    def test_property_get(self):
        ret = self.client.property_get(
            None,
            None,
            device_property.DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_ON,
        )
        self.assertEqual(ret, bytes([0x82, 0x9D, 0x2B, 0x00]))

    def test_property_set(self):
        ret = self.client.property_set(
            None,
            None,
            device_property.DevicePropertyID.LIGHT_CONTROL_REGULATOR_KID,
            999.9,
        )
        self.assertEqual(ret, bytes([0x62, 0x32, 0x00, 0x9A, 0xF9, 0x79, 0x44]))
        ret = self.client.property_set_unack(
            None,
            None,
            device_property.DevicePropertyID.LIGHT_CONTROL_REGULATOR_KIU,
            1000.0,
        )
        self.assertEqual(ret, bytes([0x63, 0x33, 0x00, 0x00, 0x00, 0x7A, 0x44]))

    def test_property_status_handler(self):
        data = bytes.fromhex("6436002F5B00")
        ret = self.client.property_status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {
                "property_id": device_property.DevicePropertyID.LIGHT_CONTROL_TIME_FADE,
                "property_value": 23.343,
            },
        )
