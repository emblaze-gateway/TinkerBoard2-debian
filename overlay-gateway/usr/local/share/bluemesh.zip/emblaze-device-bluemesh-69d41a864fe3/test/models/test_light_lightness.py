# -*- coding: utf-8 -*-
import unittest

import bluemesh.models.light_lightness as light


class DummyElement:
    def send(self, *args, **kwargs):
        pass

    def dev_key_send(self, *args, **kwargs):
        pass


class TestLightLightnessClient(unittest.TestCase):
    def setUp(self):
        self.client = light.LightLightnessClient(DummyElement())

    def test_tid(self):
        for i in range(1000):
            with self.subTest(i=i):
                self.assertEqual(self.client.tid, i % 256)

    def test_get(self):
        ret = self.client.get(None, None)
        self.assertEqual(ret, bytes([0x82, 0x4B]))

    def test_set(self):
        ret = self.client.set(None, None, 30000)
        self.assertEqual(ret, bytes([0x82, 0x4C, 0x30, 0x75, 0x00]))
        ret = self.client.set(None, None, 60000, 10)
        self.assertEqual(ret, bytes([0x82, 0x4C, 0x60, 0xEA, 0x01, 0x4A, 0x00]))
        ret = self.client.set_unack(None, None, 0)
        self.assertEqual(ret, bytes([0x82, 0x4D, 0x00, 0x00, 0x02]))
        ret = self.client.set_unack(None, None, 0, 0.5, 100)
        self.assertEqual(ret, bytes([0x82, 0x4D, 0x00, 0x00, 0x03, 0x05, 0x14]))

    def test_status_handler(self):
        data = bytes.fromhex("824E3075")
        ret = self.client.status_handler(None, None, None, data)
        self.assertEqual(ret, {"present_lightness": 30000})
        data = bytes.fromhex("820860EA4A0000")
        ret = self.client.status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {"present_lightness": 60000, "target_lightness": 74, "remaining_time": 0},
        )

    def test_linear_get(self):
        ret = self.client.linear_get(None, None)
        self.assertEqual(ret, bytes([0x82, 0x4F]))

    def test_linear_set(self):
        ret = self.client.linear_set(None, None, 30000)
        self.assertEqual(ret, bytes([0x82, 0x50, 0x30, 0x75, 0x00]))
        ret = self.client.linear_set(None, None, 60000, 10)
        self.assertEqual(ret, bytes([0x82, 0x50, 0x60, 0xEA, 0x01, 0x4A, 0x00]))
        ret = self.client.linear_set_unack(None, None, 0)
        self.assertEqual(ret, bytes([0x82, 0x51, 0x00, 0x00, 0x02]))
        ret = self.client.linear_set_unack(None, None, 0, 0.5, 100)
        self.assertEqual(ret, bytes([0x82, 0x51, 0x00, 0x00, 0x03, 0x05, 0x14]))

    def test_linear_status_handler(self):
        data = bytes.fromhex("82523075")
        ret = self.client.linear_status_handler(None, None, None, data)
        self.assertEqual(ret, {"present_lightness": 30000})
        data = bytes.fromhex("825260EA4A0000")
        ret = self.client.linear_status_handler(None, None, None, data)
        self.assertEqual(
            ret,
            {"present_lightness": 60000, "target_lightness": 74, "remaining_time": 0},
        )

    def test_last_get(self):
        ret = self.client.last_get(None, None)
        self.assertEqual(ret, bytes([0x82, 0x53]))

    def test_last_status_handler(self):
        data = bytes.fromhex("82543075")
        ret = self.client.last_status_handler(None, None, None, data)
        self.assertEqual(ret, {"lightness": 30000})

    def test_default_get(self):
        ret = self.client.default_get(None, None)
        self.assertEqual(ret, bytes([0x82, 0x55]))

    def test_default_set(self):
        ret = self.client.default_set(None, None, 30000)
        self.assertEqual(ret, bytes([0x82, 0x59, 0x30, 0x75]))
        ret = self.client.default_set_unack(None, None, 60000)
        self.assertEqual(ret, bytes([0x82, 0x5A, 0x60, 0xEA]))

    def test_default_status_handler(self):
        data = bytes.fromhex("825660EA")
        ret = self.client.default_status_handler(None, None, None, data)
        self.assertEqual(ret, {"lightness": 60000})

    def test_range_get(self):
        ret = self.client.range_get(None, None)
        self.assertEqual(ret, bytes([0x82, 0x57]))

    def test_range_set(self):
        ret = self.client.range_set(None, None, 30000, 60000)
        self.assertEqual(ret, bytes([0x82, 0x5B, 0x30, 0x75, 0x60, 0xEA]))
        ret = self.client.range_set_unack(None, None, 0, 65535)
        self.assertEqual(ret, bytes([0x82, 0x5C, 0x00, 0x00, 0xFF, 0xFF]))

    def test_range_status_handler(self):
        data = bytes.fromhex("825800307560EA")
        ret = self.client.range_status_handler(None, None, None, data)
        self.assertEqual(
            ret, {"status_code": 0, "range_min": 30000, "range_max": 60000}
        )
