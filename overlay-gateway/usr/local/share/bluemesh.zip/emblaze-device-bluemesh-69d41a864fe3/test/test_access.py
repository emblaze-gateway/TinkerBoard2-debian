# -*- coding: utf-8 -*-
import struct
import unittest
import uuid as _uuid

from bluemesh import access


class TestAccess(unittest.TestCase):
    def test_regular_expression(self):
        """
        Todo::

            string_variable_7 = "alice{{bob{michael}}carol}abc{def{{asd}zxc{qwe}}ghi}jk"

        """

        string_variable_3 = "alice{{bob{michael}}carol}rosa"
        string_extension_3 = "normal(extension)(extension)normal(extension)"
        string_raw_1 = "abcdefghijklmnopqr10stuvwxyz"
        wrong_string_variable = "zxc}asdas{qwezxc"
        wrong_string_extension = "this(is(wrong)string)"
        wrong_string_number = "qwert10yuiop"

        self.assertListEqual(
            access.re_variable.findall(string_variable_3), ["{{bob{michael}}carol}"]
        )
        self.assertIsNone(access.re_variable.search(wrong_string_variable))
        self.assertListEqual(
            access.re_extension.findall(string_extension_3),
            ["(extension)", "(extension)", "(extension)"],
        )
        self.assertListEqual(
            access.re_extension.findall(wrong_string_extension), ["(wrong)"]
        )
        self.assertListEqual(access.re_raw_data.findall(string_raw_1), ["r10"])
        self.assertIsNone(access.re_raw_data.search(wrong_string_number))

    def test_AccessMessage__unpack_variable_and_set_signature(self):
        with self.assertNoLogs("bluemesh.access", level="WARNING"):
            access.AccessMessage.set_signature(
                "a", unpack_func=lambda val, sign: (val[:1], 1)
            )
            for sign in "cde":
                access.AccessMessage.set_signature(
                    sign, unpack_func=lambda val, sign: (sign, 1)
                )
            access.AccessMessage.set_signature(
                "f", unpack_func=lambda val, sign: (val[:2], 2)
            )
            access.AccessMessage.set_signature(
                "testa", unpack_func=lambda val, sign: (sign, 1)
            )
            access.AccessMessage.set_signature(
                "testb", unpack_func=lambda val, sign: (val[0], 1)
            )
        with self.assertLogs("bluemesh.access", level="WARNING"):
            access.AccessMessage.set_signature(
                "a", unpack_func=lambda val, sign: (val[:1], 1)
            )

        fields, count = access.AccessMessage._unpack_variable(
            bytes.fromhex("0102030405060708090A0B0C0D"), "abcdef(testa)r2{(testb)}"
        )
        self.assertEqual(count, 13)
        self.assertEqual(fields.pop(0), bytes([1]))
        self.assertEqual(fields.pop(0), 2)
        self.assertEqual(fields.pop(0), "c")
        self.assertEqual(fields.pop(0), "d")
        self.assertEqual(fields.pop(0), "e")
        self.assertEqual(fields.pop(0), bytes([6, 7]))
        self.assertEqual(fields.pop(0), "testa")
        self.assertEqual(fields.pop(0), bytes([9, 10]))
        self.assertEqual(fields.pop(0), 0xB)
        self.assertEqual(fields.pop(0), 0xC)
        self.assertEqual(fields.pop(0), 0xD)
        self.assertFalse(fields)

    def test_AccessMessage_parse_opcode(self):
        op1 = bytes.fromhex("0F1234567890")
        op2 = bytes.fromhex("7F1234567890")
        op3 = bytes.fromhex("BF1234567890")
        op4 = bytes.fromhex("CF1234567890")

        opcodes = []
        opcodes.append(access.AccessMessage.parse_opcode(op1))
        with self.assertRaises(ValueError, msg="Opcode is RFU"):
            access.AccessMessage.parse_opcode(op2)
        opcodes.append(access.AccessMessage.parse_opcode(op3))
        opcodes.append(access.AccessMessage.parse_opcode(op4))

        self.assertEqual(opcodes.pop(0), 0x0F)
        self.assertEqual(opcodes.pop(0), 0xBF12)
        self.assertEqual(opcodes.pop(0), 0xCF1234)
        self.assertFalse(opcodes)

    def test_AccessMessage_unpack(self):
        op1 = (bytes.fromhex("0F1234567809"), "{b}")
        op3 = (bytes.fromhex("BF1234567809"), "{b}")
        op4 = (bytes.fromhex("CF1234567809"), "{b}")

        fields = []
        fields.append(access.AccessMessage.unpack(*op1))
        fields.append(access.AccessMessage.unpack(*op3))
        fields.append(access.AccessMessage.unpack(*op4))

        self.assertEqual(fields.pop(0), [0x12, 0x34, 0x56, 0x78, 0x9])
        self.assertEqual(fields.pop(0), [0x34, 0x56, 0x78, 0x9])
        self.assertEqual(fields.pop(0), [0x56, 0x78, 0x9])
        self.assertFalse(fields)

    def test_AccessMessage__pack_variable(self):
        with self.assertNoLogs("bluemesh.access", level="WARNING"):
            access.AccessMessage.set_signature(
                "pa", pack_func=lambda val, sign: struct.pack("<b", val)
            )

        data = access.AccessMessage._pack_variable(
            [-1, 2, 3, bytes([4, 5]), [6, 7]], "(pa)bhr2{b}"
        )

        self.assertEqual(len(data), 8)
        self.assertEqual(data, bytes([0xFF, 2, 3, 0, 4, 5, 6, 7]))

    def test_AccessMessage_pack(self):
        op1 = (0x0F, [-1, 2, -3, 4, -5, 6], "bBhHiI")
        op2 = (0xBF12, [-1, 2, -3, 4, -5, 6], "bBhHiI")
        op3 = (0xCF1234, [-1, 2, -3, 4, -5, 6], "bBhHiI")

        op_fails = [
            (0x7F, [-1, 2, -3, 4, -5, 6], "bBhHiI"),
            (0x90, [-1, 2, -3, 4, -5, 6], "bBhHiI"),
            (0xD000, [-1, 2, -3, 4, -5, 6], "bBhHiI"),
            (0x1000000, [-1, 2, -3, 4, -5, 6], "bBhHiI"),
        ]

        data1 = access.AccessMessage.pack(*op1)
        data2 = access.AccessMessage.pack(*op2)
        data3 = access.AccessMessage.pack(*op3)

        self.assertEqual(
            data1,
            bytes(
                [0x0F, 0xFF, 2, 0xFD, 0xFF, 4, 0, 0xFB, 0xFF, 0xFF, 0xFF, 6, 0, 0, 0]
            ),
        )
        self.assertEqual(
            data2,
            bytes(
                [
                    0xBF,
                    0x12,
                    0xFF,
                    2,
                    0xFD,
                    0xFF,
                    4,
                    0,
                    0xFB,
                    0xFF,
                    0xFF,
                    0xFF,
                    6,
                    0,
                    0,
                    0,
                ]
            ),
        )
        self.assertEqual(
            data3,
            bytes(
                [
                    0xCF,
                    0x12,
                    0x34,
                    0xFF,
                    2,
                    0xFD,
                    0xFF,
                    4,
                    0,
                    0xFB,
                    0xFF,
                    0xFF,
                    0xFF,
                    6,
                    0,
                    0,
                    0,
                ]
            ),
        )

        for op in op_fails:
            with self.subTest(op=op[0]), self.assertRaises(ValueError):
                access.AccessMessage.pack(*op)

    def test_pack_integer(self):
        self.assertEqual(access.pack_integer(-1, "b"), bytes([0xFF]))
        self.assertEqual(access.pack_integer(2, "B"), bytes([0x2]))
        self.assertEqual(access.pack_integer(-3, "h"), bytes([0xFD, 0xFF]))
        self.assertEqual(access.pack_integer(4, "H"), bytes([0x4, 0x0]))
        self.assertEqual(access.pack_integer(-5, "i"), bytes([0xFB, 0xFF, 0xFF, 0xFF]))
        self.assertEqual(access.pack_integer(6, "I"), bytes([0x6, 0x0, 0x0, 0x0]))

    def test_unpack_integer(self):
        self.assertEqual(access.unpack_integer(bytes([0xFF]), "b"), (-1, 1))
        self.assertEqual(access.unpack_integer(bytes([0x2]), "B"), (2, 1))
        self.assertEqual(access.unpack_integer(bytes([0xFD, 0xFF]), "h"), (-3, 2))
        self.assertEqual(access.unpack_integer(bytes([0x4, 0x0]), "H"), (4, 2))
        self.assertEqual(
            access.unpack_integer(bytes([0xFB, 0xFF, 0xFF, 0xFF]), "i"), (-5, 4)
        )
        self.assertEqual(
            access.unpack_integer(bytes([0x6, 0x0, 0x0, 0x0]), "I"), (6, 4)
        )

    def test_pack_uuid(self):
        self.assertEqual(
            access.pack_uuid("96b91bd6-a10a-11ed-a2ea-00155d7308a4", ""),
            b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4",
        )
        self.assertEqual(
            access.pack_uuid("96b91bd6a10a11eda2ea00155d7308a4", ""),
            b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4",
        )
        self.assertEqual(
            access.pack_uuid(
                b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4", ""
            ),
            b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4",
        )
        self.assertEqual(
            access.pack_uuid(_uuid.UUID("96b91bd6-a10a-11ed-a2ea-00155d7308a4"), ""),
            b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4",
        )

    def test_unpack_uuid(self):
        self.assertEqual(
            access.unpack_uuid(
                b"\x96\xb9\x1b\xd6\xa1\n\x11\xed\xa2\xea\x00\x15]s\x08\xa4", ""
            ),
            (_uuid.UUID("96b91bd6-a10a-11ed-a2ea-00155d7308a4"), 16),
        )
