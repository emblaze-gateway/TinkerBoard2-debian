# -*- coding: utf-8 -*-
import unittest
import uuid as _uuid
from unittest.mock import MagicMock, Mock, call

import bluemesh.application
from bluemesh.application import Application, ApplicationBuilder, ApplicationError
from bluemesh.element import Element


class DummyElement(Element):
    def __init__(self, application, index, interface_factory):
        self.path = f"{application.path}/element{index:02X}"
        self.interface = interface_factory.create_element_interface()
        self.index = index

    def update_model_config(self, vendor_assigned_model_id, config):
        pass


class DummyApplication(Application):
    ELEMENT_CLASSES = [DummyElement, DummyElement]
    COMPANY_ID: int = 1
    PRODUCT_ID: int = 2
    VERSION_ID: int = 3


class TestApplication(unittest.TestCase):
    def setUp(self):
        mock = MagicMock()
        bluemesh.application.BlueZInterfaceFactory = mock
        mock.create_application_interface.return_value = MagicMock()
        mock.create_network_interface.return_value = MagicMock()
        mock.create_node_interface.return_value = MagicMock()
        mock.create_management_interface.return_value = MagicMock()
        mock.create_element_interface.return_value = MagicMock()
        mock.create_property_interface.return_value = MagicMock()
        self.app = DummyApplication("/test", "dummy-dbus")

    def test_UUIDProperty(self):
        with self.assertRaises(AttributeError):  # cannot be set
            self.app.uuid = _uuid.UUID("deadbeef-dead-beef-0000-c0ffeec0ffee")
        with self.assertRaises(AttributeError):  # have not be set
            self.app.uuid
        uuid = _uuid.UUID("deadbeef-dead-beef-0000-c0ffeec0ffee")
        setattr(self.app, "__uuid", uuid)
        self.assertEqual(self.app.uuid, uuid)

    def test_KeysProperty(self):
        # dev key
        with self.assertRaises(AttributeError):  # have not be set
            self.app.dev_key
        dev_key = bytes([i for i in range(16)])
        self.app.dev_key = dev_key
        self.assertEqual(self.app.dev_key.hex(), "000102030405060708090a0b0c0d0e0f")
        with self.assertRaises(TypeError):
            self.app.dev_key = 10
        with self.assertRaises(ValueError):
            self.app.dev_key = bytes([i for i in range(15)])

        # primary net key
        with self.assertRaises(AttributeError):  # have not be set
            self.app.primary_net_key
        primary_net_key = (0, bytes([i for i in range(16)]))
        self.app.primary_net_key = primary_net_key
        self.assertEqual(self.app.primary_net_key[0], 0)
        self.assertEqual(
            self.app.primary_net_key[1].hex(), "000102030405060708090a0b0c0d0e0f"
        )
        with self.assertRaises(TypeError):
            self.app.primary_net_key = 10
        with self.assertRaises(TypeError):
            self.app.primary_net_key = [0, bytes([i for i in range(16)])]
        with self.assertRaises(TypeError):
            self.app.primary_net_key = ("0", bytes([i for i in range(16)]))
        with self.assertRaises(TypeError):
            self.app.primary_net_key = (1, 2)
        with self.assertRaises(ValueError):
            self.app.primary_net_key = (4096, bytes([i for i in range(16)]))
        with self.assertRaises(ValueError):
            self.app.primary_net_key = (1, bytes([i for i in range(15)]))

    def test_TokenProperty(self):
        with self.assertRaises(AttributeError):  # cannot be set
            self.app.token = 10
        with self.assertRaises(AttributeError):  # have not be set
            self.app.token
        setattr(self.app, "__token", 123)
        self.assertEqual(self.app.token, 123)

    def test_Application___init__(self):
        self.assertEqual(self.app.path, "/test")
        self.app.interface_factory.create_application_interface.assert_called_with(
            self.app, self.app.path
        )
        self.assertTrue(isinstance(self.app.interface, Mock))
        self.app.interface_factory.create_network_interface.assert_called_with(self.app)
        self.assertTrue(isinstance(self.app._network_interface, Mock))
        self.assertTrue(0 in self.app._elements)
        self.assertEqual(2, len(self.app._elements))
        self.assertTrue(isinstance(self.app._elements[0], DummyElement))

        class WrongApplication1(Application):
            ELEMENT_CLASSES = [DummyElement]
            COMPANY_ID: int
            PRODUCT_ID: int = 0
            VERSION_ID: int = 0

        class WrongApplication2(Application):
            ELEMENT_CLASSES = [DummyElement]
            COMPANY_ID: int = 0
            PRODUCT_ID: int
            VERSION_ID: int = 0

        class WrongApplication3(Application):
            ELEMENT_CLASSES = [DummyElement]
            COMPANY_ID: int = 0
            PRODUCT_ID: int = 0
            VERSION_ID: int

        class WrongApplication4(Application):
            ELEMENT_CLASSES: list[type["Element"]] = []
            COMPANY_ID: int = 0
            PRODUCT_ID: int = 0
            VERSION_ID: int = 0

        class WrongApplication5(Application):
            ELEMENT_CLASSES: list[type["Element"]]
            COMPANY_ID: int = 0
            PRODUCT_ID: int = 0
            VERSION_ID: int = 0

        class WrongApplication6(Application):
            ELEMENT_CLASSES: [DummyElement]
            COMPANY_ID: int = 0
            PRODUCT_ID: int = -1
            VERSION_ID: int = 0

        class WrongApplication7(Application):
            ELEMENT_CLASSES: [DummyElement]
            COMPANY_ID: int = 0
            PRODUCT_ID: int = 1
            VERSION_ID: int = "123"

        class CorrectApplication(Application):
            ELEMENT_CLASSES: [DummyElement]
            COMPANY_ID: int = 0
            PRODUCT_ID: int = 1
            VERSION_ID: int = 2

        application_classes = [
            WrongApplication1,
            WrongApplication2,
            WrongApplication3,
            WrongApplication4,
            WrongApplication5,
        ]
        for app in application_classes:
            with self.subTest(app=app):
                with self.assertRaises(ApplicationError):  # missing constant attributes
                    app("/test", "dummy-dbus")

        with self.assertRaises(ValueError):  # attribute has value out of range
            WrongApplication6("/test", "dummy-dbus")

        with self.assertRaises(TypeError):  # attribute has wrong type
            WrongApplication7("/test", "dummy-dbus")

        mock = MagicMock(side_effect=ImportError)
        bluemesh.application.BlueZInterfaceFactory = mock
        with self.assertRaises(ApplicationError):
            CorrectApplication("/test", "dummy-dbus")

    def test_Application_node_interface(self):
        with self.assertRaises(ApplicationError):
            self.app.node_interface
        with self.assertRaises(AttributeError):
            self.app.node_interface = 1
        self.app._node_interface = 1
        self.assertEqual(self.app.node_interface, 1)

    def test_Application_management_interface(self):
        with self.assertRaises(ApplicationError):
            self.app.management_interface
        with self.assertRaises(AttributeError):
            self.app.management_interface = 1
        self.app._management_interface = 1
        self.assertEqual(self.app.management_interface, 1)

    def test_Application_message_handler(self):
        import queue

        class WrongQueue:
            def get():
                return MagicMock()

        class WrongQueue2:
            def put(data):
                pass

        class UserdefinedQueue:
            def __init__(self, maxsize=0):
                self.data = []
                self.maxsize = maxsize

            def get(self, block=False, timeout=None):
                if not self.data:
                    raise queue.Empty
                data = self.data.pop(0)
                return data

            def put(self, item, block=False, timeout=None):
                if self.maxsize > 0 and self.maxsize <= len(self.data):
                    raise queue.Full
                self.data.append(item)

            def full(self):
                return False

            def empty(self):
                return len(self.data) == 0

        # add
        with self.assertRaises(TypeError):
            self.app.register_queue(WrongQueue())
        with self.assertRaises(TypeError):
            self.app.register_queue(WrongQueue2())
        with self.assertRaises(TypeError):
            self.app.register_queue(
                UserdefinedQueue(), ""
            )  # second arg must be 'None' or callable
        uq = UserdefinedQueue(3)
        self.app.register_queue(uq, lambda x: x["opcode"] == 1)
        q = queue.Queue()
        self.app.register_queue(q)
        self.app.message_handler({"opcode": 1})
        self.app.message_handler({"opcode": 2})
        self.assertEqual(q.get(), {"opcode": 1})
        self.assertEqual(q.get(), {"opcode": 2})
        with self.assertRaises(queue.Empty):
            q.get(False)
        self.assertEqual(uq.get(), {"opcode": 1})
        #  self.assertEqual(uq.get(), {"opcode": 2})
        with self.assertRaises(queue.Empty):
            uq.get()
        self.app.message_handler({"opcode": 1})
        self.app.message_handler({"opcode": 1})
        self.app.message_handler({"opcode": 1})
        with self.assertLogs("bluemesh", level="ERROR"):
            self.app.message_handler({"opcode": 1})
        with self.assertLogs("bluemesh.application", level="WARNING"):
            self.app.register_queue(q)  # nothing
        q.get(False)
        q.get(False)
        q.get(False)
        q.get(False)

        # delete
        self.app.unregister_queue(q)
        self.app.message_handler({"opcode": 3})
        with self.assertRaises(queue.Empty):
            q.get(False)
        with self.assertLogs("bluemesh.application", level="WARNING"):
            self.app.unregister_queue(q)  # nothing

    def test_Application_import_node(self):
        setattr(self.app, "__uuid", _uuid.UUID("deadbeef-dead-beef-0000-c0ffeec0ffee"))
        setattr(self.app, "__dev_key", bytes([i for i in range(16)]))
        setattr(self.app, "__primary_net_key", (0, bytes([i for i in range(16)])))
        setattr(self.app, "__iv_update", True)
        setattr(self.app, "__key_refresh", True)
        setattr(self.app, "__iv_index", 999)
        setattr(self.app, "__address", 1)
        self.app.import_node()
        self.app._network_interface.import_node.assert_called_once()

        import threading

        event_lock = threading.Event()
        event_lock.wait = Mock(return_value=False)  # simulate timeout
        with self.assertRaises(ApplicationError):
            self.app.import_node(True, event_lock)

        event_lock = threading.Event()
        event_lock.set()  # simulate reponse success
        self.app.import_node(True, event_lock)

    def test_Application_join_complete_handler(self):
        setattr(self.app, "__uuid", _uuid.UUID("deadbeef-dead-beef-0000-c0ffeec0ffee"))
        setattr(self.app, "__address", 1)

        self.app.join_complete_handler(99)
        self.assertEqual(self.app.token, 99)

        mock = Mock()
        setattr(self.app, "__import_container", mock)  # simulate import_node waiting
        self.app.join_complete_handler(99)
        self.assertEqual(self.app.token, 99)
        mock.set.assert_called_once()

    def test_Application_join_failed_handler(self):
        setattr(self.app, "__uuid", _uuid.UUID("deadbeef-dead-beef-0000-c0ffeec0ffee"))
        setattr(self.app, "__address", 1)

        self.app.join_failed_handler()
        with self.assertRaises(AttributeError):
            self.app.token

        mock = Mock()
        setattr(self.app, "__import_container", mock)  # simulate import_node waiting
        self.app.join_failed_handler()
        mock.set.assert_called_once()

    def test_Application_import_node_with_join_complete(self):
        setattr(self.app, "__uuid", _uuid.UUID("deadbeef-dead-beef-0000-c0ffeec0ffee"))
        setattr(self.app, "__dev_key", bytes([i for i in range(16)]))
        setattr(self.app, "__primary_net_key", (0, bytes([i for i in range(16)])))
        setattr(self.app, "__iv_update", True)
        setattr(self.app, "__key_refresh", True)
        setattr(self.app, "__iv_index", 999)
        setattr(self.app, "__address", 1)
        self.app.import_node()

        import threading

        event_lock = threading.Event()

        def check_success(cb, *args):
            self.assertEqual(cb(*args), 99)

        th = threading.Thread(
            target=check_success, args=(self.app.import_node, True, event_lock)
        )
        th.start()
        self.app.join_complete_handler(99)
        th.join(timeout=1)

    def test_Application_attach_node(self):
        setattr(self.app, "__token", 99)
        self.app.attach_node()
        self.app._network_interface.attach_node.assert_called_once()

        import threading

        event_lock = threading.Event()
        event_lock.wait = Mock(return_value=False)  # simulate timeout
        with self.assertRaises(ApplicationError):
            self.app.attach_node(True, event_lock)

        event_lock = threading.Event()
        event_lock.set()  # simulate reponse success
        self.app.attach_node(True, event_lock)

    def test_Application_attach_node_handler(self):
        config = [
            (0, [(0x0001, {"model_config": True})]),
            (1, [(0x0002, {"model_config2": False})]),
        ]
        self.app.attach_node_handler("/test", config)
        self.app.interface_factory.create_node_interface.assert_called_with(
            self.app, "/test"
        )
        self.app.interface_factory.create_management_interface.assert_called_with(
            self.app, "/test"
        )

        mock = Mock()
        setattr(self.app, "__attach_container", mock)  # simulate attach_node waiting
        self.app.attach_node_handler("/test", config)
        mock.set.assert_called_once()

    def test_Application_leave_node(self):
        setattr(self.app, "__token", 99)
        self.app.leave_node()
        self.app._network_interface.leave_node.assert_called_with(token=99)

    def test_Application_export_keys(self):
        self.app.attach_node_handler("/test", [])
        self.app.export_keys()
        self.app.management_interface.export_keys.assert_called_once()

        import threading

        event_lock = threading.Event()
        event_lock.wait = Mock(return_value=False)  # simulate timeout
        with self.assertRaises(ApplicationError):
            self.app.export_keys(True, event_lock)

        event_lock = threading.Event()
        event_lock.set()  # simulate reponse success
        self.app.export_keys(True, event_lock)

    def test_Application_export_keys_handler(self):
        self.app.export_keys_handler({})

        mock = Mock()
        setattr(
            self.app, "__export_keys_container", mock
        )  # simulate export_keys waiting
        self.app.export_keys_handler({})
        mock.set.assert_called_once()

    def test_Application_export_keys_with_handler(self):
        self.app.attach_node_handler("/test/ele0", [])
        keys = {
            "NetKeys": [
                (
                    1,
                    [1, 1, 1, 1],
                    {
                        "Phase": 1,
                        "OldKey": 1,
                        "AppKeys": [
                            (11, [11, 11, 11, 11], {"OldKey": 11}),
                            (22, [22, 22, 22, 22], {"OldKey": 22}),
                        ],
                    },
                ),
                (
                    2,
                    [2, 2, 2, 2],
                    {
                        "Phase": 2,
                        "OldKey": 2,
                        "AppKeys": [
                            (33, [33, 33, 33, 33], {"OldKey": 33}),
                            (44, [44, 44, 44, 44], {"OldKey": 44}),
                        ],
                    },
                ),
            ],
            "DevKeys": [
                (111, [111, 111, 111, 111]),
                (222, [222, 222, 222, 222]),
            ],
        }

        import threading

        event_lock = threading.Event()

        expect_ret = {
            "net_keys": {1: bytes([1, 1, 1, 1]), 2: bytes([2, 2, 2, 2])},
            "app_keys": {
                11: (1, bytes([11, 11, 11, 11])),
                22: (1, bytes([22, 22, 22, 22])),
                33: (2, bytes([33, 33, 33, 33])),
                44: (2, bytes([44, 44, 44, 44])),
            },
            "dev_keys": {
                111: bytes([111, 111, 111, 111]),
                222: bytes([222, 222, 222, 222]),
            },
        }

        def check_success(cb, *args):
            self.assertEqual(cb(*args), expect_ret)

        th = threading.Thread(
            target=check_success, args=(self.app.export_keys, True, event_lock)
        )
        th.start()
        self.app.export_keys_handler(keys)
        th.join(timeout=1)

    def test_Application_get_managed_objects_handler(self):
        self.app.interface.get_properties.return_value = "app_property"
        self.app._elements[0].interface.get_properties.return_value = "ele_property"
        ret = self.app.get_managed_objects_handler()
        self.app.interface.get_properties.assert_called_once()
        self.app._elements[0].interface.get_properties.assert_called()
        expect_ret = {
            "/test": "app_property",
            "/test/element00": "ele_property",
            "/test/element01": "ele_property",
        }
        self.assertEqual(ret, expect_ret)

    def test_Application_setup(self):
        self.app.attach_node_handler("/test", [])
        setattr(self.app, "__primary_net_key", (0, bytes([1])))
        setattr(self.app, "__dev_key", bytes([3]))
        setattr(self.app, "__address", 1)
        self.app.setup()
        self.app.management_interface.import_subnet.assert_called_with(
            net_index=0, net_key=bytes([1])
        )
        self.app.management_interface.import_remote_node.assert_called()

    def test_Application_import_app_key(self):
        self.app.attach_node_handler("/test", [])
        self.app.import_app_key(1, 2, bytes([3]))
        self.app.management_interface.import_app_key.assert_called_with(
            net_index=1, app_index=2, app_key=bytes([3])
        )

    def test_Application_send(self):
        self.app.attach_node_handler("/test", [])
        self.app.send("/test/ele0", 1, 2, bytes([3]), True)
        self.app.node_interface.send.assert_called_with(
            element_path="/test/ele0",
            destination=1,
            key_index=2,
            data=bytes([3]),
            force_segmented=True,
        )

    def test_Application_dev_key_send(self):
        self.app.attach_node_handler("/test", [])
        self.app.dev_key_send("/test/ele0", 1, 2, bytes([3]), True, False)
        self.app.node_interface.dev_key_send.assert_called_with(
            element_path="/test/ele0",
            destination=1,
            net_index=2,
            data=bytes([3]),
            force_segmented=False,
            remote=True,
        )

    def test_Application_publish(self):
        self.app.attach_node_handler("/test", [])
        self.app.publish("/test/ele0", (1, 2), bytes([3]), True)
        self.app.node_interface.publish.assert_called_with(
            element_path="/test/ele0",
            model=2,
            vendor=1,
            data=bytes([3]),
            force_segmented=True,
        )


class TestApplicationBuilder(unittest.TestCase):
    def setUp(self):
        mock = MagicMock()
        bluemesh.application.BlueZInterfaceFactory = mock
        mock.create_application_interface.return_value = MagicMock()
        mock.create_network_interface.return_value = MagicMock()
        mock.create_node_interface.return_value = MagicMock()
        mock.create_management_interface.return_value = MagicMock()
        mock.create_element_interface.return_value = MagicMock()
        self.builder = ApplicationBuilder(MagicMock(), "/test", "dummy-dbus")

    def test_set_attributes(self):
        # set uuid
        uuid = _uuid.UUID("deadbeef-dead-beef-0000-c0ffeec0ffee")
        self.builder.set_uuid(uuid)
        self.assertEqual(self.builder._instance_attributes["uuid"], uuid)
        self.builder.set_uuid(str(uuid))
        self.assertEqual(self.builder._instance_attributes["uuid"], uuid)
        self.builder.set_uuid(uuid.hex)
        self.assertEqual(self.builder._instance_attributes["uuid"], uuid)
        self.builder.set_uuid(uuid.bytes)
        self.assertEqual(self.builder._instance_attributes["uuid"], uuid)
        self.builder.set_uuid(uuid.int)
        self.assertEqual(self.builder._instance_attributes["uuid"], uuid)
        with self.assertRaises(ValueError):
            self.builder.set_uuid(uuid.bytes[:-1])
        with self.assertRaises(TypeError):
            self.builder.set_uuid(float(uuid.int))

        # set address
        self.builder.set_address(10)
        self.assertEqual(self.builder._instance_attributes["address"], 10)
        with self.assertRaises(ValueError):
            self.builder.set_address(0x9999)
        with self.assertRaises(TypeError):
            self.builder.set_address(float(1))

        # set device key
        self.builder.set_dev_key(bytes([i for i in range(16)]))
        self.assertEqual(
            self.builder._instance_attributes["dev_key"],
            bytes([i for i in range(16)]),
        )
        with self.assertRaises(ValueError):
            self.builder.set_dev_key(bytes([1]))
        with self.assertRaises(TypeError):
            self.builder.set_dev_key([1])

        # set primary net key
        self.builder.set_primary_net_key((1, bytes([i for i in range(16)])))
        self.assertEqual(
            self.builder._instance_attributes["primary_net_key"],
            (1, bytes([i for i in range(16)])),
        )
        with self.assertRaises(ValueError):
            self.builder.set_primary_net_key((4096, bytes([i for i in range(16)])))
        with self.assertRaises(ValueError):
            self.builder.set_primary_net_key((1, bytes([1])))
        with self.assertRaises(TypeError):
            self.builder.set_primary_net_key((1, [1]))
        with self.assertRaises(TypeError):
            self.builder.set_primary_net_key([1, bytes([i for i in range(16)])])
        with self.assertRaises(TypeError):
            self.builder.set_primary_net_key(("1", bytes([i for i in range(16)])))

        self.builder.set_iv_update(True)
        self.assertEqual(self.builder._instance_attributes["iv_update"], True)
        self.assertNotEqual(self.builder._instance_attributes["iv_update"], False)
        with self.assertRaises(TypeError):
            self.builder.set_iv_update("a")

        self.builder.set_key_refresh(True)
        self.assertEqual(self.builder._instance_attributes["key_refresh"], True)
        self.assertNotEqual(self.builder._instance_attributes["key_refresh"], False)
        with self.assertRaises(TypeError):
            self.builder.set_key_refresh("a")

        self.builder.set_iv_index(10)
        self.assertEqual(self.builder._instance_attributes["iv_index"], 10)
        self.assertNotEqual(self.builder._instance_attributes["iv_index"], 11)
        with self.assertRaises(TypeError):
            self.builder.set_iv_index("a")

        self.builder.set_token(10)
        self.assertEqual(self.builder._instance_attributes["token"], 10)
        self.assertNotEqual(self.builder._instance_attributes["token"], 11)
        with self.assertRaises(TypeError):
            self.builder.set_token("a")

    def test_build(self):
        self.assertIsInstance(self.builder.build(), Mock)

    def test_build_attach(self):
        DummyApplication.attach_node = MagicMock()
        with self.assertRaises(AttributeError):
            self.builder.build_attach()
        self.builder.set_token(12)
        self.assertIsInstance(self.builder.build_attach(), Mock)

    def test_build_import_attach(self):
        DummyApplication.import_node = MagicMock()
        DummyApplication.attach_node = MagicMock()
        DummyApplication.setup = MagicMock()
        with self.assertRaises(AttributeError):
            self.builder.build_import_attach()
        self.builder.set_uuid("deadbeef-dead-beef-0000-c0ffeec0ffee")
        with self.assertRaises(AttributeError):
            self.builder.build_import_attach()
        self.builder.set_dev_key(bytes([i for i in range(16)]))
        with self.assertRaises(AttributeError):
            self.builder.build_import_attach()
        self.builder.set_primary_net_key((1, bytes([i for i in range(16)])))
        with self.assertRaises(AttributeError):
            self.builder.build_import_attach()
        self.builder.set_iv_update(True)
        with self.assertRaises(AttributeError):
            self.builder.build_import_attach()
        self.builder.set_key_refresh(True)
        with self.assertRaises(AttributeError):
            self.builder.build_import_attach()
        self.builder.set_iv_index(10)
        with self.assertRaises(AttributeError):
            self.builder.build_import_attach()
        self.builder.set_address(10)
        self.assertIsInstance(self.builder.build_import_attach(), Mock)

    def test_build_failure(self):
        DummyApplication.__init__ = MagicMock(side_effect=ApplicationError)

        builder = ApplicationBuilder(DummyApplication, "/test", "dummy-dbus")
        builder.set_token(12)
        builder.set_address(10)
        self.assertEqual(builder.build_attach(), None)

        builder = ApplicationBuilder(DummyApplication, "/test", "dummy-dbus")
        builder.set_uuid("deadbeef-dead-beef-0000-c0ffeec0ffee")
        builder.set_dev_key(bytes([i for i in range(16)]))
        builder.set_primary_net_key((1, bytes([i for i in range(16)])))
        builder.set_iv_update(True)
        builder.set_key_refresh(True)
        builder.set_iv_index(10)
        builder.set_address(10)
        self.assertEqual(builder.build_import_attach(), None)
