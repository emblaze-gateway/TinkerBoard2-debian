# -*- coding: utf-8 -*-
import io
import unittest

from bluemesh import bluemesh_logging as logging


class TestLogging(unittest.TestCase):
    def setUp(self):
        self.logger = logging.getLogger("bluemesh.test_logging")

    def test_stream_handler(self):
        stream = io.StringIO()
        logformat = "%(name)s - %(levelname)s - %(message)s"
        handler_index = logging.addStreamHandler(
            "bluemesh", stream, "WARNING", logformat
        )
        self.logger.debug("Hello")
        self.logger.info("Hello")
        self.logger.warning("Hello")
        self.logger.error("Hello")
        ret = (
            "bluemesh.test_logging - WARNING - Hello\n"
            + "bluemesh.test_logging - ERROR - Hello\n"
        )
        self.assertEqual(stream.getvalue(), ret)
        logging.removeHandler("bluemesh", handler_index)
        with self.assertRaises(IndexError):
            logging.removeHandler("bluemesh", handler_index)  # already remove
        stream.close()
