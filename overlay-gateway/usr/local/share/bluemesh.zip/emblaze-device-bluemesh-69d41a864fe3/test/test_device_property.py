# -*- coding: utf-8 -*-
import struct
import unittest

from bluemesh.device_property import (
    Coefficient,
    Illuminance,
    PerceivedLightness,
    Percentage8,
    TimeMillisecond24,
)


class TestIlluminance(unittest.TestCase):
    def test_pack(self):
        self.assertEqual(Illuminance.pack(0), bytes([0x00, 0x00, 0x00]))
        self.assertEqual(Illuminance.pack(167772.15), bytes([0xFF, 0xFF, 0xFF]))
        self.assertEqual(Illuminance.pack(111111.11), bytes([0xC7, 0x8A, 0xA9]))
        with self.assertRaises(ValueError):
            Illuminance.pack(167772.16)
        with self.assertRaises(ValueError):
            Illuminance.pack(-0.2)

    def test_unpack(self):
        self.assertEqual(Illuminance.unpack(bytes([0x00, 0x00, 0x00])), 0)
        self.assertEqual(Illuminance.unpack(bytes([0xFF, 0xFF, 0xFF])), 167772.15)
        self.assertEqual(Illuminance.unpack(bytes([0xC7, 0x8A, 0xA9])), 111111.11)
        with self.assertRaises(ValueError):
            Illuminance.unpack(bytes([0x00, 0x00]))
        with self.assertRaises(ValueError):
            Illuminance.unpack(bytes([0x00, 0x00, 0x00, 0x00]))


class TestPerceivedLightness(unittest.TestCase):
    def test_pack(self):
        self.assertEqual(PerceivedLightness.pack(64), bytes([0x40, 0x00]))

    def test_unpack(self):
        self.assertEqual(PerceivedLightness.unpack(bytes([0x40, 0x00])), 64)
        with self.assertRaises(ValueError):
            PerceivedLightness.unpack(bytes([0x00]))
        with self.assertRaises(ValueError):
            PerceivedLightness.unpack(bytes([0x00, 0x00, 0x00]))


class TestPercentage8(unittest.TestCase):
    pass
    #  def test_pack(self):
    #  self.assertEqual(Percentage8.pack(64.5), bytes([0x41]))

    #  def test_unpack(self):
    #  self.assertEqual(Percentage8.unpack(bytes([0x41])), 65.0)
    #  with self.assertRaises(ValueError):
    #  Percentage8.unpack(bytes([0x00, 0x00]))
    #  with self.assertRaises(ValueError):
    #  Percentage8.unpack(bytes([0x65]))
    #  with self.assertRaises(ValueError):
    #  Percentage8.unpack(bytes([0xFF]))


class TestCoefficient(unittest.TestCase):
    def test_pack(self):
        self.assertEqual(Coefficient.pack(64.5), bytes([0x00, 0x00, 0x81, 0x42]))

    def test_unpack(self):
        self.assertEqual(Coefficient.unpack(bytes([0x00, 0x00, 0x81, 0x42])), 64.5)
        self.assertEqual(Coefficient.unpack(bytes([0x9A, 0xF9, 0x79, 0x44])), 999.9)
        with self.assertRaises(ValueError):
            Coefficient.unpack(bytes([0x00, 0x00, 0x00]))
        with self.assertRaises(ValueError):
            Coefficient.unpack(bytes([0x00, 0x00, 0x00, 0x00, 0x00]))
        with self.assertRaises(ValueError):
            Coefficient.unpack(bytes([0x66, 0x06, 0x7A, 0x44]))  # 1000.1
        with self.assertRaises(ValueError):
            Coefficient.unpack(bytes([0xCD, 0xCC, 0xCC, 0xBD]))  # -0.1


class TestTimeMillisecond24(unittest.TestCase):
    def test_pack(self):
        self.assertEqual(TimeMillisecond24.pack(0), bytes([0x00, 0x00, 0x00]))
        self.assertEqual(TimeMillisecond24.pack(16777.215), bytes([0xFF, 0xFF, 0xFF]))
        self.assertEqual(TimeMillisecond24.pack(11111.111), bytes([0xC7, 0x8A, 0xA9]))
        with self.assertRaises(ValueError):
            TimeMillisecond24.pack(16777.216)
        with self.assertRaises(ValueError):
            TimeMillisecond24.pack(-0.1)

    def test_unpack(self):
        self.assertEqual(TimeMillisecond24.unpack(bytes([0x00, 0x00, 0x00])), 0)
        self.assertEqual(TimeMillisecond24.unpack(bytes([0xFF, 0xFF, 0xFF])), 16777.215)
        self.assertEqual(TimeMillisecond24.unpack(bytes([0xC7, 0x8A, 0xA9])), 11111.111)
        with self.assertRaises(ValueError):
            TimeMillisecond24.unpack(bytes([0x00, 0x00]))
        with self.assertRaises(ValueError):
            TimeMillisecond24.unpack(bytes([0x00, 0x00, 0x00, 0x00]))


class TestDeviceProperty(unittest.TestCase):
    pass
