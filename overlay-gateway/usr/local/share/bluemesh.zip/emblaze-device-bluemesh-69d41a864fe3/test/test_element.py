# -*- coding: utf-8 -*-
import unittest
from unittest.mock import MagicMock, Mock

from bluemesh.element import Element, ElementError


class DummyModel:
    def __init__(self, element):
        pass

    @property
    def model_id(self):
        return (self.VENDOR, self.MODEL_ID)


class DummyElement(Element):
    MODEL_CLASSES = [
        MagicMock(
            VENDOR=1, MODEL_ID=2, return_value=MagicMock(PUBLISH=True, SUBSCRIBE=False)
        ),
        MagicMock(
            VENDOR=None,
            MODEL_ID=3,
            return_value=MagicMock(PUBLISH=False, SUBSCRIBE=True),
        ),
    ]


class TestElement(unittest.TestCase):
    def setUp(self):
        self.app = MagicMock()
        self.app.path = "/test"
        self.ele = DummyElement(self.app, 0, MagicMock())

    def test_Element___init__(self):
        self.assertEqual(self.ele.path, "/test/element00")

        class WrongElement(Element):
            pass

        with self.assertRaises(ElementError):
            WrongElement(MagicMock(), 0, MagicMock())

    def test_Element__getitem__(self):
        self.assertEqual(self.ele._models[(1, 2)], self.ele[0x00010002])
        self.assertNotEqual(self.ele._models[(1, 2)], self.ele[0x0003])

    def test_Element_send(self):
        self.ele.send(1, 2, bytes([3, 4]), True)
        self.ele.dev_key_send(1, 2, bytes([3, 4]), True, False)
        self.ele.publish((1, 2), bytes([3, 4]), True)
        self.app.send.assert_called_with("/test/element00", 1, 2, bytes([3, 4]), True)
        self.app.dev_key_send.assert_called_with(
            "/test/element00", 1, 2, bytes([3, 4]), True, False
        )
        self.app.publish.assert_called_with(
            "/test/element00", (1, 2), bytes([3, 4]), True
        )

    def test_Element_properties(self):
        self.assertEqual(
            self.ele.vendor_models, [(1, 2, {"Publish": True, "Subscribe": False})]
        )
        self.assertEqual(self.ele.models, [(3, {"Publish": False, "Subscribe": True})])

    def test_Element_update_model_config(self):
        config = {}
        self.ele.update_model_config(3, config)
        self.ele._models[(None, 3)].set_config.assert_called_with({})
        config = {"Vendor": 1}
        self.ele.update_model_config(2, config)
        self.ele._models[(1, 2)].set_config.assert_called_with({"Vendor": 1})

    def test_Element_update_model_config_handler(self):
        self.ele.update_model_config_handler(3, {})
        self.ele._models[(None, 3)].set_config.assert_called_with({})

    def test_Element_message_received_handler(self):
        # message_received
        self.ele._models[(1, 2)].message_received.return_value = None
        self.ele._models[(None, 3)].message_received.return_value = {"opcode": 0xDEAD}
        self.ele.message_received_handler(1, 2, 3, [4, 5, 6, 7])
        self.app.message_handler.assert_called_with({"opcode": 0xDEAD})

        self.ele._models[(1, 2)].message_received.return_value = {"opcode": 0xF00D}
        self.ele.message_received_handler(1, 2, 3, [4, 5, 6, 7])
        self.app.message_handler.assert_called_with({"opcode": 0xF00D})

        # dev_key_message_received
        self.ele._models[(1, 2)].dev_key_message_received.return_value = None
        self.ele._models[(None, 3)].dev_key_message_received.return_value = {
            "opcode": 0xBEEF
        }
        self.ele.dev_key_message_received_handler(1, True, 3, [4, 5, 6, 7])
        self.app.message_handler.assert_called_with({"opcode": 0xBEEF})

        self.ele._models[(None, 3)].dev_key_message_received.return_value = {
            "opcode": 0xC0FFEE
        }
        self.ele.dev_key_message_received_handler(1, False, 3, [4, 5, 6, 7])
        self.app.message_handler.assert_called_with({"opcode": 0xC0FFEE})
