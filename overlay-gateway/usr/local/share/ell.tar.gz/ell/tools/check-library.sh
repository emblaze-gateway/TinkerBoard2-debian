#!/bin/bash

readelf -Ws ell/.libs/libell.so | grep ELL_
