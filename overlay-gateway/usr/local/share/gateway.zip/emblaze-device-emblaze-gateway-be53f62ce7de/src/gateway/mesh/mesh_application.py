# -*- coding: utf-8 -*-
"""Bluemesh Appliation for communication with BlueZ"""
import logging as _logging
import uuid
from typing import Any

import bluemesh.bluemesh_logging as logging
from bluemesh.application import Application, ApplicationBuilder, ApplicationError
from bluemesh.db import ApplicationKey as DB_ApplicationKey
from bluemesh.db import ConfigurationDatabase
from bluemesh.db import Element as DB_Element
from bluemesh.db import NetworkKey as DB_NetworkKey
from bluemesh.db import Node as DB_Node
from bluemesh.element import Element
from bluemesh.models import (
    ConfigClient,
    GenericLevelClient,
    LightLCClient,
    LightLightnessClient,
)

from gateway.mesh.monitoring import (
    BaseTimestampClient,
    EnergyAccumulationClient,
    EnergyProfileClient,
    PIRCountAccumulationClient,
)

logger = _logging.getLogger("emblaze.mesh.mesh_application")

MODEL_LIST = {
    0x0001: ConfigClient,
    0x1003: GenericLevelClient,
    0x1302: LightLightnessClient,
    0x1311: LightLCClient,
    0x0059E000: BaseTimestampClient,
    0x0059E010: PIRCountAccumulationClient,
    0x0059E020: EnergyProfileClient,
    0x0059E021: EnergyAccumulationClient,
}


def create_cdb(cdb_object: dict[str, Any]) -> ConfigurationDatabase:
    """Make ConfigurationDatabase instance.

    Args:
        cdb_object: Python dictionary object read from cdb json.

    Returns:
        ConfigurationDatabase instance.

    """
    cdb_object["schema"] = cdb_object["$schema"]
    del cdb_object["$schema"]
    return ConfigurationDatabase(**cdb_object)


def get_uuid(cdb: ConfigurationDatabase, unicast_address: int) -> uuid.UUID:
    """Get the node's UUID.

    Args:
        unicast_address: Any element address of node.

    """
    return cdb.get_node(unicast_address).UUID


def _build_element_class(element: DB_Element) -> type["Element"]:
    """Dynamically making `Element` class"""
    name = element.name or f"Element{element.index}"
    base_class = (Element,)
    model_list = list(
        filter(
            lambda x: x is not None,
            [MODEL_LIST.get(model.modelId) for model in element.models],
        )
    )
    attrs = {
        "MODEL_CLASSES": model_list,
    }
    return type(name, base_class, attrs)


def _build_application_class(
    node: DB_Node, element_classes: list[type["Element"]]
) -> type["Application"]:
    """Dynamically making `Application` class"""
    name = "MeshApplication"
    base_class = (Application,)
    attrs = {
        "COMPANY_ID": node.cid,
        "PRODUCT_ID": node.pid,
        "VERSION_ID": node.vid,
        "ELEMENT_CLASSES": element_classes,
    }
    return type(name, base_class, attrs)


def __build(method) -> Application | None:
    try:
        app = method()
    except (AttributeError, ApplicationError) as e:
        logger.error("Build Fail - %r: %r", type(e), e)
        app = None
    else:
        logger.info("Application Build Success")
    return app


def _build(
    builder: ApplicationBuilder,
    token: int | None,
    node: DB_Node,
    net_key: DB_NetworkKey,
) -> Application | None:
    if token:
        logger.info("Application Attach")
        builder.set_token(token)
        app = __build(builder.build_attach)
    else:
        logger.info("Application Import and Attach")
        builder.set_uuid(uuid.uuid1())
        builder.set_address(node.unicastAddress)
        builder.set_primary_net_key((net_key.index, net_key.key))
        builder.set_dev_key(node.deviceKey)
        builder.set_iv_index(0)  # temporary
        builder.set_iv_update(False)  # temporary
        builder.set_key_refresh(False)  # temporary
        app = __build(builder.build_import_attach)
    return app


def _add_net_keys(
    app: Application,
    node: DB_Node,
    primary_key: int,
    net_keys: list[DB_NetworkKey],
) -> None:
    if len(net_keys) > 1:
        for net_key in net_keys[1:]:
            app.import_subnet(net_key.index, net_key.key)
            app[0][0x0001].netkey_add(
                node.unicastAddress, primary_key, net_key.index, net_key.key
            )
            logger.info("Add netkey: %r", net_key.index)


def _add_app_keys(
    app: Application,
    node: DB_Node,
    primary_key: int,
    app_keys: list[DB_ApplicationKey],
) -> None:
    if app_keys:
        for app_key in app_keys:
            app.import_app_key(app_key.boundNetKey, app_key.index, app_key.key)
            app[0][0x0001].appkey_add(
                node.unicastAddress,
                primary_key,
                app_key.boundNetKey,
                app_key.index,
                app_key.key,
            )
            logger.info("Add appkey: %r", app_key.index)


def _set_ttl(app: Application, node: DB_Node, net_key: int) -> None:
    if hasattr(node, "defaultTTL"):
        app[0][0x0001].default_ttl_set(node.unicastAddress, net_key, node.defaultTTL)
        logger.info("Set Default TTL: %r", node.defaultTTL)


def _set_network_transmit(app: Application, node: DB_Node, net_key: int) -> None:
    if hasattr(node, "networkTransmit"):
        app[0][0x0001].network_transmit_set(
            node.unicastAddress,
            net_key,
            node.networkTransmit.count,
            node.networkTransmit.interval,
        )
        logger.info(
            "Set Network Transmit: %r repetition(s) at %r ms interval",
            node.networkTransmit.count,
            node.networkTransmit.interval,
        )


def _set_relay_retransmit(app: Application, node: DB_Node, net_key: int) -> None:
    if hasattr(node, "relayRetransmit"):
        if node.relayRetransmit.count > 0:
            app[0][0x0001].relay_set(
                node.unicastAddress,
                net_key,
                1,
                node.relayRetransmit.count,
                node.relayRetransmit.interval,
            )
            logger.info(
                "Set Relay Retransmit: %r repetition(s) at %r ms interval",
                node.relayRetransmit.count,
                node.relayRetransmit.interval,
            )
        else:
            app[0][0x0001].relay_set(
                node.unicastAddress,
                net_key,
                0,
                node.relayRetransmit.count,
                node.relayRetransmit.interval,
            )
            logger.info("Unset Relay Retransmit")


def _bind_models(app: Application, node: DB_Node, net_key: int) -> None:
    for element in node.elements:
        for model in element.models:
            for bound_app_key in model.bind:
                app[0][0x0001].model_app_bind(
                    node.unicastAddress,
                    net_key,
                    node.unicastAddress + element.index,
                    bound_app_key,
                    model.modelId,
                )
                if model.modelId > 0xFFFF:
                    logger.info(
                        "model_app_bind: element(%d) - appkey(%d) - %08X",
                        element.index,
                        bound_app_key,
                        model.modelId,
                    )
                else:
                    logger.info(
                        "model_app_bind: element(%d) - appkey(%d) - %04X",
                        element.index,
                        bound_app_key,
                        model.modelId,
                    )


def _add_model_subscriptions(app: Application, node: DB_Node, net_key: int) -> None:
    for element in node.elements:
        for model in element.models:
            for sub in model.subscribe:
                if isinstance(sub, int):
                    app[0][0x0001].model_subscription_add(
                        node.unicastAddress,
                        net_key,
                        node.unicastAddress + element.index,
                        sub,
                        model.modelId,
                    )
                    if model.modelId > 0xFFFF:
                        logger.info(
                            "Add model subscription: %08X -> %04X", model.modelId, sub
                        )
                    else:
                        logger.info(
                            "Add model subscription: %04X -> %04X", model.modelId, sub
                        )
                else:
                    app[0][0x0001].model_subscription_virtual_address_add(
                        node.unicastAddress,
                        net_key,
                        node.unicastAddress + element.index,
                        sub,
                        model.modelId,
                    )
                    if model.modelId > 0xFFFF:
                        logger.info(
                            "Add model subscription: %08X -> %032X", model.modelId, sub
                        )
                    else:
                        logger.info(
                            "Add model subscription: %04X -> %032X", model.modelId, sub
                        )


def _add_remote_nodes(app: Application, cdb: ConfigurationDatabase) -> None:
    if len(cdb.nodes) >= 1:
        for remote_node in cdb.nodes:
            if not remote_node.excluded:
                app.import_remote_node(
                    remote_node.unicastAddress,
                    len(remote_node.elements),
                    remote_node.deviceKey,
                )
                logger.info("Add remote node: %04x", remote_node.unicastAddress)


def create_application(
    cdb: ConfigurationDatabase, token: int | None = None, sequence_number: int = 0
) -> Application | None:
    """create mesh application

    ConfigClient must be in element index 0.

    """

    # Gateway-self node's index == 0
    node = cdb.nodes[0]
    # Node's primary net key index == 0
    primary_key = cdb.get_net_key(node.netKeys[0].index)

    element_classes: list[type["Element"]] = [
        _build_element_class(element) for element in node.elements
    ]
    MeshApplication = _build_application_class(node, element_classes)
    builder = ApplicationBuilder(MeshApplication, "/emblaze/gateway", "dbus-python")
    app = _build(builder, token, node, primary_key)

    if app:
        logger.info("Token: %r", hex(app.token)[2:])

        if sequence_number:
            app.set_sequence_number(sequence_number)
            logger.info("Sequence Number: %d", app.sequence_number)

        net_keys = list(map(lambda x: cdb.get_net_key(x.index), node.netKeys))
        _add_net_keys(app, node, primary_key.index, net_keys)

        app_keys = list(map(lambda x: cdb.get_app_key(x.index), node.appKeys))
        _add_app_keys(app, node, primary_key.index, app_keys)

        _set_ttl(app, node, primary_key.index)

        _set_network_transmit(app, node, primary_key.index)

        _set_relay_retransmit(app, node, primary_key.index)

        _bind_models(app, node, primary_key.index)

        _add_model_subscriptions(app, node, primary_key.index)

        _add_remote_nodes(app, cdb)

    else:
        raise RuntimeError("Application Build Fail")

    return app
