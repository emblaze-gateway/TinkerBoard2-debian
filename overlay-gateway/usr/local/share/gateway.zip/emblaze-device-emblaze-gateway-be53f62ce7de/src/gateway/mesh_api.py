# -*- coding: utf-8 -*-
"""Communication through rpc"""

import asyncio
import logging
import queue
import threading
from typing import Any

from bluemesh.device_property import DevicePropertyID

from gateway.mesh.mesh_application import Application, get_uuid
from gateway.mq_api import send_monitoring_data
from gateway.rabbitmq_api import RpcClient

logger = logging.getLogger("emblaze.gateway.mesh_api")


async def config_default_ttl_status(source, fields) -> dict[str, Any]:
    # pylint: disable=unused-argument
    return {"status": {"ttl": fields["ttl"]}}


async def config_relay_status(source, fields) -> dict[str, Any]:
    # pylint: disable=unused-argument
    return {
        "status": {
            "relay_enable": fields["relay"],
            "realy_interval": fields["rtx_interval"],
            "relay_count": fields["rtx_cnt"],
        }
    }


async def config_network_transmit_status(source, fields) -> dict[str, Any]:
    # pylint: disable=unused-argument
    return {
        "status": {
            "network_interval": fields["tx_interval"],
            "network_count": fields["tx_cnt"],
        }
    }


async def generic_level_status(source, fields) -> dict[str, Any]:
    status = {"present_level": fields["present_level"]}
    if "target_level" in fields:
        status["target_level"] = fields["target_level"]
        status["remaining_time"] = fields["remaining_time"]

    return {"unicast": f"{source:04X}", "status": status}


async def light_lc_mode_status(source, fields) -> dict[str, Any]:
    return {
        "unicast": f"{source:04X}",
        "status": {
            "light_lc_mode": fields["mode"],
        },
    }


async def light_lc_om_status(source, fields) -> dict[str, Any]:
    return {
        "unicast": f"{source:04X}",
        "status": {
            "occupancy_mode": fields["mode"],
        },
    }


LC_PROPERTY = {
    DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_ON: "luxlevel_on",
    DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_PROLONG: "luxlevel_prolong",
    DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_STANDBY: "luxlevel_standby",
    DevicePropertyID.LIGHT_CONTROL_TIME_RUN_ON: "time_run_on",
    DevicePropertyID.LIGHT_CONTROL_TIME_PROLONG: "time_prolong",
    DevicePropertyID.LIGHT_CONTROL_TIME_FADE_ON: "time_fade_on",
    DevicePropertyID.LIGHT_CONTROL_TIME_FADE: "time_fade",
    DevicePropertyID.LIGHT_CONTROL_TIME_FADE_STANDBY_AUTO: "time_fade_standby_auto",
    DevicePropertyID.LIGHT_CONTROL_LIGHTNESS_ON: "lightness_on",
    DevicePropertyID.LIGHT_CONTROL_LIGHTNESS_PROLONG: "lightness_prolong",
    DevicePropertyID.LIGHT_CONTROL_LIGHTNESS_STANDBY: "lightness_standby",
}


async def light_lc_property_status(source, fields) -> dict[str, Any]:
    return {
        "unicast": f"{source:04X}",
        "status": {
            LC_PROPERTY[fields["property_id"]]: fields["property_value"],
        },
    }


async def energy_accumulation_status(source, fields) -> dict[str, Any]:
    return {
        "unicast": f"{source:04X}",
        "status": {
            "energy_accumulation": fields["accumulation"],
        },
    }


async def pir_accumulation_status(source, fields) -> dict[str, Any]:
    return {
        "unicast": f"{source:04X}",
        "status": {
            "pir_accumulation": fields["accumulation"],
        },
    }


async def config_model_subscription_status(source, fields) -> dict[str, Any] | None:
    # pylint: disable=unused-argument
    if fields["status"] != 0:
        return None
    return {
        "unicast": f"{fields['element_address']:04X}",
        "target_model_id": f"{fields['model_id']:04X}",
        "subscribe": f"{fields['address']:04X}",
    }


async def config_model_publication_status(source, fields) -> dict[str, Any] | None:
    # pylint: disable=unused-argument
    if fields["status"] != 0:
        return None
    return {
        "unicast": f"{fields['element_address']:04X}",
        "target_model_id": f"{fields['model_id']:04X}",
        "publish": {
            "address": f"{fields['publish_address']:04X}",
            "index": fields["app_key_index"],
            "credentials": fields["credential_flag"],
            "ttl": fields["ttl"],
            "period": fields["period"],
            "retransmit_count": fields["rtx_cnt"],
            "retransmit_interval": fields["rtx_interval"],
        },
    }


MESH_MSG_HANDLERS = {
    0x800E: config_default_ttl_status,
    0x8028: config_relay_status,
    0x8025: config_network_transmit_status,
    0x8208: generic_level_status,
    0x8294: light_lc_mode_status,
    0x8298: light_lc_om_status,
    0x64: light_lc_property_status,
    0xCE5900: energy_accumulation_status,
    0xC75900: pir_accumulation_status,
    0x801F: config_model_subscription_status,
    0x8019: config_model_publication_status,
}


OPCODES = {
    # Get mesh message opcode:
    0x800E: "configuration_data",
    0x8028: "configuration_data",
    0x8025: "configuration_data",
    0x8208: "generic_level_data",
    0x8294: "light_lc_data",
    0x8298: "light_lc_data",
    0x64: "light_lc_data",
    0xCE5900: "energy_accumulation_data",
    0xC75900: "pir_accumulation_data",
    0x801F: "subscribe_update_data",
    0x8019: "publish_update_data",
}


async def on_mesh(
    data: dict[str, Any],
    params: dict[str, Any],
) -> Any:
    logger.debug("[x] Incoming message: %r", data)
    timeout = data.pop("timeout", None)
    opcode: int = data["message"]["opcode"]
    source: int = data["message"]["source"]
    #  destination: int | bool = data.get("destination", data.get("remote"))
    #  key_index: int = data.get("key_index", data.get("net_index"))
    fields: dict[str, Any] = data["message"].get("fields", {})
    handler = MESH_MSG_HANDLERS.get(opcode)
    if callable(handler):
        mq_client = params["mq_client"]
        message = await handler(source, fields)
        if message is None:
            logger.debug(
                "Failure Ack from mesh network: source(%r), opcode(%04X), message(%r)",
                source,
                opcode,
                fields,
            )
            return "Receive Failure"
        message["device_uuid"] = str(get_uuid(params["cdb"], source))
        try:
            return await asyncio.wait_for(
                send_monitoring_data(mq_client, OPCODES[opcode], message),
                timeout=timeout,
            )
        except TimeoutError:
            return "Timeout"
    else:
        return "No Handler"


async def __mesh_loop(thread_queue: queue.Queue, mq_url: str, waiter: asyncio.Future):
    event_client = await RpcClient(mq_url, "event").connect()
    while not waiter.done():
        await event_client.call("heartbeat", {"from": "mesh_loop"})
        data: dict[str, Any] = {}

        for _ in range(60):
            if waiter.done() or data:
                break
            try:
                data["message"] = thread_queue.get(block=True, timeout=1)
            except queue.Empty:
                pass

        if not data:  # No message received for 1m
            continue

        logger.debug("mesh_loop: [x] Incoming message from bluemesh: %r", data)
        data["timeout"] = 10
        await event_client.call("mesh", data)
        thread_queue.task_done()
    await event_client.disconnect()


async def mesh_loop(mesh_app: Application, mq_url: str, waiter: asyncio.Future):
    await asyncio.sleep(3)
    mesh_queue: queue.Queue = queue.Queue(maxsize=200)
    mesh_app.register_queue(mesh_queue)
    thread = threading.Thread(
        target=asyncio.run,
        args=(__mesh_loop(mesh_queue, mq_url, waiter),),
    )
    thread.start()
    return thread
