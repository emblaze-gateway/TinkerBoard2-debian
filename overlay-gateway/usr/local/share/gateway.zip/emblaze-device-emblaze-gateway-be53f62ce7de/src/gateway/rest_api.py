# -*- coding: utf-8 -*-
"""REST api client

백엔드 서버에 REST API를 통한 요청을 처리.

Examples:
    다음은 Configuration Database를 요청하는 예시이다::

        >>> import gateway.rest_api
        >>> import asyncio
        >>> data = {
        ...    "api": 2000,
        ...    "id": "<USER ID>",
        ...    "z_idx_arr": ["<INDEX>", ...],
        >>> }
        >>> status, response = asyncio.run(rest_api.post("/ctrl_pn", data))
        >>> cdb = response["CDB"]
        >>> print(cdb)

"""
import base64
import hashlib
import hmac
import logging
import math
import time
from typing import Any

import aiohttp

logger = logging.getLogger("emblaze.gateway.rest_api")


def _generate_signature(
    method: str, timestamp: str, access_key: str, secret_key: str, segment: str
) -> str:
    msg = method + segment + "\n" + timestamp + "\n" + access_key

    enc = hmac.new(
        secret_key.encode("utf-8"), msg.encode("utf-8"), hashlib.sha256
    ).digest()
    return base64.b64encode(enc).decode("utf-8")


def get_current_timestamp() -> str:
    return str(math.trunc(time.time() * 1000))


API = {
    "/device": 30002,
    "/common": 30000,
    "/ctrl_pn": 30000,
}


def _url(protocol: str, domain: str, api: str) -> str:
    """url.

    Args:
        api (str): api
    """
    return protocol + "://" + domain + ":" + str(API[api]) + api


async def post(
    api: str, data: dict[str, Any], config: dict[str, str]
) -> tuple[int, dict[str, Any]]:
    """post.

    Args:
        api (str): API URL
        data (dict[str, Any]): dictionary object
    """
    http_method = "POST"
    timestamp = get_current_timestamp()
    signature = _generate_signature(
        http_method,
        timestamp,
        config["access_key"],
        config["secret_key"],
        config["segment"],
    )

    headers = {
        "content-type": "application/json;charset=UTF-8",
        "emblaze-ts-v1": timestamp,
        "emblaze-sg-v1": signature,
    }
    timeout = aiohttp.ClientTimeout(total=10)
    async with aiohttp.ClientSession(headers=headers, timeout=timeout) as session:
        async with session.post(
            _url(config["protocol"], config["domain"], api), json=data
        ) as response:
            ret = (response.status, await response.json())

    logger.debug("REST: api - %r, request - %r, result - %r", api, data, ret)
    return ret
