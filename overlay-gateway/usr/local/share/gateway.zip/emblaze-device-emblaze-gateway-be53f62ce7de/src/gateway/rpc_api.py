# -*- coding: utf-8 -*-
"""Communication through rpc"""

import asyncio
import logging
import threading
import uuid
from typing import Any, Callable

from bluemesh.application import Application
from bluemesh.db import ConfigurationDatabase

import gateway.rest_api
from gateway.mesh.mesh_application import create_application, create_cdb
from gateway.mesh_api import mesh_loop, on_mesh
from gateway.mq_api import mq_loop, on_mq
from gateway.rabbitmq_api import MQProducer, RpcClient, RpcServer, make_rpc_handler
from gateway.watchdog import sd_notify, watchdog_init

logger = logging.getLogger("emblaze.gateway.rpc_api")
LOCAL_MQ_URL = "amqp://guest:guest@127.0.0.1/"


async def on_rpc(
    data: dict[str, Any],
    params: dict[str, Any],
) -> Any:
    # pylint: disable=exec-used
    return_val = f"__result{uuid.uuid4().hex}"
    logger.debug("on_rpc: command: %r", data.get("command"))
    command_line = f"{return_val} = {data.pop('command')}"

    restricted_local: dict[str, Any] = {}

    restricted_local["cdb"] = params["cdb"]
    restricted_local["app"] = params["mesh_app"]

    exec(command_line, {}, restricted_local)
    logger.debug("on_rpc: result: %r", restricted_local[return_val])

    return str(restricted_local[return_val])


#  def get_rpc_client(user_id: str | None = None):
def get_rpc_client():
    client = RpcClient(LOCAL_MQ_URL, "event")
    #  user_id = user_id or uuid.uuid4().hex
    #  client.set_message_option("user_id", user_id)
    logger.debug("")
    return client


async def rpc(event_client: RpcClient, command: str):
    logger.debug("")
    return await event_client.call("rpc", {"command": command})


async def on_heartbeat(
    data: dict[str, Any],
) -> Any:
    logger.debug("on_heartbeat: pulse %r", data["from"])


async def heartbeat(event_client: RpcClient, waiter: asyncio.Future):
    await asyncio.sleep(3)
    while not waiter.done():
        await event_client.call("heartbeat", {"from": "event_loop"})
        await asyncio.sleep(60)


async def connect_to_server(gw_id: str, rest_config: dict[str, str]) -> tuple[str, str]:
    gw_queue = None
    try:
        gw_queue = await get_gateway_queue(gw_id, rest_config)
    except Exception as e:
        raise RuntimeError("Unable to connect to server") from e
    if gw_queue is None:
        raise RuntimeError("Cannot find gateway database from server")
    return gw_queue["pw"], gw_queue["queue"]


async def connect_to_event_client(mq_url: str) -> RpcClient:
    try:
        event_client = await RpcClient(mq_url, "event").connect()
    except Exception as e:
        raise RuntimeError("Failed to start local RPC client") from e
    return event_client


def get_rmq_url(gw_id: str, gw_pw: str, domain: str, port: str) -> str:
    return f"amqp://{gw_id}:{gw_pw}@{domain}:{port}"


async def connect_to_amqp_monitoring(rmq_url: str, gw_id: str) -> MQProducer:
    try:
        mq_client = await MQProducer(rmq_url, "monitoring").connect()
    except Exception as e:
        raise RuntimeError("Failed to connect to AMQP monitoring broker") from e
    mq_client.set_message_option("user_id", gw_id)
    return mq_client


async def connect_to_bluemesh(
    gw_id: str, rest_config: dict[str, str], mesh_config: dict[str, str]
) -> tuple[ConfigurationDatabase, Application]:
    try:
        cdb_dict = await get_cdb(gw_id, rest_config)
    except Exception as e:
        raise RuntimeError("Unable to get cdb from server") from e
    if not cdb_dict:
        raise RuntimeError("Cannot get CDB")
    cdb = create_cdb(cdb_dict)
    mesh_app = create_application(
        cdb,
        int(mesh_config.get("token", "0")) or None,
        int(mesh_config.get("seqnr", "0")),
    )
    return cdb, mesh_app


async def connect_to_event_server(rmq_url: str) -> RpcServer:
    try:
        event_server = RpcServer(rmq_url, "event")
    except Exception as e:
        raise RuntimeError("Failed to start local RPC server") from e
    return event_server


async def event_loop(config: dict[str, Any]) -> None:
    # pylint: disable=too-many-locals,too-many-statements
    event_client: RpcClient | None = None
    mq_client: MQProducer | None = None
    mesh_app: Application | None = None
    mesh_thread: threading.Thread | None = None

    try:
        sd_notify("STATUS=Starting up")

        waiter: asyncio.Future = asyncio.get_running_loop().create_future()
        event_parameters: dict[str, Any] = {}
        tasks: list[asyncio.Task] = []
        gw_id = config["gateway_id"]

        gw_pw, gw_queue = await connect_to_server(gw_id, config["rest"])

        def get_server_rmq_url(port: str) -> str:
            return get_rmq_url(gw_id, gw_pw, config["rabbitmq"]["domain"], port)

        event_client = await connect_to_event_client(LOCAL_MQ_URL)
        event_parameters["event_client"] = event_client

        producer_rmq_url = get_server_rmq_url(config["rabbitmq"]["monitoring_port"])
        mq_client = await connect_to_amqp_monitoring(producer_rmq_url, gw_id)
        event_parameters["mq_client"] = mq_client

        # MQ Server
        consumer_rmq_url = get_server_rmq_url(config["rabbitmq"]["control_port"])
        mq_server = mq_loop(
            gw_id,
            gw_queue,
            event_client,
            mq_client,
            consumer_rmq_url,
            waiter=waiter,
        )
        tasks.append(asyncio.create_task(mq_server))
        event_parameters["mq_server"] = mq_server

        # Mesh Client
        cdb, mesh_app = await connect_to_bluemesh(gw_id, config["rest"], config["mesh"])
        event_parameters["cdb"] = cdb
        event_parameters["mesh_app"] = mesh_app

        # Mesh Server
        mesh_coroutine = mesh_loop(mesh_app, LOCAL_MQ_URL, waiter)

        # Event Server
        event_server = await connect_to_event_server(LOCAL_MQ_URL)
        callback: dict[Callable, str] = {
            make_rpc_handler(on_rpc, params=event_parameters): "rpc",
            make_rpc_handler(on_mesh, params=event_parameters): "mesh",
            make_rpc_handler(on_mq, params=event_parameters): "mq",
            make_rpc_handler(on_heartbeat): "heartbeat",
        }
        tasks.append(asyncio.create_task(event_server.run(callback, waiter=waiter)))

        # Event loop Heartbeat
        tasks.append(asyncio.create_task(heartbeat(event_client, waiter)))

        # Watchdog
        watchdog_coroutine = watchdog_init(waiter)
        if watchdog_coroutine:
            tasks.append(asyncio.create_task(watchdog_coroutine))

        sd_notify("READY=1")
        sd_notify("STATUS=Running")

        mesh_thread = await mesh_coroutine
        for task in tasks:
            await task
        await waiter
    finally:
        sd_notify("STOPPING=1")
        sd_notify("STATUS=Quitting")
        if mesh_app:
            config["mesh"] = {"seqnr": mesh_app.sequence_number}
            mesh_app.leave_node()
        if event_client:
            await event_client.disconnect()
        if mq_client:
            await mq_client.disconnect()
        if not waiter.done():
            waiter.set_result(True)
        if mesh_thread:
            mesh_thread.join()
        await asyncio.sleep(1)


async def get_cdb(gw_id: str, config: dict[str, str]) -> dict[str, Any] | None:
    """1-3-6 Gateway CDB Get"""
    request = {
        "api": 12005,
        "gateway_id": gw_id,
    }
    response = await gateway.rest_api.post("/device", request, config)
    if response[0] == 200:
        return response[1]
    return None


async def get_gateway_queue(
    gw_id: str, config: dict[str, str]
) -> dict[str, Any] | None:
    """1-3-5 Gateway Queue Get"""
    request = {
        "api": 12004,
        "gateway_id": gw_id,
    }
    response = await gateway.rest_api.post("/device", request, config)
    if response[0] == 200:
        return response[1]
    return None
