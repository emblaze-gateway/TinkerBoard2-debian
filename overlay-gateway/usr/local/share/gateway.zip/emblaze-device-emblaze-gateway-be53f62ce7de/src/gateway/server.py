# -*- coding: utf-8 -*-
"""Internal routines"""

import argparse
import asyncio
import configparser
import copy
import json
import logging
import logging.config
import pathlib
import signal
import sys
import time
from typing import Any

from gateway.rpc_api import event_loop

logger = logging.getLogger("emblaze.gateway.server")

SAMPLE_CONFIG_FILE_PATH = pathlib.Path(__file__).parent / "example.ini"


def _sigterm_handler(signum, frame):
    raise SystemExit


def _sigabrt_handler(signum, frame):
    raise SystemExit


signal.signal(signal.SIGTERM, _sigterm_handler)
signal.signal(signal.SIGABRT, _sigabrt_handler)


def _parse_arguments(argv: list[str]) -> dict[str, Any]:
    default_directory_path = pathlib.Path.cwd() / "emblaze"

    default_config_file_path = default_directory_path / "config.ini"
    default_db_file_path = default_directory_path / "dat.json"
    default_log_file_path = default_directory_path / "log.log"

    parser = argparse.ArgumentParser(
        prog="emblaze_gateway", description="Emblaze gateway by Neostack"
    )
    parser.add_argument(
        "-c",
        "--conf",
        default=default_config_file_path,
        type=pathlib.Path,
        help="configuration file path. default: ${PWD}/emblaze/config.ini",
        metavar="CONFIG_FILE",
    )
    parser.add_argument(
        "-d",
        "--dat",
        default=default_db_file_path,
        type=pathlib.Path,
        help="database json file path. default: ${PWD}/emblaze/dat.json",
        metavar="DB_FILE",
    )
    parser.add_argument(
        "--log-file",
        default=default_log_file_path,
        type=pathlib.Path,
        help="log file path. default: ${PWD}/emblaze/log.log",
        metavar="LOG_FILE",
    )

    args = vars(parser.parse_args(argv))

    # config 파일이 default고 경로가 존재하지 않으면 생성
    # 또한, config 파일이 존재하지 않으면 기본 파일 생성
    if args["conf"] == default_config_file_path:
        default_directory_path.mkdir(parents=True, exist_ok=True)
        if not args["conf"].exists():
            with open(SAMPLE_CONFIG_FILE_PATH, "r", encoding="utf-8") as file:
                content = file.read()
            with open(args["conf"], "w", encoding="utf-8") as file:
                file.write(content)
            logger.error(
                "{} {}",
                "config 파일이 존재하지 않아 새로 생성되었습니다.",
                "해당 config 내용을 채운 후 다시 실행해주세요.",
            )
            sys.exit(1)

    if args["dat"] == default_db_file_path:
        default_directory_path.mkdir(parents=True, exist_ok=True)

    return args


def _initialize_logger(config: dict[str, Any], log_file_path: pathlib.Path) -> None:
    logging_obj = {
        "version": 1,
        "disable_existing_loggers": True,
        "formatters": {
            "verbose": {
                "format": "%(asctime)s - %(name)s - %(funcName)s - %(module)s - "
                "%(process)d - %(thread)d - %(levelname)s - %(message)s"
            },
            "default": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            },
            "simple": {"format": "%(name)s - %(levelname)s - %(message)s"},
        },
        "handlers": {
            "null": {
                "level": "DEBUG",
                "class": "logging.NullHandler",
            },
            "console": {
                "level": "INFO",
                "class": "logging.StreamHandler",
                "formatter": "default",
            },
            "console_simple": {
                "level": "INFO",
                "class": "logging.StreamHandler",
                "formatter": "simple",
            },
            "console_verbose": {
                "level": "INFO",
                "class": "logging.StreamHandler",
                "formatter": "verbose",
            },
            "file": {
                "level": "DEBUG",
                "class": "logging.FileHandler",
                "formatter": "default",
                "filename": str(log_file_path),
                "mode": "a",
            },
            "file_verbose": {
                "level": "DEBUG",
                "class": "logging.FileHandler",
                "formatter": "verbose",
                "filename": str(log_file_path),
                "mode": "a",
            },
        },
    }

    if "loggers" in config:
        logging_obj["loggers"] = config["loggers"]
    if "root_logger" in config:
        logging_obj["root"] = config["root_logger"]

    logging.config.dictConfig(logging_obj)


def _get_logger_options(section: configparser.SectionProxy, option: str) -> Any:
    if option == "handlers":
        return list(
            map(
                lambda s: s.strip(),
                section.get(option, "null").split(","),
            )
        )
    elif option == "level":
        return section.get(option, "WARNING")
    elif option == "propagate":
        return section.getboolean(option, "no")
    else:
        return None


def _parse_config(config_string: str) -> tuple[dict[str, Any], dict[str, Any]]:
    parser = configparser.ConfigParser()

    parser.read_string(config_string)

    # gateway config
    required_options = {
        "main": ["gateway_id"],
        "rabbitmq": ["domain", "monitoring_port", "control_port"],
        "rest": ["access_key", "secret_key", "segment", "domain"],
    }

    if not set(parser.sections()).issuperset(required_options.keys()):
        raise AttributeError(
            "Missed required config: "
            f"{set(required_options.keys()) - set(parser.sections())}"
        )
    for sec, opts in required_options.items():
        if not set(parser.options(sec)).issuperset(opts):
            raise AttributeError(
                "Missed required options from "
                f"{sec}: {set(opts) - set(parser.options(sec))}"
            )

    config = {
        "gateway_id": parser.get("main", "gateway_id"),
        "rabbitmq": dict(parser.items("rabbitmq")),
        "rest": dict(parser.items("rest")),
    }

    # logger config
    logger_config: dict[str, Any] = {}
    if parser.has_section("logger"):
        logger_section = parser["logger"]
        logger_config["keys"] = list(
            map(lambda s: s.strip(), logger_section.get("keys", "").split(","))
        )
        default_logger: dict[str, Any] = {
            key: _get_logger_options(logger_section, key)
            for key in ["handlers", "level", "propagate"]
        }
        for sub_logger_name in logger_config["keys"]:
            sub_logger_section_name = "logger." + sub_logger_name
            current_logger = copy.deepcopy(default_logger)
            if parser.has_section(sub_logger_section_name):
                sub_logger = parser[sub_logger_section_name]
                for option in sub_logger.keys():
                    current_logger[option] = _get_logger_options(sub_logger, option)

            if sub_logger_name == "root":
                current_logger.pop("propagate", None)
                logger_config["root_logger"] = current_logger
            else:
                if "loggers" not in logger_config:
                    logger_config["loggers"] = {}
                logger_config["loggers"][sub_logger_name] = current_logger

    return config, logger_config


def main() -> None:
    args = _parse_arguments(sys.argv[1:])

    if not args["conf"].exists():
        logger.error("config 파일이 존재하지 않습니다.")
        sys.exit(1)

    with open(args["conf"], encoding="utf-8") as file:
        config_string = file.read()

    config, logger_config = _parse_config(config_string)

    _initialize_logger(logger_config, args["log_file"])

    if not args["dat"].exists():
        with open(args["dat"], "w", encoding="utf-8") as file:
            json.dump({}, file)

    with open(args["dat"], encoding="utf-8") as file:
        config["mesh"] = json.load(file)

    err_code = 0
    try:
        asyncio.run(event_loop(config))
    except KeyboardInterrupt:
        logger.info(" [*] Interrupted")
        err_code = 1
    except SystemExit:
        logger.info(" [*] Terminated")
        err_code = 2
    except Exception as e:
        logger.error("%r", e)
        err_code = 3
    finally:
        time.sleep(1)
        with open(args["dat"], "w", encoding="utf-8") as file:
            json.dump(dict(config["mesh"]), file)
        sys.exit(err_code)


if __name__ == "__main__":
    main()
