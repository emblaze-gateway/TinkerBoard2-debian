"""Systemd module"""

import asyncio
import logging
import os
from collections.abc import Coroutine

logger = logging.getLogger("emblaze.gateway.watchdog")

_PID = os.environ.get("WATCHDOG_PID")
_USEC = os.environ.get("WATCHDOG_USEC")
_SOCK = os.environ.get("NOTIFY_SOCKET")


try:
    from systemd import daemon as sd
except ImportError:
    logger.warning("Unused systemd module")

    def _sd_booted() -> bool:
        return False

    def _sd_notify(status: str, pid: int) -> None:
        # pylint: disable=unused-argument
        pass

else:

    def _sd_booted() -> bool:
        return sd.booted()

    if _SOCK:

        def _sd_notify(status: str, pid: int) -> None:
            sd.notify(status, pid=pid)

    else:
        logger.warning("Unset systemd notification")

        def _sd_notify(status: str, pid: int) -> None:
            # pylint: disable=unused-argument
            pass


def sd_notify(status: str, pid: int = 0) -> None:
    """Send a message to systemd

    Wraps sd_notify(3).

    Args:
        status: Message
        pid: Process ID. default 0 (current process ID)

    """
    _sd_notify(status, pid)


def _get_watchdog_interval(usec: int) -> float:
    return usec / 1000000 / 3


def watchdog_init(waiter: asyncio.Future) -> Coroutine | None:
    """Systemd watchdog initialize.

    When the system have run by systemd with watchdog, an asyncio.Task start to send
    notify "Watchdog". It should run on event loop.

    Returns:
        If it run on systemd with watchdog, returns coroutine task for Watchdog loop.
        Otherwise, returns None.

    """
    if not _sd_booted():
        logger.warning("NOT used systemd")
        logger.warning(
            "%s %s",
            "The system does not use systemd",
            "or the systemd python module is not installed.",
        )
        return None

    if not _PID or not _USEC:
        logger.debug("Watchdog NOT set.")
        return None

    pid = int(_PID)
    interval = _get_watchdog_interval(int(_USEC))
    logger.debug("Watchdog set. PID(%d) interval sec(%f)", pid, interval)

    return _watchdog_loop(pid, interval, waiter)


async def _watchdog_loop(pid: int, interval: float, waiter: asyncio.Future) -> None:
    while not waiter.done():
        _watchdog_callback(pid)
        await asyncio.sleep(interval)


def _watchdog_callback(pid: int) -> None:
    sd_notify("WATCHDOG=1", pid=pid)
