# emblaze Gateway

[![pre-commit](https://img.shields.io/badge/pre--commit%202.20.0-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)
[![Code style: black](https://img.shields.io/badge/code%20style-black%2022.6.0-black.svg)](https://github.com/psf/black)
[![Code style: flake8](https://img.shields.io/badge/pep8-flake8%204.0.1-CC9900)](https://github.com/pycqa/flake8)
[![linting: pylint](https://img.shields.io/badge/linting-pylint%202.14.5-yellowgreen.svg)](https://github.com/PyCQA/pylint)
[![Imports: isort](https://img.shields.io/badge/imports-isort%205.9.3-%231674b1?style=flat&labelColor=ef8336)](https://pycqa.github.io/isort/)
[![Checked with mypy](https://img.shields.io/badge/typing-mypy%200.981-333CCC)](http://mypy-lang.org/)
[![Docs: sphinx](https://img.shields.io/badge/Made%20with-Sphinx-1f425f.svg)](https://www.sphinx-doc.org/)

[![Python](http://ForTheBadge.com/images/badges/made-with-python.svg)](https://www.python.org/)

---

TCP 기반의 광범위 네트워크와 Bluetooth 기반의 지역 네트워크를 연결하는 게이트웨이 소프트웨어.
HTTP기반의 REST API를 사용하여 서버와 통신하고, Bluetooth Mesh profile을 이용하여 조명 및 센서 등과
같은 디바이스를 조작하고 데이터를 수집한다.

## Table of contents

- [emblaze Gateway](#emblaze-gateway)
    * [Table of contents](#table-of-contents)
    * [Version](#version)
    * [Environment](#environment)
    * [Installation](#installation)
        + [Git](#git)
    * [Usage](#usage)
        + [Server](#server)
        + [Command Line Interface](#command-line-interface)
    * [Test](#test)
        + [unittest](#unittest)
        + [coverage](#coverage)
    * [Documentation](#documentation)
        + [Sphinx](#sphinx)


## Version

|Version|Patch Note|
|:-----:|----------|
|0.0.0  |Advanced development. No release.|


## Environment

|Module  |Version|Note|
|--------|-------|----|
|Python  |3.10.6 ||
|Kernel  |5.15.0 |Ubuntu 20.04.|
|BlueZ   |5.65   |www.bluez.org/release-of-bluez-5-65/. See also Github. Download the source code.|
|Bluemesh|0.1.0  |BlueZ SDK.|
|AMQP    |0-9-1  |Open, general-purpose protocol for messaging.|
|RabbitMQ|3.8.2  |Most widely deployed open source message broker.|


## Installation

### Git

Repository를 다운로드 받고, pip를 통해 다운로드한다.

```bash
$ git clone <repository> or wget <repository zip url> && tar -xvf <reopsitory zip>
$ cd emblaze-gateway
$ pip install .
```


## Usage

### Server

서버의 경우, KeyboardInterrupt가 발생할 때까지 동작한다. CTRL+C를 입력하면 종료된다.

#### Example

```bash
$ emblaze_gateway
INFO:root: [*] Waiting for messages. To exit press CTRL+C
```

### Command Line Interface

CUI 환경에서 게이트웨이를 제어하고 싶을 때 사용하는 툴. 서버가 동작하고 있는 상태에서 실행해야한다.
네트워크를 통한 원격제어와 동시에 사용 가능하다.

#### Example

```bash
$ emblaze_gw_cli
>>> helper()
>>> helper(name="get_cdb")
>>> cdb_data = get_cdb()
>>> print(cdb_data)
```


## Test

### unittest

Add tests into "test" directory, as filename with prefix `test_`.
Run whole test using setuptools.

```
python3 setup.py test
```

### coverage

#### Prerequirement

Install coverage

```
pip install "bluemesh[test]"
```

Make coverage files using setuptools.

```
python3 setup.py coverage
```

HTML output is made to `docs/coverage_report_html` directory.


## Documentation

### Sphinx

#### Prerequirement

Install Sphinx

```
pip install "bluemesh[docs]"
```

To build technical documents using sphinx, as follow:

```bash
sphinx-apidoc -f -o docs/source bluemesh
python setup.py build_sphinx [options...]
```

You can find html document in `docs/sphinx/`.
Get more information about sphinx from [here](https://www.sphinx-doc.org/en/master/usage/advanced/setuptools.html)
