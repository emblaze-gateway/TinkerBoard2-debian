# -*- coding: utf-8 -*-
"""Bluemesh Appliation for communication with BlueZ"""
import logging as _logging
import uuid

import bluemesh.bluemesh_logging as logging
from bluemesh.application import Application, ApplicationBuilder, ApplicationError
from bluemesh.db import ConfigurationDatabase
from bluemesh.element import Element
from bluemesh.models import (
    ConfigClient,
    GenericLevelClient,
    LightLCClient,
    LightLightnessClient,
)

from gateway.mesh.monitoring import (
    BaseTimestampClient,
    EnergyAccumulationClient,
    EnergyProfileClient,
    PIRCountAccumulationClient,
)

logger = _logging.getLogger("emblaze.mesh.mesh_application")

MODEL_LIST = {
    0x0001: ConfigClient,
    0x1003: GenericLevelClient,
    0x1302: LightLightnessClient,
    0x1311: LightLCClient,
    0x0059E000: BaseTimestampClient,
    0x0059E010: PIRCountAccumulationClient,
    0x0059E020: EnergyProfileClient,
    0x0059E021: EnergyAccumulationClient,
}


def create_cdb(**kwargs) -> ConfigurationDatabase:
    kwargs["schema"] = kwargs["$schema"]
    del kwargs["$schema"]
    return ConfigurationDatabase(**kwargs)


def build(method):
    try:
        app = method()
    except (AttributeError, ApplicationError) as e:
        logger.error("Build Fail - %r: %r", type(e), e)
        app = None
    else:
        logger.info("Application Build Success")
    return app


def create_application(
    cdb: ConfigurationDatabase, token: int | None = None, sequence_number: int = 0
):
    # pylint: disable=too-many-locals,too-many-branches,too-many-statements
    """create mesh application

    ConfigClient must be in element index 0.

    """

    node = cdb.nodes[0]
    element_classes = []
    for element in node.elements:
        element_name = element.name or f"Element{element.index}"
        element_base_class = (Element,)
        element_model_list = list(
            filter(
                lambda x: x is not None,
                [MODEL_LIST.get(model.modelId) for model in element.models],
            )
        )
        element_attrs = {
            "MODEL_CLASSES": element_model_list,
        }
        element_classes.append(type(element_name, element_base_class, element_attrs))

    application_name = "MeshApplication"
    application_base_class = (Application,)
    application_attrs = {
        "COMPANY_ID": node.cid,
        "PRODUCT_ID": node.pid,
        "VERSION_ID": node.vid,
        "ELEMENT_CLASSES": element_classes,
    }
    MeshApplication = type(application_name, application_base_class, application_attrs)

    builder = ApplicationBuilder(MeshApplication, "/emblaze/gateway", "dbus-python")

    netkey = 0

    if token:
        logger.info("Application Attach")
        builder.set_token(token)
        app = build(builder.build_attach)
    else:
        logger.info("Application Import and Attach")
        builder.set_uuid(uuid.uuid1())
        builder.set_address(node.unicastAddress)
        netkey = node.netKeys[0].index
        builder.set_primary_net_key((netkey, cdb.get_net_key(netkey).key))
        builder.set_dev_key(node.deviceKey)
        builder.set_iv_index(0)
        builder.set_iv_update(False)
        builder.set_key_refresh(False)
        app = build(builder.build_import_attach)

    if app:
        if sequence_number:
            assert isinstance(sequence_number, int)
            app.set_sequence_number(sequence_number)
            logger.info("Sequence Number: %d", app.sequence_number)

        logger.info("Token: %r", hex(app.token)[2:])

        if len(node.netKeys) > 1:
            for node_key in node.netKeys[1:]:
                net_key = cdb.get_net_key(node_key.index)
                app.import_subnet(net_key.index, net_key.key)
                app[0][0x0001].netkey_add(
                    node.unicastAddress, netkey, net_key.index, net_key.key
                )
                logger.info("netkey_add: %r", net_key.index)

        if node.appKeys:
            for node_key in node.appKeys:
                app_key = cdb.get_app_key(node_key.index)
                app.import_app_key(app_key.boundNetKey, app_key.index, app_key.key)
                app[0][0x0001].appkey_add(
                    node.unicastAddress,
                    netkey,
                    app_key.boundNetKey,
                    app_key.index,
                    app_key.key,
                )
                logger.info("appkey_add: %r", app_key.index)

        if hasattr(node, "defaultTTL"):
            app[0][0x0001].default_ttl_set(node.unicastAddress, netkey, node.defaultTTL)
        if hasattr(node, "networkTransmit"):
            app[0][0x0001].network_transmit_set(
                node.unicastAddress,
                netkey,
                node.networkTransmit.count,
                node.networkTransmit.interval,
            )
        if hasattr(node, "relayRetransmit"):
            if node.relayRetransmit.count > 0:
                app[0][0x0001].relay_set(
                    node.unicastAddress,
                    netkey,
                    1,
                    node.relayRetransmit.count,
                    node.relayRetransmit.interval,
                )
            else:
                app[0][0x0001].relay_set(
                    node.unicastAddress,
                    netkey,
                    0,
                    node.relayRetransmit.count,
                    node.relayRetransmit.interval,
                )

        for element in node.elements:
            for model in element.models:
                for bound_app_key in model.bind:
                    app[0][0x0001].model_app_bind(
                        node.unicastAddress,
                        netkey,
                        node.unicastAddress + element.index,
                        bound_app_key,
                        model.modelId,
                    )
                    logger.info(
                        "model_app_bind: %r - %r - %r",
                        element.index,
                        bound_app_key,
                        model.modelId,
                    )
                for sub in model.subscribe:
                    if isinstance(sub, int):
                        app[0][0x0001].model_subscription_add(
                            node.unicastAddress,
                            netkey,
                            node.unicastAddress + element.index,
                            sub,
                            model.modelId,
                        )
                    else:
                        app[0][0x0001].model_subscription_virtual_address_add(
                            node.unicastAddress,
                            netkey,
                            node.unicastAddress + element.index,
                            sub,
                            model.modelId,
                        )
                    logger.info("model_subscription_add: %r", sub)

        if len(cdb.nodes) > 1:
            for remote_node in cdb.nodes:
                if not remote_node.excluded:
                    app.import_remote_node(
                        remote_node.unicastAddress,
                        len(remote_node.elements),
                        remote_node.deviceKey,
                    )
                    logger.info("import remote node: %r", remote_node.unicastAddress)
    else:
        logger.error("Application Build Fail: Missing required attributes")

    return app
