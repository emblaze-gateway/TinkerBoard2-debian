# -*- coding: utf-8 -*-
# pylint: disable=unused-argument
"""Neostack Monitoring Model"""
import datetime as dt
import struct
from typing import Any, Callable

import bluemesh.bluemesh_logging as logging
from bluemesh.access import AccessMessage
from bluemesh.models.base import Model

logger = logging.getLogger("emblaze.mesh.models.vendor")


class BaseTimestampClient(Model):
    """모니터링 누적 시작 시간 모델"""

    MODEL_ID = 0xE000
    VENDOR = 0x0059
    #  VENDOR = None
    HANDLERS: dict[int, Callable] = {}
    SUBSCRIBE = True

    @Model.send(0xC15900, "")
    def get(self, dest, key_index):
        """설정 되어있는 BaseTimestamp 값 요청"""

    @Model.send(0xC25900, "(vbt)")
    def set(self, dest, key_index, timestamp: dt.datetime):
        """BaseTimestamp 값 설정 및 Accumulation 값 초기화"""
        return [timestamp]

    @Model.send(0xC35900, "")
    def reset(self, dest, key_index):
        """Accumulation 중단"""

    @Model.message_handler(HANDLERS, 0xC45900, "(vbt)")
    def status_handler(self, source, key_index, destination, fields):
        """BaseTimestamp 응답"""
        timestamp = fields[0]
        logger.info("BaseTimestamp: {}", timestamp)
        return {"timestamp": timestamp}


class PIRCountAccumulationClient(Model):
    """PIR 인식 횟수 누적 모델"""

    MODEL_ID = 0xE010
    VENDOR = 0x0059
    #  VENDOR = None
    HANDLERS: dict[int, Callable] = {}
    SUBSCRIBE = True

    @Model.send(0xC55900, "")
    def get(self, dest, key_index):
        """누적값 요청"""

    @Model.send(0xC65900, "")
    def reset(self, dest, key_index):
        """누적 중단"""

    @Model.message_handler(HANDLERS, 0xC75900, "I")
    def status_handler(self, source, key_index, destination, fields):
        """누적값 응답"""
        accumulation = fields[0]
        logger.info("PIRCountAccumulation: {}", accumulation)
        return {"accumulation": accumulation}


class EnergyProfileClient(Model):
    """전력 프로파일 모델

    밝기에 따른 전력 세기에 대한 테이블을 저장한다.

    """

    MODEL_ID = 0xE020
    VENDOR = 0x0059
    #  VENDOR = None
    HANDLERS: dict[int, Callable] = {}
    SUBSCRIBE = True

    @Model.send(0xC85900, "")
    def get(self, dest, key_index):
        """테이블 요청"""

    # set method는 현재 사용하지 않으므로 구현 안함

    @Model.send(0xCA5900, "")
    def reset(self, dest, key_index):
        """테이블 초기화"""

    @Model.message_handler(HANDLERS, 0xCB5900, "{(vep)}")
    def status_handler(self, source, key_index, destination, fields):
        """테이블 응답"""
        profiles = fields[0]
        logger.info("EnergyProfile: {}", profiles)
        return {"profiles": profiles}


class EnergyAccumulationClient(Model):
    """전력 소모량 누적 모델"""

    MODEL_ID = 0xE021
    VENDOR = 0x0059
    #  VENDOR = None
    HANDLERS: dict[int, Callable] = {}
    SUBSCRIBE = True

    @Model.send(0xCC5900, "")
    def get(self, dest, key_index):
        """누적값 요청"""

    @Model.send(0xCD5900, "")
    def reset(self, dest, key_index):
        """누적값 초기화"""

    @Model.message_handler(HANDLERS, 0xCE5900, "I")
    def status_handler(self, source, key_index, destination, fields):
        """누적값 응답"""
        accumulation = fields[0]
        logger.info("EnergyAccumulation: {}", accumulation)
        return {"accumulation": accumulation}


def pack_base_timestamp(datetime: dt.datetime, signature: str) -> bytes:
    datestr = datetime.strftime("%y%m%d%H%M%S")
    datalist = [int(datestr[x : x + 2]) for x in range(0, 12, 2)]
    data = struct.pack("<BBBBBB", *datalist)
    return data


def unpack_base_timestamp(data: bytes, signature: str) -> tuple[dt.datetime, int]:
    datalist = struct.unpack("<BBBBBB", data[:6])
    datestr = "".join(map(str, datalist))
    datetime = dt.datetime.strptime(datestr, "%y%m%d%H%M%S")
    return datetime, 6


def unpack_energy_profile(data: bytes, signature: str) -> tuple[Any, int]:
    profile = struct.unpack("<BH", data[:3])
    return profile, 3


AccessMessage.set_signature(
    "vbt", pack_func=pack_base_timestamp, unpack_func=unpack_base_timestamp
)

AccessMessage.set_signature("vep", unpack_func=unpack_energy_profile)
