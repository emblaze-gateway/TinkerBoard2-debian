# -*- coding: utf-8 -*-
"""Communication through rpc"""

import asyncio
import logging
import queue
import threading
from typing import Any

from bluemesh.device_property import DevicePropertyID

from gateway import mq_api
from gateway.mesh.mesh_application import Application
from gateway.rabbitmq_api import RpcClient

logger = logging.getLogger("emblaze.gateway.mesh_api")


async def config_default_ttl_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    message = {"status": {"ttl": fields["ttl"]}}
    await mq_api.configuration_data(mq_client, uuid, message)


async def config_relay_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    message = {
        "status": {
            "relay_enable": fields["relay"],
            "realy_interval": fields["rtx_interval"],
            "relay_count": fields["rtx_cnt"],
        }
    }
    await mq_api.configuration_data(mq_client, uuid, message)


async def config_network_transmit_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    message = {
        "status": {
            "network_interval": fields["tx_interval"],
            "network_count": fields["tx_cnt"],
        }
    }
    await mq_api.configuration_data(mq_client, uuid, message)


async def generic_level_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID

    status = {"present_level": fields["present_level"]}
    if "target_level" in fields:
        status["target_level"] = fields["target_level"]
        status["remaining_time"] = fields["remaining_time"]

    message = {"unicast": f"{source:04X}", "status": status}

    await mq_api.generic_level_data(mq_client, uuid, message)


async def light_lc_mode_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    message = {
        "unicast": f"{source:04X}",
        "status": {
            "light_lc_mode": fields["mode"],
        },
    }
    await mq_api.light_lc_data(mq_client, uuid, message)


async def light_lc_om_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    message = {
        "unicast": f"{source:04X}",
        "status": {
            "occupancy_mode": fields["mode"],
        },
    }
    await mq_api.light_lc_data(mq_client, uuid, message)


LC_PROPERTY = {
    DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_ON: "luxlevel_on",
    DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_PROLONG: "luxlevel_prolong",
    DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_STANDBY: "luxlevel_standby",
    DevicePropertyID.LIGHT_CONTROL_TIME_RUN_ON: "time_run_on",
    DevicePropertyID.LIGHT_CONTROL_TIME_PROLONG: "time_prolong",
    DevicePropertyID.LIGHT_CONTROL_TIME_FADE_ON: "time_fade_on",
    DevicePropertyID.LIGHT_CONTROL_TIME_FADE: "time_fade",
    DevicePropertyID.LIGHT_CONTROL_TIME_FADE_STANDBY_AUTO: "time_fade_standby_auto",
    DevicePropertyID.LIGHT_CONTROL_LIGHTNESS_ON: "lightness_on",
    DevicePropertyID.LIGHT_CONTROL_LIGHTNESS_PROLONG: "lightness_prolong",
    DevicePropertyID.LIGHT_CONTROL_LIGHTNESS_STANDBY: "lightness_standby",
}


async def light_lc_property_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    message = {
        "unicast": f"{source:04X}",
        "status": {
            LC_PROPERTY[fields["property_id"]]: fields["property_value"],
        },
    }
    await mq_api.light_lc_data(mq_client, uuid, message)


async def energy_accumulation_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    message = {
        "unicast": f"{source:04X}",
        "status": {
            "energy_accumulation": fields["accumulation"],
        },
    }
    await mq_api.energy_accumulation_data(mq_client, uuid, message)


async def pir_accumulation_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    message = {
        "unicast": f"{source:04X}",
        "status": {
            "pir_accumulation": fields["accumulation"],
        },
    }
    await mq_api.pir_accumulation_data(mq_client, uuid, message)


async def config_model_subscription_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    if fields["status"] != 0:
        return
    message = {
        "unicast": f"{fields['element_address']:04X}",
        "target_model_id": f"{fields['model_id']:04X}",
        "subscribe": f"{fields['address']:04X}",
    }
    await mq_api.subscribe_update_data(mq_client, uuid, message)


async def config_model_publication_status(params: dict[str, Any], source, fields):
    mq_client = params["mq_client"]
    uuid = params["cdb"].get_node(source).UUID
    if fields["status"] != 0:
        return
    message = {
        "unicast": f"{fields['element_address']:04X}",
        "target_model_id": f"{fields['model_id']:04X}",
        "publish": {
            "address": f"{fields['publish_address']:04X}",
            "index": fields["app_key_index"],
            "credentials": fields["credential_flag"],
            "ttl": fields["ttl"],
            "period": fields["period"],
            "retransmit_count": fields["rtx_cnt"],
            "retransmit_interval": fields["rtx_interval"],
        },
    }
    await mq_api.publish_update_data(mq_client, uuid, message)


MESH_HANDLERS = {
    0x800E: config_default_ttl_status,
    0x8028: config_relay_status,
    0x8025: config_network_transmit_status,
    0x8208: generic_level_status,
    0x8294: light_lc_mode_status,
    0x8298: light_lc_om_status,
    0x64: light_lc_property_status,
    0xCE5900: energy_accumulation_status,
    0xC75900: pir_accumulation_status,
    0x801F: config_model_subscription_status,
    0x8019: config_model_publication_status,
}


async def on_mesh(
    data: dict[str, Any],
    params: dict[str, Any],
) -> Any:
    logger.debug("on_mesh: [x] Incoming message: %r", data)
    timeout = data.pop("timeout", None)
    opcode: int = data["message"]["opcode"]
    source: int = data["message"]["source"]
    #  destination: int | bool = data.get("destination", data.get("remote"))
    #  key_index: int = data.get("key_index", data.get("net_index"))
    fields: dict[str, Any] = data["message"].get("fields", {})
    function = MESH_HANDLERS.get(opcode)
    try:
        if callable(function):
            return await asyncio.wait_for(
                function(params, source, fields), timeout=timeout
            )
        else:
            return "No Handler"
    except TimeoutError:
        return "Timeout"


async def __mesh_loop(thread_queue: queue.Queue, event_client: RpcClient):
    logger.debug("__mesh_loop: event_client")
    await event_client.connect()
    await event_client.call("heartbeat", {"from": "mesh_loop"})
    while True:
        data = {}
        while True:
            try:
                data["message"] = thread_queue.get(block=True, timeout=60)
            except queue.Empty:
                await event_client.call("heartbeat", {"from": "mesh_loop"})
            else:
                break

        logger.debug("mesh_loop: [x] Incoming message from bluemesh: %r", data)
        if data["message"] == "exit":
            break
        data["timeout"] = 5
        await event_client.call("mesh", data)


async def mesh_loop(mesh_app: Application, event_client: RpcClient):
    await asyncio.sleep(3)
    logger.debug("mesh_loop: start")

    mesh_queue: queue.Queue = queue.Queue(maxsize=200)
    mesh_app.register_queue(mesh_queue)
    mesh_event_thread = threading.Thread(
        target=asyncio.run, args=(__mesh_loop(mesh_queue, event_client),), daemon=True
    )
    mesh_event_thread.start()

    logger.debug("mesh_loop: running")

    await asyncio.Future()

    # Mesh Destroy
    #  mesh_app.unregister_queue(mesh_queue)
    #  del mesh_app
    #  mesh_queue.put("exit")
    #  mesh_event_thread.join()
    #  mesh_queue.join()
    logger.debug("mesh_loop: end")
