# -*- coding: utf-8 -*-
"""Communication with server"""

import asyncio
import datetime
import logging
import os
import uuid as _uuid
from typing import Any, Callable

import psutil
from bluemesh.device_property import DevicePropertyID

from gateway.mesh.mesh_application import Application
from gateway.rabbitmq_api import MQConsumer, MQProducer, RpcClient, make_handler

logger = logging.getLogger("emblaze.gateway.mq_api")

MESH_RABBITMQ_URL = "amqp://guest:guest@127.0.0.1/"


def send_iteration(
    app: Application,
    element: int,
    model_id: int,
    key_index: int,
    target_addresses: list[str],
    send_msgs: list[tuple[str, list[Any]]],
) -> None:
    # pylint: disable=too-many-arguments
    sends = []
    for msg, fields in send_msgs:
        sends.append((getattr(app[element][model_id], msg), fields))

    for addr in target_addresses:
        for send, fields in sends:
            assert callable(send)
            send(int(addr, base=16), key_index, *fields)


async def configuration_set(params: dict[str, Any], **kwargs) -> None:
    logger.info("configuration_set: %r", kwargs)
    args = kwargs["set"]

    send_msgs: list[tuple[str, list[Any]]] = []
    ttl = args.get("ttl")
    relay_enable = args.get("relay_enable")
    relay_count = args.get("relay_count")
    relay_interval = args.get("relay_interval")
    network_count = args.get("network_count")
    network_interval = args.get("network_interval")

    if ttl is not None:
        send_msgs.append(
            (
                "default_ttl_set",
                [ttl],
            )
        )
    if (
        relay_enable is not None
        and relay_count is not None
        and relay_interval is not None
    ):
        send_msgs.append(("relay_set", [relay_enable, relay_count, relay_interval]))
    if network_count is not None and network_interval is not None:
        send_msgs.append(("network_transmit_set", [network_count, network_interval]))

    send_iteration(
        app=params["mesh_app"],
        element=0,
        model_id=0x0001,
        key_index=0,
        target_addresses=kwargs["unicast"],
        send_msgs=send_msgs,
    )


async def configuration_get(params: dict[str, Any], **kwargs) -> None:
    logger.info("configuration_get: %r", kwargs)
    args = kwargs["get"]

    send_msgs: list[tuple[str, list[Any]]] = []
    ttl = "ttl" in args
    relay = "relay" in args
    network = "network" in args

    if ttl:
        send_msgs.append(("default_ttl_get", []))
    if relay:
        send_msgs.append(("relay_get", []))
    if network:
        send_msgs.append(("network_transmit_get", []))

    send_iteration(
        app=params["mesh_app"],
        element=0,
        model_id=0x0001,
        key_index=0,
        target_addresses=kwargs["unicast"],
        send_msgs=send_msgs,
    )


async def generic_level_set(params: dict[str, Any], **kwargs) -> None:
    logger.info("generic_level_set: %r", kwargs)
    args = kwargs["set"]

    send_msgs: list[tuple[str, list[Any]]] = []
    transition_time = args.get("transition_time")
    delay = args.get("delay")
    level = args.get("level")

    fields = []
    if level is not None:
        fields.append(level)
    else:
        return
    if transition_time is not None:
        fields.append(transition_time)
    if delay is not None:
        fields.append(delay)
    send_msgs.append(("set", fields))

    send_iteration(
        app=params["mesh_app"],
        element=0,
        model_id=0x1003,
        key_index=0,
        target_addresses=kwargs["unicast"],
        send_msgs=send_msgs,
    )


async def generic_level_get(params: dict[str, Any], **kwargs) -> None:
    logger.info("generic_level_get: %r", kwargs)
    args = kwargs["get"]

    send_msgs: list[tuple[str, list[Any]]] = []
    level = "level" in args

    if level:
        send_msgs.append(("get", []))
    else:
        return

    send_iteration(
        app=params["mesh_app"],
        element=0,
        model_id=0x1003,
        key_index=0,
        target_addresses=kwargs["unicast"],
        send_msgs=send_msgs,
    )


LC_PROPERTY = {
    "luxlevel_on": DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_ON,
    "luxlevel_prolong": DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_PROLONG,
    "luxlevel_standby": DevicePropertyID.LIGHT_CONTROL_AMBIENT_LUXLEVEL_STANDBY,
    "time_run_on": DevicePropertyID.LIGHT_CONTROL_TIME_RUN_ON,
    "time_prolong": DevicePropertyID.LIGHT_CONTROL_TIME_PROLONG,
    "time_fade_on": DevicePropertyID.LIGHT_CONTROL_TIME_FADE_ON,
    "time_fade": DevicePropertyID.LIGHT_CONTROL_TIME_FADE,
    "time_fade_standby_auto": DevicePropertyID.LIGHT_CONTROL_TIME_FADE_STANDBY_AUTO,
    "lightness_on": DevicePropertyID.LIGHT_CONTROL_LIGHTNESS_ON,
    "lightness_prolong": DevicePropertyID.LIGHT_CONTROL_LIGHTNESS_PROLONG,
    "lightness_standby": DevicePropertyID.LIGHT_CONTROL_LIGHTNESS_STANDBY,
}


async def light_lc_set(params: dict[str, Any], **kwargs) -> None:
    logger.info("light_lc_set: %r", kwargs)
    args = kwargs["set"]

    send_msgs: list[tuple[str, list[Any]]] = []
    light_lc_mode = args.get("light_lc_mode")
    occupancy_mode = args.get("occupancy_mode")

    if light_lc_mode is not None:
        send_msgs.append(("mode_set", [light_lc_mode]))
    if occupancy_mode is not None:
        send_msgs.append(("om_set", [occupancy_mode]))

    for property_name, property_id in LC_PROPERTY.items():
        if property_name in args:
            send_msgs.append(("property_set", [property_id, args[property_name]]))

    send_iteration(
        app=params["mesh_app"],
        element=0,
        model_id=0x1311,
        key_index=0,
        target_addresses=kwargs["unicast"],
        send_msgs=send_msgs,
    )


async def light_lc_get(params: dict[str, Any], **kwargs) -> None:
    logger.info("light_lc_get: %r", kwargs)
    args = kwargs["get"]

    send_msgs: list[tuple[str, list[Any]]] = []
    light_lc_mode = "light_lc_mode" in args
    occupancy_mode = "occupancy_mode" in args

    if light_lc_mode:
        send_msgs.append(("mode_get", []))
    if occupancy_mode:
        send_msgs.append(("om_get", []))

    for property_name, property_id in LC_PROPERTY.items():
        if property_name in args:
            send_msgs.append(("property_get", [property_id]))

    send_iteration(
        app=params["mesh_app"],
        element=0,
        model_id=0x1311,
        key_index=0,
        target_addresses=kwargs["unicast"],
        send_msgs=send_msgs,
    )


async def energy_accumulation_get(params: dict[str, Any], **kwargs) -> None:
    logger.info("energy_accumulation_get: %r", kwargs)
    args = kwargs["get"]

    send_msgs: list[tuple[str, list[Any]]] = []
    energy_accumulation = "energy_accumulation" in args

    if energy_accumulation:
        send_msgs.append(("get", []))
    else:
        return

    send_iteration(
        app=params["mesh_app"],
        element=0,
        model_id=0x0059E021,
        key_index=0,
        target_addresses=kwargs["unicast"],
        send_msgs=send_msgs,
    )


async def pir_accumulation_get(params: dict[str, Any], **kwargs) -> None:
    logger.info("pir_accumulation_get: %r", kwargs)
    args = kwargs["get"]

    send_msgs: list[tuple[str, list[Any]]] = []
    pir_accumulation = "pir_accumulation" in args

    if pir_accumulation:
        send_msgs.append(("get", []))
    else:
        return

    send_iteration(
        app=params["mesh_app"],
        element=0,
        model_id=0x0059E010,
        key_index=0,
        target_addresses=kwargs["unicast"],
        send_msgs=send_msgs,
    )


async def subscribe_update(params: dict[str, Any], **kwargs) -> None:
    # pylint: disable=too-many-locals
    logger.info("subscribe_update: %r", kwargs)
    targets = list(map(lambda x: int(x, base=16), kwargs["target_model_id"]))
    subscribe_list = list(map(lambda x: int(x, base=16), kwargs["group"]))
    target_addresses = list(map(lambda x: int(x, base=16), kwargs["unicast"]))
    app = params["mesh_app"]

    send_msgs: list[tuple[str, list[Any]]] = []

    for target in targets:
        for addr in target_addresses:
            send_msgs.append(
                ("model_subscription_overwrite", [addr, subscribe_list[0], target])
            )
            for subscribe_addr in subscribe_list[1:]:
                send_msgs.append(
                    ("model_subscription_add", [addr, subscribe_addr, target])
                )

    cdb = params["cdb"]
    element = 0
    model_id = 0x0001
    net_key_index = 0  # master key
    sends = []
    for msg, fields in send_msgs:
        sends.append((getattr(app[element][model_id], msg), fields))

    for send, fields in sends:
        assert callable(send)
        addr = fields[0]
        node = cdb.get_node(addr)
        send(node.unicastAddress, net_key_index, *fields)


async def publish_update(params: dict[str, Any], **kwargs) -> None:
    # pylint: disable=too-many-locals
    logger.info("publish_update: %r", kwargs)
    args = kwargs["publish"]
    targets = list(map(lambda x: int(x, base=16), kwargs["target_model_id"]))
    target_addresses = list(map(lambda x: int(x, base=16), kwargs["unicast"]))
    app = params["mesh_app"]

    send_msgs: list[tuple[str, list[Any]]] = []

    fields = []
    fields.append(int(args.get("address"), base=16))
    fields.append(args.get("index"))
    fields.append(args.get("credentials"))
    fields.append(args.get("ttl"))
    fields.append(args.get("period"))
    fields.append(args.get("retransmit_count"))
    fields.append(args.get("retransmit_interval"))

    for target in targets:
        for addr in target_addresses:
            send_msgs.append(("model_publication_set", [addr] + fields + [target]))

    cdb = params["cdb"]
    element = 0
    model_id = 0x0001
    net_key_index = 0  # master key
    sends = []
    for msg, fields in send_msgs:
        sends.append((getattr(app[element][model_id], msg), fields))

    for send, fields in sends:
        assert callable(send)
        addr = fields[0]
        node = cdb.get_node(addr)
        send(node.unicastAddress, net_key_index, *fields)


MQ_HANDLERS = {
    2: configuration_set,
    3: configuration_get,
    4: generic_level_set,
    5: generic_level_get,
    6: light_lc_set,
    7: light_lc_get,
    8: energy_accumulation_get,
    9: pir_accumulation_get,
    10: subscribe_update,
    11: publish_update,
}


def _str_to_datetime(time: str):
    return datetime.datetime.strptime(time, "%Y-%m-%dT%H:%M:%S%z")


def _datetime_to_str(time: datetime.datetime) -> str:
    return time.isoformat(timespec="seconds")


def _now() -> datetime.datetime:
    return datetime.datetime.now(tz=datetime.timezone(datetime.timedelta(hours=9)))


def _check_usage_of_resource() -> dict:
    cpu = round(psutil.cpu_percent(1), 2)
    mem = round(psutil.virtual_memory().percent, 2)
    diskinfo = os.statvfs("/")
    disk = round(diskinfo.f_bavail * diskinfo.f_bsize, 2)
    tx_packets = psutil.net_io_counters().packets_sent
    rx_packets = psutil.net_io_counters().packets_recv
    return {
        "cpu_utilization": cpu,
        "memory_utilization": mem,
        "disk_available": disk,
        "network_rx": rx_packets,
        "network_tx": tx_packets,
    }


def _gw_agent() -> str:
    """Dummy"""
    return "ASUS TinkerBoard2; Debian 10; Gateway/0.1.0/1"


def _default_fields() -> dict:
    data = {}
    data["agent"] = _gw_agent()
    data["timestamp"] = _datetime_to_str(_now())
    return data


async def heartbeat(mq_client: MQProducer) -> None:
    while True:
        logger.debug("heartbeat: pulse")
        data: dict[str, Any] = _check_usage_of_resource()
        data["msg_type"] = 1001
        data.update(_default_fields())
        await mq_client.call("status", data)
        await asyncio.sleep(60)


async def configuration_data(
    mq_client: MQProducer, uuid: _uuid.UUID, message: dict[str, Any]
) -> None:
    logger.info("configuration_data: %r", message)
    data: dict[str, Any] = message.copy()
    data["msg_type"] = 1002
    data["device_uuid"] = str(uuid)
    data.update(_default_fields())
    await mq_client.call("status", data)


async def generic_level_data(
    mq_client: MQProducer, uuid: _uuid.UUID, message: dict[str, Any]
) -> None:
    logger.info("generic_level_data: %r", message)
    data: dict[str, Any] = message.copy()
    data["msg_type"] = 1004
    data["device_uuid"] = str(uuid)
    data.update(_default_fields())
    await mq_client.call("light", data)


async def light_lc_data(
    mq_client: MQProducer, uuid: _uuid.UUID, message: dict[str, Any]
) -> None:
    logger.info("light_lc_data: %r", message)
    data: dict[str, Any] = message.copy()
    data["msg_type"] = 1006
    data["device_uuid"] = str(uuid)
    data.update(_default_fields())
    await mq_client.call("light", data)


async def energy_accumulation_data(
    mq_client: MQProducer, uuid: _uuid.UUID, message: dict[str, Any]
) -> None:
    logger.info("energy_accumulation_data: %r", message)
    data: dict[str, Any] = message.copy()
    data["msg_type"] = 1008
    data["device_uuid"] = str(uuid)
    data.update(_default_fields())
    await mq_client.call("energy", data)


async def pir_accumulation_data(
    mq_client: MQProducer, uuid: _uuid.UUID, message: dict[str, Any]
) -> None:
    logger.info("pir_accumulation_data: %r", message)
    data: dict[str, Any] = message.copy()
    data["msg_type"] = 1009
    data["device_uuid"] = str(uuid)
    data.update(_default_fields())
    await mq_client.call("space", data)


async def subscribe_update_data(
    mq_client: MQProducer, uuid: _uuid.UUID, message: dict[str, Any]
) -> None:
    logger.info("subscribe_update_data: %r", message)
    data: dict[str, Any] = message.copy()
    data["msg_type"] = 1010
    data["device_uuid"] = str(uuid)
    data.update(_default_fields())
    await mq_client.call("status", data)


async def publish_update_data(
    mq_client: MQProducer, uuid: _uuid.UUID, message: dict[str, Any]
) -> None:
    logger.info("publish_update_data: %r", message)
    data: dict[str, Any] = message.copy()
    data["msg_type"] = 1011
    data["device_uuid"] = str(uuid)
    data.update(_default_fields())
    await mq_client.call("status", data)


async def on_mq(
    data: dict[str, Any],
    params: dict[str, Any],
) -> Any:
    logger.debug("on_mq: [x] Incoming message: %r", data)
    function = MQ_HANDLERS[data.pop("msg_type")]
    timeout = data.pop("timeout", None)
    try:
        await asyncio.wait_for(function(params, **data), timeout=timeout)
        return "Success"
    except TimeoutError:
        return "Timeout"


async def on_control_message(data: dict[str, Any], event_client: MQProducer) -> None:
    logger.debug("on_control_message: [x] Incoming message: %r", data)
    _str_to_datetime(data.pop("timestamp"))
    expired = _str_to_datetime(data.pop("expired"))
    if expired < _now():
        logger.debug("on_control_message: expired: %r, now: %r", expired, _now())
        return
    await event_client.call("mq", data)


async def mq_loop(
    gw_id: str,
    qname: str,
    event_client: RpcClient,
    producer: MQProducer,
    consumer_rmq_url: str,
) -> None:
    # pylint: disable=too-many-arguments
    await asyncio.sleep(3)
    logger.debug("mq_loop: start")

    # MQ Control
    consumer = MQConsumer(consumer_rmq_url, "control")
    consumer.set_option("consumer_tag", gw_id)
    callback: dict[Callable, str] = {
        make_handler(on_control_message, event_client=event_client): qname,
    }

    logger.debug("mq_loop: running")

    await asyncio.gather(
        consumer.run(callback, durable=True, is_queuename=True), heartbeat(producer)
    )
    await asyncio.Future()

    #  # Heartbeat Disconnect
    #  await producer.disconnect()

    logger.debug("mq_loop: end")
