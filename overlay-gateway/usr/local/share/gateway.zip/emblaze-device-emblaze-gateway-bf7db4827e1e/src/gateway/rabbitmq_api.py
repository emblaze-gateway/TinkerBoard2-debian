# -*- coding: utf-8 -*-
"""Communication through rpc"""

import asyncio
import functools
import json
import logging
import time
import uuid
from functools import partial
from typing import Any, Callable

import aio_pika
import aio_pika.abc
import aio_pika.exceptions

logger = logging.getLogger("emblaze.gateway.rabbitmq_api")


class MQProducer:
    # pylint: disable=too-many-instance-attributes
    """RabbitMQ message Producer"""

    def __init__(self, url: str, exchange_name: str) -> None:
        self.__url: str = url
        self._exchange_name: str = exchange_name
        self._loop: asyncio.AbstractEventLoop | None = None

        self.__connection: aio_pika.abc.AbstractConnection
        self._channel: aio_pika.abc.AbstractChannel
        self._exchange: aio_pika.abc.AbstractExchange
        self._connected: bool = False
        self._options: dict[str, Any] = {}

        self._option_list = [
            "headers",
            "content_encoding",
            "priority",
            "correlation_id",
            "reply_to",
            "expiration",
            "message_id",
            "timestamp",
            "type",
            "user_id",
            "app_id",
        ]

    def set_message_option(self, option: str, value: Any):
        if option not in self._option_list:
            raise KeyError
        self._options[option] = value

    async def connect(self) -> "MQProducer":
        if self._connected:
            return self

        self._loop = self._loop or asyncio.get_running_loop()
        self.__connection = await aio_pika.connect_robust(self.__url, loop=self._loop)
        self._channel = await self.__connection.channel()
        self._exchange = await self._channel.declare_exchange(
            self._exchange_name,
            aio_pika.ExchangeType.DIRECT,
        )
        self._connected = True
        return self

    async def disconnect(self) -> None:
        if self._connected:
            self._loop = None
            await self._channel.close()
            await self.__connection.close()
            self._connected = False

    async def call(self, qname: str, data: dict[str, Any]) -> Any:
        if not self._connected:
            raise RuntimeError("Connection must be established first")
        logger.debug("%r publish: '%r': data '%r'", self._exchange_name, qname, data)
        await self._exchange.publish(
            aio_pika.Message(
                json.dumps(data).encode(),
                content_type="application/json",
                delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
                **self._options,
            ),
            routing_key=qname,
        )

    async def __aenter__(self):
        await self.connect()

    async def __aexit__(self, exe_type, exe_value, traceback):
        await self.disconnect()


class RpcClient(MQProducer):
    """RabbitMQ-based RPC client"""

    def __init__(self, url: str, exchange_name: str) -> None:
        super().__init__(url, exchange_name)

        self.__futures: dict[str, asyncio.Future]
        self.__callback_queue: aio_pika.abc.AbstractQueue

        self._option_list = [
            "headers",
            "content_encoding",
            "priority",
            "expiration",
            "message_id",
            "timestamp",
            "type",
            "user_id",
            "app_id",
        ]

    async def connect(self) -> "RpcClient":
        await super().connect()
        self.__futures = {}
        self.__callback_queue = await self._channel.declare_queue(exclusive=True)
        await self.__callback_queue.bind(
            self._exchange, routing_key=self.__callback_queue.name
        )
        await self.__callback_queue.consume(self.on_response, no_ack=True)

        return self

    async def disconnect(self) -> None:
        await super().disconnect()
        for future in self.__futures.values():
            future.cancel()
        for future in self.__futures.values():
            await future

    def on_response(self, message: aio_pika.abc.AbstractIncomingMessage) -> None:
        if message.correlation_id is None:
            logger.warning("Unreachable message %r", message)
            return

        future: asyncio.Future = self.__futures.pop(message.correlation_id)
        future.set_result(message.body)
        logger.debug(
            "%r receive response: data '%r'", self._exchange_name, message.body
        )

    async def call(self, qname: str, data: dict[str, Any]) -> Any:
        if not self._connected:
            raise RuntimeError("Connection must be established first")
        correlation_id = str(uuid.uuid4())
        assert isinstance(self._loop, asyncio.AbstractEventLoop)
        future: asyncio.Future = self._loop.create_future()

        self.__futures[correlation_id] = future

        logger.debug("%r publish: '%r': data '%r'", self._exchange_name, qname, data)
        await self._exchange.publish(
            aio_pika.Message(
                json.dumps(data).encode(),
                content_type="application/json",
                correlation_id=correlation_id,
                reply_to=self.__callback_queue.name,
                delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
                **self._options,
            ),
            routing_key=qname,
        )

        return json.loads((await future).decode())


class MQConsumer:
    """RabbitMQ message Consumer"""

    def __init__(self, url: str, exchange_name: str, loop=None) -> None:
        self._url: str = url
        self._exchange_name: str = exchange_name
        self._loop = loop
        self._waiter: asyncio.Future | None = None
        self._options: dict[str, Any] = {}

        self._option_list = [
            "consumer_tag",
        ]

    def set_option(self, option: str, value: Any):
        if option not in self._option_list:
            raise KeyError
        self._options[option] = value

    def is_running(self):
        return self._waiter is not None and not self._waiter.done()

    def start(self):
        if not self.is_running():
            self._waiter = asyncio.Future()

    async def stop(self):
        if self.is_running():
            self._waiter.set_result(0)
            self._waiter = None

    async def run(
        self,
        callbacks: dict[Callable, str],
        prefetch_count: int = 5,
        *,
        durable=False,
        is_queuename=False,
    ) -> Any:
        #  if self.is_running():
        #  logger.error("Consumer is already running", self._exchange_name)
        #  return
        #  self.start()
        self._loop = self._loop or asyncio.get_running_loop()
        connection = await aio_pika.connect_robust(self._url, loop=self._loop)
        async with connection:
            async with connection.channel() as channel:
                await channel.set_qos(prefetch_count=prefetch_count)

                exchange = await channel.declare_exchange(
                    self._exchange_name, aio_pika.ExchangeType.DIRECT, durable=durable
                )

                for callback, routing_key in callbacks.items():
                    queue = await channel.declare_queue(
                        routing_key if is_queuename else None, durable=True
                    )
                    await queue.bind(exchange, routing_key=routing_key)
                    await queue.consume(callback, **self._options)
                    logger.debug(
                        "%r consume: '%r' start", self._exchange_name, routing_key
                    )

                await asyncio.Future()
                #  if self.is_running():
                #  assert self._waiter is not None
                #  await self._waiter


class RpcServer(MQConsumer):
    """RabbitMQ-based RPC server"""

    def __init__(
        self,
        url: str,
        exchange_name: str,
        loop: asyncio.AbstractEventLoop | None = None,
    ) -> None:
        super().__init__(url, exchange_name, loop)

    async def run(
        self,
        callbacks: dict[Callable, str],
        prefetch_count: int = 5,
        *,
        durable=False,
        is_queuename=False,
    ) -> Any:
        #  if self.is_running():
        #  logger.error("Consumer is already running", self._exchange_name)
        #  return
        #  self.start()
        self._loop = self._loop or asyncio.get_running_loop()
        connection = await aio_pika.connect_robust(self._url, loop=self._loop)
        async with connection:
            async with connection.channel() as channel:
                await channel.set_qos(prefetch_count=prefetch_count)

                exchange = await channel.declare_exchange(
                    self._exchange_name, aio_pika.ExchangeType.DIRECT, durable=durable
                )

                for callback, routing_key in callbacks.items():
                    queue = await channel.declare_queue(
                        routing_key if is_queuename else None, durable=True
                    )
                    await queue.bind(exchange, routing_key=routing_key)
                    await queue.consume(
                        functools.partial(callback, exchange=exchange), **self._options
                    )
                    logger.debug(
                        "%r consume: '%r' start", self._exchange_name, routing_key
                    )

                await asyncio.Future()
                #  if self.is_running():
                #  assert self._waiter is not None
                #  await self._waiter


async def __on_handler(
    message: aio_pika.abc.AbstractIncomingMessage,
    func: Callable[[dict[str, Any]], Any],
) -> Any:
    async with message.process(ignore_processed=True):
        try:
            data = json.loads(message.body.decode())
            logger.debug(" [x] Incoming message: %r", data)
            await func(data)

        except Exception as e:
            await message.reject()
            logger.exception(" [x] exception: %r", e)
            logger.exception("processing error for message %r", message)


async def __on_rpc_handler(
    message: aio_pika.abc.AbstractIncomingMessage,
    func: Callable[[dict[str, Any]], Any],
    exchange: aio_pika.abc.AbstractExchange,
) -> Any:
    async with message.process(ignore_processed=True):
        status = 0
        result = None
        assert message.reply_to is not None
        try:
            data = json.loads(message.body.decode())
            logger.debug(" [x] Incoming message: %r", data)
            result = await func(data)

        except Exception as e:
            await message.reject()
            logger.exception(" [x] exception: %r", e)
            logger.exception("processing error for message %r", message)
            result = (
                f"Exception: {e}\n"
                f"    message: {message}\n"
                f"    body: {message.body!r}"
            )
            status = 1
        finally:
            ret = {
                "status": status,
                "timestamp": time.time(),
                "response": result,
            }
            logger.debug(" [.] Response: %r", ret)
            response = json.dumps(ret).encode()

            await exchange.publish(
                aio_pika.Message(
                    body=response,
                    correlation_id=message.correlation_id,
                ),
                routing_key=message.reply_to,
            )


def make_handler(func: Callable, *args, **kwargs):
    return partial(__on_handler, func=partial(func, *args, **kwargs))


def make_rpc_handler(func: Callable, *args, **kwargs):
    return partial(__on_rpc_handler, func=partial(func, *args, **kwargs))
