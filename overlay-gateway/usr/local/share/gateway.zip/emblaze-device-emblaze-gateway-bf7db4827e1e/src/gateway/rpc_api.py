# -*- coding: utf-8 -*-
"""Communication through rpc"""

import os
import asyncio
import configparser
import logging
import sys
import uuid
from typing import Any, Callable

import gateway.rest_api
from gateway.mesh.mesh_application import create_application, create_cdb
from gateway.mesh_api import mesh_loop, on_mesh
from gateway.mq_api import mq_loop, on_mq
from gateway.rabbitmq_api import MQProducer, RpcClient, RpcServer, make_rpc_handler
from gateway.watchdog import watchdog_init, sd_notify

logger = logging.getLogger("emblaze.gateway.rpc_api")
LOCAL_MQ_URL = "amqp://guest:guest@127.0.0.1/"


#  restricted_locals: dict[str, dict[str, Any]] = {}


async def on_rpc(
    data: dict[str, Any],
    params: dict[str, Any],
) -> Any:
    # pylint: disable=exec-used
    return_val = f"__result{uuid.uuid4().hex}"
    logger.debug("on_rpc: command: %r", data.get("command"))
    command_line = f"{return_val} = {data.pop('command')}"

    restricted_local: dict[str, Any] = {}
    #  restricted_local = restricted_locals[data["id"]]

    restricted_local["cdb"] = params["cdb"]
    restricted_local["app"] = params["mesh_app"]

    exec(command_line, {}, restricted_local)
    logger.debug("on_rpc: result: %r", restricted_local[return_val])

    return str(restricted_local[return_val])
    #  return restricted_local


#  def get_rpc_client(user_id: str | None = None):
def get_rpc_client():
    client = RpcClient(LOCAL_MQ_URL, "event")
    #  user_id = user_id or uuid.uuid4().hex
    #  client.set_message_option("user_id", user_id)
    logger.debug("")
    return client


async def rpc(event_client: RpcClient, command: str):
    logger.debug("")
    return await event_client.call("rpc", {"command": command})


async def on_heartbeat(
    data: dict[str, Any],
) -> Any:
    logger.info("on_heartbeat: pulse %r", data["from"])


async def heartbeat(event_client: RpcClient):
    await asyncio.sleep(3)
    while True:
        await event_client.call("heartbeat", {"from": "event_loop"})
        await asyncio.sleep(60)


async def event_loop(config: configparser.ConfigParser) -> None:
    # pylint: disable=too-many-locals,too-many-statements
    sd_notify("STATUS=Starting up")

    logger.debug("event_loop: start")

    rest_config = dict(config["rest"])

    gw_id = config["main"]["gateway_id"]
    _gw_queue = await get_gateway_queue(gw_id, rest_config)
    if _gw_queue is None:
        raise RuntimeError("Cannot get CDB")
    amqp_pw = _gw_queue["pw"]
    amqp_queue = _gw_queue["queue"]
    mq_account = gw_id + ":" + amqp_pw
    event_parameters: dict[str, Any] = {}

    # Event Client
    event_client = await RpcClient(LOCAL_MQ_URL, "event").connect()
    event_parameters["event_client"] = event_client
    logger.debug("event_loop: event_client set")

    # MQ Client
    producer_rmq_url = (
        "amqp://"
        + mq_account
        + "@"
        + config["rabbitmq"]["domain"]
        + ":"
        + config["rabbitmq"]["monitoring_port"]
    )
    mq_client = await MQProducer(producer_rmq_url, "monitoring").connect()
    mq_client.set_message_option("user_id", gw_id)
    event_parameters["mq_client"] = mq_client
    logger.debug("event_loop: mq_client set")

    # MQ Server
    mq_server = mq_loop(
        gw_id,
        amqp_queue,
        event_client,
        mq_client,
        (
            "amqp://"
            + mq_account
            + "@"
            + config["rabbitmq"]["domain"]
            + ":"
            + config["rabbitmq"]["control_port"]
        ),
    )
    mq_server_task = asyncio.create_task(mq_server)
    #  loops.append(mq_server)
    event_parameters["mq_server"] = mq_server
    logger.debug("event_loop: mq_server set")

    # Mesh Client
    cdb_dict = await get_cdb(gw_id, rest_config)
    if not cdb_dict:
        raise RuntimeError(f"{cdb_dict}")
    cdb = create_cdb(**(cdb_dict))
    mesh_app = create_application(
        cdb,
        int(config["mesh"].get("token", "0")) or None,
        int(config["mesh"].get("seqnr", "0")),
    )
    if mesh_app is None:
        sys.exit(1)
    event_parameters["cdb"] = cdb
    event_parameters["mesh_app"] = mesh_app
    logger.debug("event_loop: mesh_client set")

    # Mesh Server
    mesh_server = mesh_loop(mesh_app, RpcClient(LOCAL_MQ_URL, "event"))
    mesh_server_task = asyncio.create_task(mesh_server)
    #  loops.append(mesh_server)
    event_parameters["mesh_server"] = mesh_server
    logger.debug("event_loop: mesh_server set")

    # Event Server
    event_server = RpcServer(LOCAL_MQ_URL, "event")
    event_parameters["event_server"] = event_server
    callback: dict[Callable, str] = {
        make_rpc_handler(on_rpc, params=event_parameters): "rpc",
        make_rpc_handler(on_mesh, params=event_parameters): "mesh",
        make_rpc_handler(on_mq, params=event_parameters): "mq",
        make_rpc_handler(on_heartbeat): "heartbeat",
    }
    event_server_task = asyncio.create_task(event_server.run(callback))
    logger.debug("event_loop: event_server set")

    heartbeat_task = asyncio.create_task(heartbeat(event_client))

    watchdog_task = asyncio.create_task(watchdog_init())

    sd_notify("READY=1")
    sd_notify("STATUS=Running")

    try:
        await event_server_task
        await mesh_server_task
        await mq_server_task
        await heartbeat_task
        await watchdog_task
        await asyncio.Future()
    finally:
        sd_notify("STOPPING=1")
        sd_notify("STATUS=Quitting")
        config["mesh"] = {"seqnr": mesh_app.sequence_number}
        mesh_app.leave_node()
        await asyncio.sleep(1)

    # Event Client Disconnect
    #  await event_client.disconnect()
    #  await mq_client.disconnect()
    logger.debug("event_loop: end")


async def get_cdb(gw_id: str, config: dict[str, str]) -> dict[str, Any] | None:
    """1-3-6 Gateway CDB Get"""
    request = {
        "api": 12005,
        "gateway_id": gw_id,
    }
    response = await gateway.rest_api.post("/device", request, config)
    if response[0] == 200:
        return response[1]
    return None


async def get_gateway_queue(
    gw_id: str, config: dict[str, str]
) -> dict[str, Any] | None:
    """1-3-5 Gateway Queue Get"""
    request = {
        "api": 12004,
        "gateway_id": gw_id,
    }
    response = await gateway.rest_api.post("/device", request, config)
    if response[0] == 200:
        return response[1]
    return None
