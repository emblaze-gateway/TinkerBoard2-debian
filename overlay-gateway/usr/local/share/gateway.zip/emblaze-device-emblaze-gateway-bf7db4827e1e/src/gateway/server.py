# -*- coding: utf-8 -*-
"""Internal routines"""

import argparse
import asyncio
import configparser
import json
import logging
import logging.config
import pathlib
import sys
import signal

from gateway.rpc_api import event_loop

logger = logging.getLogger("emblaze.gateway.server")

SAMPLE_CONFIG_FILE_PATH = pathlib.Path(__file__).parent / "example.ini"


def _SIGTERM_handler(signum, frame):
    raise SystemExit

def _SIGABRT_handler(signum, frame):
    raise SystemExit

signal.signal(signal.SIGTERM, _SIGTERM_handler)
signal.signal(signal.SIGABRT, _SIGABRT_handler)


def main() -> None:
    # pylint: disable=too-many-locals,too-many-branches,too-many-statements
    default_directory_path = pathlib.Path.home() / "emblaze"

    default_config_file_path = default_directory_path / "config.ini"
    default_db_file_path = default_directory_path / "dat.json"
    default_log_file_path = default_directory_path / "log.log"

    parser = argparse.ArgumentParser(
        description="Connect mesh network to backend server"
    )
    parser.add_argument(
        "-c",
        "--conf",
        default=default_config_file_path,
        type=pathlib.Path,
        help="configuration file path",
        metavar="CONFIG_FILE",
    )
    parser.add_argument(
        "-d",
        "--dat",
        default=default_db_file_path,
        type=pathlib.Path,
        help="database file path",
        metavar="DB_FILE",
    )
    parser.add_argument(
        "--log-file",
        default=default_log_file_path,
        type=pathlib.Path,
        help="log file path",
        metavar="LOG_FILE",
    )
    args = vars(parser.parse_args(sys.argv[1:]))

    if args["conf"] == default_config_file_path:
        default_directory_path.mkdir(parents=True, exist_ok=True)
        if not args["conf"].exists():
            with open(SAMPLE_CONFIG_FILE_PATH, "r", encoding="utf-8") as file:
                content = file.read()
            with open(args["conf"], "w", encoding="utf-8") as file:
                file.write(content)
            logging.error("config 파일이 존재하지 않아 새로 생성되었습니다. "
                          "해당 config 내용을 채운 후 다시 실행해주세요.")
            sys.exit(1)

    if not args["conf"].exists():
        logging.error("config 파일이 존재하지 않습니다.")
        sys.exit(1)

    config = configparser.ConfigParser()

    with open(args["conf"], encoding="utf-8") as file:
        config.read_file(file)

    if args["log_file"] == default_log_file_path:
        args["log_file"] = pathlib.Path(
            config["logger"].get("filename") or args["log_file"]
        )

    default_logger = {
        "handlers": config["logger"].get("handlers", "null").split(","),
        "level": config["logger"].get("level", "WARNING"),
        "propagate": config["logger"].get("propagate", "no"),
    }

    loggers = {}
    root_logger = {}
    for logger_name in config["logger"].get("keys").split(","):
        logger_section = "logger." + logger_name
        current_logger = {}
        current_logger = default_logger.copy()
        if config.has_section(logger_section):
            for option, value in config[logger_section].items():
                current_logger[option] = value.split(",")
        if logger_name == "root":
            root_logger = current_logger
        else:
            loggers[logger_name] = current_logger

    logging_obj = {
        "version": 1,
        "disable_existing_loggers": True,
        "formatters": {
            "verbose": {
                "format": "%(asctime)s - %(name)s - %(funcName)s - %(module)s - "
                "%(process)d - %(thread)d - %(levelname)s - %(message)s"
            },
            "default": {
                "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            },
            "simple": {"format": "%(name)s - %(levelname)s - %(message)s"},
        },
        "handlers": {
            "null": {
                "level": "DEBUG",
                "class": "logging.NullHandler",
            },
            "console": {
                "level": "INFO",
                "class": "logging.StreamHandler",
                "formatter": "default",
            },
            "console_simple": {
                "level": "INFO",
                "class": "logging.StreamHandler",
                "formatter": "simple",
            },
            "console_verbose": {
                "level": "INFO",
                "class": "logging.StreamHandler",
                "formatter": "verbose",
            },
            "file": {
                "level": "DEBUG",
                "class": "logging.FileHandler",
                "formatter": "default",
                "filename": str(args["log_file"]),
                "mode": "w",
            },
            "file_verbose": {
                "level": "DEBUG",
                "class": "logging.FileHandler",
                "formatter": "verbose",
                "filename": str(args["log_file"]),
                "mode": "w",
            },
        },
    }

    if loggers:
        logging_obj["loggers"] = loggers

    if root_logger:
        logging_obj["root"] = root_logger

    logging.config.dictConfig(logging_obj)

    required_options = {
        "main": ["gateway_id"],
        "rabbitmq": ["domain", "monitoring_port", "control_port"],
        "rest": ["access_key", "secret_key", "segment", "domain"],
    }
    if not set(config.sections()).issuperset(required_options.keys()):
        raise AttributeError(
            "Missed required config: "
            f"{set(required_options.keys()) - set(config.sections())}"
        )
    for sec, opts in required_options.items():
        if not set(config.options(sec)).issuperset(opts):
            raise AttributeError(
                "Missed required options from "
                f"{sec}: {set(opts) - set(config.options(sec))}"
            )

    if args["dat"] == default_db_file_path:
        default_directory_path.mkdir(parents=True, exist_ok=True)
        if not default_db_file_path.exists():
            with open(default_db_file_path, "w", encoding="utf-8") as file:
                json.dump({}, file)

    with open(args["dat"], encoding="utf-8") as file:
        config["mesh"] = json.load(file)

    try:
        asyncio.run(event_loop(config))
    except KeyboardInterrupt:
        logger.info(" [*] Interrupted")
        sys.exit(1)
    except SystemExit:
        logger.info(" [*] Terminated")
        sys.exit(2)
    except Exception as e:
        logger.error(" [.] %r", e)
        sys.exit(3)
    finally:
        with open(args["dat"], "w", encoding="utf-8") as file:
            json.dump(dict(config["mesh"]), file)


if __name__ == "__main__":
    main()
