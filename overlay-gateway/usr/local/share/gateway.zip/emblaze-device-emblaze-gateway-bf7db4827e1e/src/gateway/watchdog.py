import asyncio
import os
import threading
import logging

logger = logging.getLogger("emblaze.gateway.watchdog")

PID = os.environ['WATCHDOG_PID']
USEC = os.environ['WATCHDOG_USEC']
SOCK = os.environ['NOTIFY_SOCKET']


try:
    from systemd import daemon as sd
except ImportError:
    logger.warning("Unused systemd module")
    def sd_booted() -> bool:
        return False
    def sd_notify(status: str, pid: int = 0) -> None:
        pass
else:
    def sd_booted() -> bool:
        return sd.booted()
    if SOCK:
        def sd_notify(status: str, pid: int = 0) -> None:
            sd.notify(status, pid=pid)
    else:
        logger.warning("Unset systemd notification")
        def sd_notify(status: str, pid: int = 0) -> None:
            pass


async def watchdog_init() -> None:
    if not sd_booted():
        logger.warning("This system is not booted by systemd")
        return

    if not PID or not USEC:
        logger.debug("Watchdog NOT set.")
        return

    pid = int(PID)
    interval = int(USEC) / 1000000 / 3
    logger.debug("Watchdog set. PID(%s) USEC(%s)", PID, USEC)

    await watchdog_callback(pid, interval)


async def watchdog_callback(pid: int, interval: float) -> None:
    while True:
        sd_notify("WATCHDOG=1", pid=pid)
        await asyncio.sleep(interval)
