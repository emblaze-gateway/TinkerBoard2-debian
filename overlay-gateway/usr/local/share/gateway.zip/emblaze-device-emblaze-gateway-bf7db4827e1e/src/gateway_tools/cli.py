# -*- coding: utf-8 -*-
"""API를 호출하거나 파이썬 코드를 실행할 수 있는 Command Line Interface.

Examples:
    키워드 인자를 갖는 함수 호출 형태로 API를 호출할 수 있다. 또한, 데이터를 생성하고,
    변경/수정하기 위해 파이썬 문법을 지원한다::

        $ ./command_line_interface
        >>> helper()
        >>> helper(name="api_name")
        >>> api_name(foo="foo", bar="bar")

"""

import asyncio
import logging
import sys
from functools import partial
from pathlib import Path
from typing import Any

from prompt_toolkit import PromptSession, print_formatted_text
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.history import FileHistory
from prompt_toolkit.lexers import PygmentsLexer
from pygments.lexers.python import PythonLexer

import gateway.mq_api
import gateway.rpc_api
import gateway.server
from gateway.rabbitmq_api import RpcClient

logging.basicConfig()


def main() -> None:
    # pylint: disable=exec-used
    """CLI 메인함수"""
    hist_file: Path = Path("~/.cache/emblaze-gateway/command_history").expanduser()
    hist_file.parent.mkdir(parents=True, exist_ok=True)
    if not hist_file.exists():
        hist_file.touch()

    #  apis = list(gw.GW_ROUTINES.keys())
    apis = ["call"]

    lexer = PygmentsLexer(PythonLexer)

    def prompt_continuation(width, line_number, is_soft_wrap):
        # pylint: disable=unused-argument
        return "... "

    session: PromptSession = PromptSession(history=FileHistory(str(hist_file)))
    session.auto_suggest = AutoSuggestFromHistory()
    session.completer = WordCompleter(apis)
    session.multiline = True
    session.prompt_continuation = prompt_continuation

    restricted_global: dict[str, Any] = {}
    restricted_local: dict[str, Any] = {}

    event_client = gateway.rpc_api.get_rpc_client()

    restricted_global["call"] = partial(call, event_client)
    #  restricted_local["mq_api"] = gateway.mq_api
    #  restricted_local["get_api_doctrings"] = get_api_doctrings

    while True:
        try:
            command = session.prompt(">>> ", lexer=lexer)
        except KeyboardInterrupt:
            print_formatted_text(
                "<<KeyboardInterrupt>>. (Press Ctrl-D if you want to exit)\n"
            )
            continue
        except EOFError:
            print_formatted_text("Program Exit")
            sys.exit(0)
        try:
            exec(command, restricted_global, restricted_local)
        except Exception as e:
            print_formatted_text(f"An error occurred: {type(e)}: {e}")


async def __call(event_client: RpcClient, command: str):
    response = None
    async with event_client:
        response = await gateway.rpc_api.rpc(event_client, command)
    return response


def call(event_client: RpcClient, command: str):
    return asyncio.run(__call(event_client, command))


if __name__ == "__main__":
    main()
